# The factor 3 in periods of cubic trace sequences

Review release of 21 November 2026. Open `manuscript.pdf` for the theorems and proofs. The corresponding LaTeX is `manuscript.tex`. The local character formula and the density dichotomy are unconditional. Historical priority and independent human review remain open.

## Reproduce the results

Extract this archive and run the following from the directory containing this file, with Python 3.8 or newer. The tests use only the standard library and run offline.

```sh
python3 verify.py
```

The verifier hashes the release files and compares fresh stdout with every expected transcript. It exits with an error on any mismatch. SHA-256 checks consistency of this copy. A separate repository timestamp or DOI supplies publication provenance when a human creator deposits the work.

| Path | Purpose |
| --- | --- |
| `replication/check.py` | Exact enumeration of eligible primes through 1,000,000, Frobenius-oriented character, independent recurrence matrix, auxiliary cubic and bounded quadratic-form test. Pass a smaller inclusive bound as the first argument for a quick check. |
| `replication/family_check.py` | Explicit polynomial long division and literal root enumeration for the general two-coefficient family, including vanishing norm witnesses. |
| `replication/dichotomy_check.py` | Integer-root comparison for 625 coefficient pairs and prime sweeps for two universal cases and three possible pairs of irreducible Galois groups. |
| `pari/` | Previously archived independent PARI factorizations, original GP program and version, plus a fresh prime-by-prime comparison. The verifier independently recomputes the Python side. To regenerate the original output separately, run `gp -q pari/pari_audit.gp` with PARI/GP and its Galois data installed. |
| `next-search/` | Small 7-part pilot using direct root enumeration, exact period extraction from a factored group order, and recurrence-state verification. A standalone second implementation checks the census and first recurrence return at 9781. The sample provides no asserted density. |
| `companion/` | Separate application of the archived Dirichlet critical-line statement to a 256-bit interval. Contains the analytic deduction, exact Python calculator, tests, a search over 256 smaller interval widths and a coarser rational cross-check, expected outputs and the Lean source for the original endpoint arithmetic. |
| `publication-route.md` | Claim-by-claim assessment, concrete next searches, and release and submission sequence. |
| `priority-notes.md`, `field-priority-notes.md` | Dated research notes, detailed citations and scope of the prior-art search. |

To rebuild the manuscript run `tectonic manuscript.tex` in an editable copy. Classic LaTeX with the standard AMS, geometry, booktabs and hyperref packages also supports the source. Tectonic may download its TeX bundle on first use. The release PDF was built with Tectonic 0.17.0. The mathematical findings can be checked independently of the PDF build.

## Provenance

The prior PARI dataset and original interval certificate came from the research checkout at commit `18eab560e0bcfc8c525176ea7e7f37883b5107ec`. This archive contains the inputs needed for the Python reproductions, regardless of access to that checkout. The interval calculator re-evaluates a published analytic inequality at two explicit endpoints. The main paper supplies its mathematical arguments in writing. Neither the paper's general cubic theorem nor the external analytic inequality is claimed here as a newly compiled Lean theorem.

An optional arithmetic-only replay uses the toolchain declared in `companion/lean-toolchain`. From that directory, run `lean TraceWindowArithmetic.lean` with that toolchain installed. The current review run exercised the Python checks. Sutherland's [public provenance and checker results](https://math.mit.edu/~drew/grh/) document the comparison against the formal Dirichlet theorem used by the companion.

Human authorship, choice of release licenses, and any external submission are reserved for the people taking responsibility for the final work. The manuscript contains its AI-assistance disclosure.
