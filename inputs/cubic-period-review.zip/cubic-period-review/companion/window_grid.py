"""Apply the archived endpoint inequality on 256 nested widths and cross-check a round bound."""
from fractions import Fraction
from math import ceil
from rh_trace_window import certify, log_bounds


def main():
    b = 2**256
    unit = 2**134
    grid = [certify(b - j*unit, b)[0] for j in range(1, 257)]
    first = next(j for j, lower in enumerate(grid, 1) if lower > 0)
    a = b - first*unit
    # Independent coarse arithmetic: round the same endpoint inequality using
    # sqrt(x) <= 2^128 and a single pair of log bounds for both endpoints.
    lo = Fraction(1774456, 10000)
    hi = Fraction(1774457, 10000)
    d_hi = Fraction(846822, 100000)
    pi_lo = Fraction(314, 100)
    if not (lo < log_bounds(a)[0] and log_bounds(b)[1] < hi
            and log_bounds(4761)[1] < d_hi):
        raise ArithmeticError("coarse log enclosures failed")
    error_each = 2**128 * ((1/(2*pi_lo) + 3/lo)*d_hi
                           + 4*(hi/(8*pi_lo) + 1/(4*pi_lo) + 6/lo))
    coarse_lower = ceil(((b-a)/hi - 2*error_each)/4)
    rounded_bound = 16 * 10**36
    if first != 168 or min(coarse_lower, grid[first-1]) < rounded_bound:
        raise ArithmeticError((first, coarse_lower, grid[first-1]))
    print("widths tested: j*2^134 for integer j from 1 through 256")
    print("first j with positive certified lower bound:", first)
    print("lower bound at j=167:", grid[166])
    print("lower bound at j=168:", grid[167])
    print("coarse rational lower bound at j=168:", coarse_lower)
    print("width ratio relative to 2^142:", Fraction(b-a, 2**142))


if __name__ == "__main__":
    main()
