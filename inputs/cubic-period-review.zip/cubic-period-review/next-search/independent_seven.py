"""Check the index-seven census by recurrence matrices and one witness by iteration."""
from math import isqrt


def is_prime(n):
    return n >= 2 and all(n % k != 0 for k in range(2, isqrt(n) + 1))


def returns_after(n, p):
    """Apply n recurrence steps to the initial row vector by binary powering."""
    matrix = ((0, 0, 1), (1, 0, 1), (0, 1, 0))
    initial = (3 % p, 0, 2 % p)
    state = initial

    def apply(row, columns):
        return tuple(sum(a*b for a, b in zip(row, column)) % p for column in columns)

    while n:
        columns = tuple(zip(*matrix))
        if n & 1:
            state = apply(state, columns)
        matrix = tuple(apply(row, columns) for row in matrix)
        n //= 2
    return state == initial


def census(limit):
    eligible = index_hits = period_hits = 0
    for p in range(2, limit + 1):
        if p % 7 not in (2, 4) or not is_prime(p):
            continue
        if any((x**3 - x - 1) % p == 0 for x in range(p)):
            continue
        n = p*p + p + 1
        eligible += 1
        index_hits += returns_after(n//7, p)
        while n % 7 == 0:
            n //= 7
        period_hits += not returns_after(n, p)
    return eligible, index_hits, period_hits


def first_return(p):
    initial = (3 % p, 0, 2 % p)
    a, b, c = initial
    for k in range(1, p*p + p + 2):
        a, b, c = b, c, (a+b) % p
        if (a, b, c) == initial:
            return k
    raise ArithmeticError('no return in the norm-one bound')


if __name__ == '__main__':
    counts = census(10000)
    witness = 9781
    period = first_return(witness)
    n = witness*witness + witness + 1
    print('inclusive limit 10000')
    print('eligible, 7 divides index, 7 divides period:', *counts)
    print('witness prime, first recurrence return, index:', witness, period, n//period)
    if counts != (133, 12, 122) or n != 7*period:
        raise ArithmeticError('regression mismatch')
