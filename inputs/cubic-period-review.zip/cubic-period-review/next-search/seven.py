"""Pilot for the 7-part of the Perrin period at irreducible primes.

The default run obtains each period by factor reduction and independently checks
index divisibility by 7 using the recurrence matrix. It uses public small primes.
"""
import argparse
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "replication"))
from check import ONE, X, perrin, power, primes_up_to


def prime_divisors(n):
    divisor = 2
    while divisor * divisor <= n:
        if n % divisor == 0:
            yield divisor
            while n % divisor == 0:
                n //= divisor
        divisor = 3 if divisor == 2 else divisor + 2
    if n > 1:
        yield n


def period(p, bound):
    result = bound
    for prime in prime_divisors(bound):
        while result % prime == 0 and power(X, result // prime, p) == ONE:
            result //= prime
    return result


def run(limit):
    counts = {}
    examples = {}
    for p in primes_up_to(limit):
        if p % 7 not in (2, 4):
            continue
        # A cubic without a root over the prime field is irreducible.
        if any((x**3 - x - 1) % p == 0 for x in range(p)):
            continue
        n = p*p + p + 1
        valuation = 1
        cofactor = n // 7
        while cofactor % 7 == 0:
            valuation += 1
            cofactor //= 7
        order = period(p, n)
        # The recurrence test starts from the original trace initial triple.
        state = tuple(perrin(n//7 + i, p) for i in range(3))
        index_multiple = (n // order) % 7 == 0
        if (state == (3 % p, 0, 2 % p)) != index_multiple:
            raise ArithmeticError((p, n, order, state))
        bucket = (p % 7, valuation)
        row = counts.setdefault(bucket, [0, 0, 0])
        row[0] += 1
        row[1] += index_multiple
        row[2] += order % 7 == 0
        examples.setdefault((valuation, index_multiple, order % 7 == 0), (p, n, order))
    print("inclusive bound", limit)
    print("p mod 7 | v7(N) | primes | 7 divides index | 7 divides period")
    for (residue, valuation), row in sorted(counts.items()):
        print(residue, valuation, *row)
    print("witnesses: v7(N), index divisible, period divisible -> (p, N, period)")
    for key in sorted(examples):
        print(key, examples[key])


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("limit", nargs="?", type=int, default=10000)
    args = parser.parse_args()
    if args.limit < 0:
        parser.error("limit must be nonnegative")
    run(args.limit)
