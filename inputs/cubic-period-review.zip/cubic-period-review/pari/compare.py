"""Verify the eligible prime set and each q-splitting flag against PARI's factorizations."""
import gzip
import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "replication"))
from check import ONE, X, power, primes_up_to

LIMIT = 1_000_000


def run():
    eligible = cubes = checked = 0
    with gzip.open(Path(__file__).with_name("pari-rows.jsonl.gz"), "rt") as rows:
        kind, metadata = json.loads(next(rows))
        if kind != "metadata" or metadata[3:5] != [-23, 621]:
            raise ValueError("unexpected PARI header")
        for prime in primes_up_to(LIMIT):
            if prime in (3, 23):
                continue
            p, f_degrees, q_degrees, _ = json.loads(next(rows))
            if p != prime:
                raise ValueError(("prime sequence mismatch", prime, p))
            checked += 1
            if p % 3 != 1:
                continue
            is_inert = (pow(-23 % p, (p - 1) // 2, p) == 1 and power(X, p, p) != X)
            if is_inert != (f_degrees == [3]):
                raise ValueError(("eligibility mismatch", p, f_degrees))
            if is_inert:
                eligible += 1
                is_cube = power(X, (p*p + p + 1) // 3, p) == ONE
                if q_degrees != ([1, 1, 1] if is_cube else [3]):
                    raise ValueError(("splitting mismatch", p, q_degrees))
                cubes += is_cube
        if json.loads(next(rows)) != ["complete", LIMIT] or next(rows, None) is not None:
            raise ValueError("unexpected PARI trailer")
    print(f"{checked} unramified prime rows, {eligible} eligible, {cubes} cubes, all matched")


if __name__ == "__main__":
    run()
