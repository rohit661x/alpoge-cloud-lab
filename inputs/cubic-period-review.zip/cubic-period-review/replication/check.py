#!/usr/bin/env python3
"""Exhaustive replication. Run python3 check.py 1000000. Uses only the standard library."""
import argparse
from math import isqrt

X = (0, 1, 0)
ONE = (1, 0, 0)


def primes_up_to(limit):
    sieve = bytearray(b'\x01') * (limit + 1)
    for k in range(2, isqrt(limit) + 1):
        if sieve[k]:
            sieve[k*k::k] = bytes((limit - k*k)//k + 1)
    return (k for k in range(2, limit + 1) if sieve[k])


def multiply(left, right, p, linear, constant):
    """Product modulo X^3 - linear*X - constant."""
    a, b, c = left
    d, e, f = right
    high = b*f + c*e
    top = c*f
    return ((a*d + constant*high) % p,
            (a*e + b*d + linear*high + constant*top) % p,
            (a*f + b*e + c*d + linear*top) % p)


def power(base, n, p, linear=1, constant=1):
    value = ONE
    while n:
        if n & 1:
            value = multiply(value, base, p, linear, constant)
        base = multiply(base, base, p, linear, constant)
        n //= 2
    return value


def perrin(n, p):
    """Independent companion-matrix powering in the recurrence state basis."""
    matrix = ((0, 1, 0), (0, 0, 1), (1, 1, 0))
    state = (3, 0, 2)
    while n:
        if n & 1:
            state = tuple(sum(a*b for a, b in zip(row, state)) % p for row in matrix)
        columns = tuple(zip(*matrix))
        matrix = tuple(tuple(sum(a*b for a, b in zip(row, col)) % p
                             for col in columns) for row in matrix)
        n //= 2
    return state[0]


def represented(p):
    """For N(z)=p balance positive embeddings by the unit (25+sqrt(621))/2.
    This gives |y| <= sqrt(p/27); negating the conjugate coefficient permits y>=0.
    Check the discriminant of x^2+yx-155y^2-p=0.
    """
    for y in range(isqrt(p//27) + 1):
        discriminant = 621*y*y + 4*p
        root = isqrt(discriminant)
        if root*root == discriminant and (root - y) % 2 == 0:
            return ((root-y)//2, y)
    return None


def check(limit):
    counts = [0, 0]
    examples = [[], []]
    for p in primes_up_to(limit):
        if p % 3 != 1 or pow((-23) % p, (p-1)//2, p) != 1:
            continue
        # Square discriminant forces identity or a three-cycle.
        if power(X, p, p) == X:
            continue
        d = perrin(p-1, p)
        oriented = power(X, (p*p+p+1)//3, p)
        character = pow(d, 2*((p-1)//3), p)
        cubic_split = power(X, p, p, 6, 3) == X
        form = represented(p)
        trivial = character == 1
        if ((d*d + 3*d + 8) % p or oriented != (character, 0, 0)
                or cubic_split != trivial or (form is not None) != trivial):
            raise ArithmeticError((p, d, oriented, character, cubic_split, form))
        bucket = int(trivial)
        counts[bucket] += 1
        if len(examples[bucket]) < 5:
            examples[bucket].append((p, d, character, cubic_split, form))
    print('inclusive limit', limit)
    print('eligible', sum(counts))
    print('3 divides period', counts[0])
    print('3 does not divide period', counts[1])
    print('first five in each class: p, A(p-1) mod p, oriented value, q splits, form witness')
    for group in examples:
        for row in group:
            print(*row)
    return counts


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('limit', type=int, nargs='?', default=1000000)
    args = parser.parse_args()
    if args.limit < 0:
        parser.error('limit must be nonnegative')
    check(args.limit)
