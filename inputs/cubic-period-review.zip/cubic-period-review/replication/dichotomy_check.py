#!/usr/bin/env python3
"""Regression for both parameter families and all three irreducible field configurations."""
from math import isqrt

from check import X, ONE, power as depressed_power, primes_up_to
from family_check import power


def integer_roots(h, b):
    if b == 0:
        roots = {0}
        if h > 0 and isqrt(3*h)**2 == 3*h:
            roots.update((isqrt(3*h), -isqrt(3*h)))
        return roots
    divisors = set()
    for i in range(1, isqrt(abs(b))+1):
        if b % i == 0:
            divisors.update((i, -i, b//i, -(b//i)))
    return {k for k in divisors if k**3-3*h*k == b}


def check_parameters():
    for r in range(-12, 13):
        for s in range(-12, 13):
            h, b = 3+r+s, 9+6*r+6*s+r*s
            # Cauchy bound for all three roots of the monic q.
            bound = 1+max(3*abs(h), abs(b))
            parameters = {k for k in range(-bound, bound+1)
                          if (r+3*k+6)*(s+3*k+6) == (k+3)**3}
            if parameters != integer_roots(h,b):
                raise ArithmeticError((r,s,parameters))


def check_row(r, s, limit):
    h, b = 3+r+s, 9+6*r+6*s+r*s
    disc = r*r*s*s-4*(r**3+s**3)+18*r*s-27
    roots = integer_roots(h,b)
    if r == s or r+s == -2:
        raise ValueError('f reducible over Q')
    eligible = trivial = 0
    for p in primes_up_to(limit):
        if p % 3 != 1 or pow(disc % p,(p-1)//2,p) != 1:
            continue
        if power(X,p,p,r,s) == X:
            continue
        eligible += 1
        cube = power(X,(p*p+p+1)//3,p,r,s) == ONE
        q_split = depressed_power(X,p,p,3*h,b) == X
        if q_split != cube or (roots and not cube):
            raise ArithmeticError((r,s,p))
        trivial += cube
    if not roots and trivial in (0,eligible):
        raise ArithmeticError(('missing both finite-sample outcomes',r,s))
    print(r,s,disc,sorted(roots),eligible,trivial,eligible-trivial)


if __name__ == '__main__':
    check_parameters()
    print('625 parameter pairs matched; all primes through 20000 in each row.')
    print('r s disc(f) rational_q_roots eligible cube noncube')
    for pair in [(3,0),(-5,7),(0,2),(0,-3),(-1,5)]:
        check_row(*pair,20000)
