#!/usr/bin/env python3
"""Finite-field regression for the unit-norm cubic family; stdlib only."""
from collections import Counter

from check import ONE, X, primes_up_to


def mul(left, right, p, r, s):
    # Literal convolution and polynomial long division by X^3-rX^2+sX-1.
    poly = [0]*5
    for i, a in enumerate(left):
        for j, b in enumerate(right):
            poly[i+j] += a*b
    for k in (4, 3):
        lead = poly[k]
        poly[k-1] += r*lead
        poly[k-2] -= s*lead
        poly[k-3] += lead
    return tuple(c % p for c in poly[:3])


def power(base, exponent, p, r, s):
    acc = ONE
    for bit in bin(exponent)[2:]:
        acc = mul(acc, acc, p, r, s)
        if bit == '1':
            acc = mul(acc, base, p, r, s)
    return acc


def check_case(r, s, p, counts, first):
    def exp(x, k):
        return power(x, k, p, r, s)

    def product(a, b):
        return mul(a, b, p, r, s)

    def add(*values):
        return tuple(sum(col) % p for col in zip(*values))

    def scalar(value):
        if value[1:] != (0, 0):
            raise ValueError(('not scalar', r, s, p, value))
        return value[0]

    if any((x**3-r*x*x+s*x-1) % p == 0 for x in range(p)):
        counts['reducible skipped'] += 1
        return
    counts['irreducible tested'] += 1
    n = p*p+p+1
    a = X
    b = exp(a, p)
    c = exp(b, p)
    direct = scalar(exp(a, n//3))
    char_exponent = (p-1)//3
    h = (3+r+s) % p
    big_b = (9+6*r+6*s+r*s) % p
    norms = []
    for orientation, middle in enumerate([b, c]):
        z = add(ONE, a, product(a, middle))
        norm = scalar(exp(z, n))
        ratio = product(middle, exp(a, n-1))
        trace = scalar(add(ratio, exp(ratio, p), exp(ratio, p*p)))
        require(norm == (3+3*(r+s)+r*s-trace) % p, 'trace formula', r,s,p)
        if norm:
            expected = pow(norm, (2 if orientation == 0 else 1)*char_exponent, p)
            require(expected == direct, 'oriented character', r,s,p)
        norms.append(norm)
    require(any(norms), 'both witnesses vanish', r,s,p)
    require(sum(norms) % p == big_b and norms[0]*norms[1] % p == h**3 % p,
            'resolvent coefficients', r,s,p)
    roots = [x for x in range(p) if (x**3-3*h*x-big_b) % p == 0]
    require(len(roots) == (3 if direct == 1 else 0), 'q roots', r,s,p)
    labels = ['cube' if direct == 1 else 'noncube']
    if h == 0:
        labels.append('h zero')
    if norms[0] == 0:
        labels.append('forward witness zero')
    if norms[1] == 0:
        labels.append('reverse witness zero')
    if r == 1 and s == -1:
        require(direct == 1, 'Tribonacci', r,s,p)
        labels.append('Tribonacci')
    for label in labels:
        counts[label] += 1
        first.setdefault(label, (r, s, p, direct, *norms, roots))


def require(condition, label, r, s, p):
    if not condition:
        raise ArithmeticError((label, r, s, p))


def main():
    counts = Counter()
    first = {}
    for p in primes_up_to(97):
        if p % 3 == 1:
            for r in range(-4, 5):
                for s in range(-4, 5):
                    check_case(r, s, p, counts, first)
    print('p <= 97, p = 1 mod 3, -4 <= r,s <= 4 (integer triples)')
    for key, value in counts.items():
        print(key, value)
    print('first examples: r, s, p, oriented value, forward norm, reverse norm, q roots')
    for key, row in first.items():
        print(key, row)


if __name__ == '__main__':
    main()
