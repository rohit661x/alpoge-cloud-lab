import unittest

from check import ONE, X, multiply, perrin, power, primes_up_to, represented


class ReplicationTests(unittest.TestCase):
    def test_recurrence(self):
        terms = [3, 0, 2]
        for n in range(3, 75):
            terms.append(terms[n-2] + terms[n-3])
        self.assertEqual([x % 101 for x in terms], [perrin(i, 101) for i in range(75)])

    def test_prime_sieve(self):
        self.assertEqual(list(primes_up_to(13)), [2, 3, 5, 7, 11, 13])

    def test_quotient_ring(self):
        for p, linear, constant in [(13, 1, 1), (151, 6, 3)]:
            self.assertEqual(power(X, 3, p, linear, constant), (constant, linear, 0))
            acc = ONE
            for i in range(51):
                self.assertEqual(acc, power(X, i, p, linear, constant))
                acc = multiply(acc, X, p, linear, constant)

    def test_form(self):
        self.assertIsNone(represented(13))
        x, y = represented(151)
        self.assertEqual(x*x + x*y - 155*y*y, 151)


if __name__ == '__main__':
    unittest.main()
