"""Verify archive hashes, run all Python checks, and compare with archived transcripts."""
import hashlib
import os
from pathlib import Path
import subprocess
import sys

ROOT = Path(__file__).resolve().parent


def verify_manifest():
    for entry in (ROOT / "SHA256SUMS").read_text().splitlines():
        digest, name = entry.split("  ", 1)
        if hashlib.sha256((ROOT / name).read_bytes()).hexdigest() != digest:
            raise ValueError("SHA-256 mismatch for " + name)
    print("Verified SHA-256 manifest.", flush=True)


def run(directory, args, expected=None):
    path = ROOT / directory
    result = subprocess.run(
        [sys.executable, *args], cwd=path, text=True, capture_output=True,
        env={**os.environ, "PYTHONDONTWRITEBYTECODE": "1"},
    )
    if result.returncode:
        sys.stderr.write(result.stdout + result.stderr)
        raise SystemExit(result.returncode)
    if expected and (path / expected).read_text() != result.stdout:
        raise ValueError("Output differed from " + str(path / expected))
    label = f"{directory}/{' '.join(args)}"
    print("PASS", label, flush=True)


if __name__ == "__main__":
    verify_manifest()
    run("replication", ["-m", "unittest", "test_check"])
    run("replication", ["check.py", "1000000"], "results.txt")
    run("replication", ["family_check.py"], "family-results.txt")
    run("replication", ["dichotomy_check.py"], "dichotomy-results.txt")
    run("pari", ["compare.py"], "comparison.txt")
    run("next-search", ["seven.py", "10000"], "seven-results.txt")
    run("next-search", ["independent_seven.py"], "independent-seven-results.txt")
    run("companion", ["window_grid.py"], "grid-results.txt")
    run("companion", ["-m", "unittest", "test_rh_trace_window"])
    run("companion", ["rh_trace_window.py"], "window-results.txt")
