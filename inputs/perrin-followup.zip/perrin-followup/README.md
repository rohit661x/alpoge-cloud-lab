# Perrin periods and primes in short intervals

Research release dated 21 November 2026. This package includes two review manuscripts, their LaTeX sources and self-contained numerical verification. The period theorem uses classical Kummer theory and unconditional Chebotarev. The prime-count estimate uses the archived Dirichlet critical-line theorem and the published explicit short-interval inequalities.

## Reproduce the results

Run the following commands from the extracted directory. The first requires Python 3.8 or later with its standard library. The second additionally requires PARI/GP on PATH. Pass an absolute executable path with `--gp` if needed.

```sh
python3 verify.py
python3 verify.py --pari
```

The verifier checks SHA-256 for every listed release file, runs the chosen calculations and compares fresh results with the included transcripts. With PARI enabled it also compares the two implementations' six census rows directly. From the same directory, `lean verification/LocalCounts.lean` replays the finite statements with Lean 4.33.1. The Lean file checks selected translation counts and an integer identity for finite geometric sums. The Galois image, density theorem and analytic inequality are supplied as written arguments.

| Files | Contents |
| --- | --- |
| `perrin-periods.pdf`, `perrin-periods.tex` | Unconditional order and index densities for every auxiliary prime congruent to 1 modulo 3, along with a summary for the remaining auxiliary primes. |
| `short-interval.pdf`, `short-interval.tex` | The explicit one-root prime count, endpoints, reduction to eleven residue classes, and comparison of analytic methods. |
| `factor-three.pdf` | Earlier local factor-3 proof cited in the new period manuscript. |
| `verification/` | Two languages independently enumerate held-out primes, plus exact finite Lean checks and a high-precision PARI comparison for Eq. (5.1). Python uses the original project's generic quotient-ring arithmetic in `cubic.py`. |
| `analytic/` | Both directed-rounding implementations, exact transcripts, the earlier window derivation and a page-level comparison of the two consecutive displays in the source. |
| `priority.md` | Primary-source overlap, dissertation page references, and remaining full-text gaps. |
| `invitation.md`, `review-questions.md` | Private drafts for a human referee to review either note. Add the responsible sender and intended recipient before sending. |

The empirical range is 10,000 < p ≤ 1,000,000, disjoint from the initial seven-part pilot through 10,000. The six auxiliary primes were specified before the new computation. Local tools used were Python 3.15.2, PARI/GP 2.17.3 and Tectonic 0.17.0. To rebuild either paper in an editable copy use `tectonic perrin-periods.tex` or `tectonic short-interval.tex`; a first-time TeX installation can require its standard bundle. The released PDFs and code can be read and run offline.

The historical comparison includes Ballot’s complete Arizona dissertation via the university, and available portions and context of two later books. The work is private and has no author byline, publication DOI or outside referee endorsement. Human contributors select authorship, licenses and the final publication venue. The PDFs disclose AI involvement.
