"""Separate evaluation of DGM's unnumbered display immediately before (5.1)."""
from fractions import Fraction as F
from math import ceil, isqrt


def atanh_series(z):
    lo = sum(2*z**(2*i+1)/(2*i+1) for i in range(14))
    return lo, lo + 2*z**29/(29*(1-z*z))


def log_interval(n):
    # Reduction to an argument in [1, 2], using exact integer input.
    k = n.bit_length()-1
    a, b = atanh_series(F(1, 3))
    c, d = atanh_series(F(n-2**k, n+2**k))
    return k*a+c, k*b+d


def audit(j):
    b = 2**256
    h = j*2**133
    x = b-h
    beta = 58
    t = F(beta*x, h)
    assert t > 20 and 6*h < 5*x and x>2**252
    q, phi = 69, 44
    plo, phi_pi = F('3.14'), F(22, 7)
    lq = log_interval(q)[1]
    lqt = log_interval(ceil(q*t))[1]
    root = isqrt(x)
    l0 = log_interval(ceil(q*t/(2*plo)))[1]
    L = (1-2/(phi_pi*beta)+2/(plo*beta**2))*l0
    L += (F('.253')*lq-log_interval(3)[0]/2-log_interval(23)[0]/22
          +F('2.409')+F('1.638')/phi)
    L += (F('1.58')*lqt+F('16.08'))/(beta*t)
    L += (log_interval(ceil(q*q*t))[1]*log_interval(ceil(t))[1]/plo
          +F('3.9')*lq+F('.7')+F('22.7')/phi)*F(h,x)
    L += 4*(1+F(h*h,4*x*x))*(1+F('2.89')/t)*lqt/(plo*beta)
    L += F('.95')+F('3.7')/2**42+2*log_interval(2*x)[1]/root+F('1.7')*h/(x*root)
    return max(0,11*ceil((F(h,phi)-(root+1)*L)/log_interval(b)[1]))


if __name__ == '__main__':
    for j, claimed in [(126,0), (127,14898013315381436822750307473914960820),
                       (128,1016009059325208929842845651764572861),
                       (168,620470965985848807099864620264143597945),
                       (256,1979495588538353671967233436719882857893)]:
        lower = audit(j)
        assert lower >= claimed
        print('j =',j,'independent lower bound =',lower)
