"""Integer/rational certificates for DGM (5.1) and the EHP endpoint comparison."""
from fractions import Fraction as F
from math import ceil, isqrt
from decimal import Decimal, localcontext

B = 2**256
Q = 69
PHI = 44
PI_LO = F('3.14')
BETA = 58


def log_upper(n):
    """Decimal.ln is correctly rounded in ROUND_HALF_EVEN; advance by one ulp."""
    with localcontext() as ctx:
        ctx.prec = 55
        return F(Decimal(n).ln().next_plus())


def field_count(j):
    """Corollary 1.2, using a stronger elementary lower bound on pi."""
    pi_lo = F('3.14159265')
    def atan_sum(inv, terms):
        return sum(F((-1)**k, (2*k+1)*inv**(2*k+1)) for k in range(terms))
    assert 16*atan_sum(5,8)-4*atan_sum(239,3) > pi_lo
    width = j*2**134
    loss = F(0)
    for t in (B-width, B):
        with localcontext() as ctx:
            ctx.prec = 55
            low = F(Decimal(t).ln().next_minus())
        high = log_upper(t)
        root = isqrt(t-1)+1
        loss += root*((1/(2*pi_lo)+3/low)*log_upper(4761)
                      +4*(high/(8*pi_lo)+1/(4*pi_lo)+6/low))
    return max(0, ceil((width/log_upper(B)-loss)/4))


def weighted_count(j):
    h = j * 2**133
    x = B - h
    s = isqrt(x)
    t = F(BETA*x, h)
    assert 6*h <= 5*x and x > (10*PHI*5)**2 and t > 20 and BETA > 20
    L = log_upper(ceil(Q*t))
    L2 = log_upper(ceil(Q**2*t))
    LT = log_upper(ceil(t))
    lq = log_upper(Q)
    # Eq. (5.1) charged to a single reduced residue class.
    leading = (1+2/(PI_LO*BETA)+2/(PI_LO*BETA**2)
               +F('11.56')/(PI_LO*BETA*t))*L + F('.253')*lq
    secondary = (L2*LT/PI_LO+F('3.9')*lq+F('.7')+F('22.7')/PHI
                 +(F('1.58')*L+F('16.08'))/BETA**2
                 +(1+F('2.89')/t)*L/(PI_LO*t))*F(h,x)
    # log(2*pi)<2, x^(-1/6)<2^-42, omega(69)=2.
    assert x > 2**252
    tail = (F('1.53') + log_upper(3)/2 + log_upper(23)/22
            +F('1.638')/PHI+4/(PI_LO*BETA)
            +F('3.7')/2**42+2*log_upper(2*x)/s+F('1.7')*h/(x*s))
    loss = leading + secondary + tail
    per_class = max(0,ceil((F(h,PHI)-(s+1)*loss)/log_upper(B)))
    return 11*per_class


def ehp_fails(j):
    width = j*2**134
    a = B-width
    # Both endpoint errors exceed 8*sqrt(a)-238 by Theorem 1.
    # li(B)-li(a) <= width/log(a), log(a)>175.
    assert a > 2**255 and F(69,100)*255 > 175
    return F(width,175*PHI) < 2*(8*isqrt(a)-238)


if __name__ == '__main__':
    for j in (256,168,128,127):
        print(f'j={j} field lower count={field_count(j)} DGM lower count={weighted_count(j)} EHP endpoint lower is negative={ehp_fails(j)}')
    print('first positive j for this DGM certificate:',next(j for j in range(1,257) if weighted_count(j)))
