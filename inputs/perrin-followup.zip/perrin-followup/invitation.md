**Subject** Request for a mathematical reading of a Perrin-period density and a short-interval estimate

Dear [Name],

I am preparing two notes about the Perrin recurrence. The first computes order and index densities for the Perrin unit on specified Frobenius classes. The second counts primes for which an associated degree-nine polynomial has exactly one root, using an explicit bound for short intervals in arithmetic progressions.

Would you be willing to check the argument closest to your interests? I have attached the notes, the numerical certificate and four focused questions. A response on even one question would help, especially a counterexample, a missing hypothesis or a reference that already proves the stated specialization.

Best regards,  
[Sender]
