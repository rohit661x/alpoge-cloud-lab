# Questions for an independent reader

1. **Division-field image.** For prime ℓ ≡ 1 (mod 3), does the norm argument for the real Perrin unit, together with the action of S₃ on its conjugates, establish full rank two modulo ℓ? Does the commutator argument justify the cyclotomic intersection used to lift this image through every ℓ-power level?

2. **From Frobenius to the period.** Conditional on an inert prime p whose residue has order three modulo ℓ, do the fixed-point count and the valuation tail imply that the period is coprime to ℓ with relative density 1/(ℓ+1)? Is there a prior theorem computing this same conditional numerical density for the Perrin unit?

3. **Analytic input.** For q = 69, β = 58 and T = βx/h, is every hypothesis of the unnumbered inequality preceding Eq. (5.1) of Dudek–Grenié–Molteni satisfied? Please check the sign of the conductor prime-divisor term through Eqs. (5.1) and (5.2), and whether a correction or later edition bears on this use.

4. **Certified count.** Does division of each progression's log-weighted prime sum by log(2²⁵⁶), followed by integer rounding and addition over eleven classes, give the asserted count in (2²⁵⁶−127·2¹³⁴, 2²⁵⁶]? Please check the mapping from polynomial roots to these classes and the directions of all endpoint, square-root and logarithm bounds.
