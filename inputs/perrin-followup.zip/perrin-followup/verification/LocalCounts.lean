import Std

/-! Finite arithmetic for order-three Frobenius components.
    The division-field image, Chebotarev, and passage to densities are external. -/
namespace LocalCounts

set_option maxRecDepth 10000
set_option maxHeartbeats 10000000

/-- Sum f(0),...,f(n-1). Two nested sums run over all translations exactly once. -/
def sumFirst (f : Nat → Nat) : Nat → Nat
  | 0 => 0
  | n + 1 => sumFirst f n + f n

/-- For v=(x,y,z) with x+y+z=0 mod m, compute whether
    (1+A+A²)v=0, where A(v)=c*(y,z,x). -/
def translationTest (m c x y : Nat) : Nat :=
  let z := (m - ((x + y) % m)) % m
  let d := (c*c) % m
  if (x + c*y + d*z) % m = 0 ∧
     (y + c*z + d*x) % m = 0 ∧
     (z + c*x + d*y) % m = 0 then 1 else 0

/-- A lift (v,(P,c)) cubes to one iff the scalar cubes to one and
    the norm operator annihilates v. P is the cycle (x,y,z) ↦ (y,z,x). -/
def cubeCount (m c : Nat) : Nat :=
  if c^3 % m = 1 then
    sumFirst (fun x => sumFirst (translationTest m c x) m) m
  else 0

theorem modulus_seven : cubeCount 7 2 = 7 ∧ cubeCount 7 4 = 7 := by decide
theorem modulus_forty_nine : cubeCount 49 18 = 49 ∧ cubeCount 49 30 = 49 := by decide
theorem modulus_thirteen : cubeCount 13 3 = 13 ∧ cubeCount 13 9 = 13 := by decide

/-- Six of seven lifts of either class have valuation exactly one.
    The seventh has p²+p+1 divisible by 49. -/
def nextLiftCount (c : Nat) : Nat :=
  sumFirst (fun k =>
    let p := c + 7*k
    if (p*p+p+1) % 49 = 0 then 1 else 0) 7

theorem exceptional_lifts :
    nextLiftCount 2 = 1 ∧ nextLiftCount 4 = 1 ∧
    30 % 7 = 2 ∧ (30*30+30+1) % 49 = 0 ∧
    18 % 7 = 4 ∧ (18*18+18+1) % 49 = 0 := by decide

/-- Conditional on the stated base component the fractions of vanishing
    translations are 1/7 and 1/49, checked by cross multiplication. -/
theorem conditional_ratios :
    7 * cubeCount 7 2 = 7^2 ∧ 7 * cubeCount 7 4 = 7^2 ∧
    49 * cubeCount 49 18 = 49^2 ∧ 49 * cubeCount 49 30 = 49^2 := by decide

/-- Exact finite partial sums behind the conditional density 1/8:
    sum_{t=1}^n 6/49^t = (1-49^(-n))/8.
    The numerator is represented over denominator 49^n. -/
def numerator : Nat → Nat
  | 0 => 0
  | n + 1 => 49 * numerator n + 6

theorem partial_sum_identity (n : Nat) : 8 * numerator n + 1 = 49^n := by
  induction n with
  | zero => decide
  | succ n ih =>
    rw [numerator, Nat.pow_succ]
    omega

end LocalCounts

#print axioms LocalCounts.modulus_seven
#print axioms LocalCounts.modulus_forty_nine
#print axioms LocalCounts.modulus_thirteen
#print axioms LocalCounts.exceptional_lifts
#print axioms LocalCounts.conditional_ratios
#print axioms LocalCounts.partial_sum_identity
