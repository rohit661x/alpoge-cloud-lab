"""Seven-adic and other local order statistics for rational inert Perrin primes."""
import argparse
from collections import Counter

from cubic import ONE, X, power, primes_up_to

AUXILIARY = (7, 13, 19, 31, 37, 43)


def inert(p):
    # With square nonzero discriminant the only possible types are 111 and 3.
    if p == 2:
        return True
    return pow(-23 % p, (p-1)//2, p) == 1 and power(X, p, p) != X


def valuations(p, ell, size):
    exponent = size
    t = 0
    while exponent % ell == 0:
        exponent //= ell
        t += 1
    component = power(X, exponent, p)
    w = 0
    while component != ONE and w < t:
        component = power(component, ell, p)
        w += 1
    if component != ONE:
        raise ArithmeticError(("root order exceeds norm-one group", p, ell))
    return t, w


def census(lower, upper, auxiliary=AUXILIARY):
    cells = {ell: Counter() for ell in auxiliary}
    total = 0
    for p in primes_up_to(upper):
        if p <= lower or not inert(p):
            continue
        total += 1
        size = p*p + p + 1
        for ell in auxiliary:
            if size % ell:
                continue
            t, w = valuations(p, ell, size)
            cells[ell][t, w] += 1
    return total, cells


def summarize(cell):
    eligible = sum(cell.values())
    index = sum(count for (t, w), count in cell.items() if t > w)
    period = sum(count for (t, w), count in cell.items() if w > 0)
    both = sum(count for (t, w), count in cell.items() if 0 < w < t)
    return eligible, index, period, both


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--lower", type=int, default=10000)
    parser.add_argument("--upper", type=int, default=1000000)
    args = parser.parse_args()
    if not 0 <= args.lower < args.upper:
        parser.error("use 0 <= lower < upper")
    total, cells = census(args.lower, args.upper)
    print(f"interval ({args.lower}, {args.upper}], inert primes {total}")
    print("ell eligible index period both")
    for ell, cell in cells.items():
        print(ell, *summarize(cell))
    print("ell t w count (t is v_ell(N), w is v_ell(W))")
    for ell, cell in cells.items():
        for (t, w), count in sorted(cell.items()):
            print(ell, t, w, count)


if __name__ == "__main__":
    main()
