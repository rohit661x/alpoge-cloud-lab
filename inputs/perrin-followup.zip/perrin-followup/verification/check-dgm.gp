\\ Independent numerical check against the displayed equation, with its exact constants.
\\ This high-precision consistency check complements the directed rational certificate.
default(realprecision,100);
check_dgm(j,bound) = {
  my(b=2^256,h=j*2^133,x=b-h,q=69,phi=eulerphi(q),beta=58,T=beta*x/h);
  my(c1=(1+2/(Pi*beta)+2/(Pi*beta^2)+4*2.89/(Pi*beta*T))*log(q*T)+0.253*log(q));
  my(c2=(log(q^2*T)*log(T)/Pi+3.9*log(q)+0.7+22.7/phi+(1.58*log(q*T)+16.08)/beta^2+(1+2.89/T)*log(q*T)/(Pi*T))*h/x);
  my(c3=1.53+log(3)/2+log(23)/22+1.638/phi+2*log(2*Pi)/(Pi*beta)*(1-1/beta)+3.7*x^(-1/6)+2*log(2*x)/sqrt(x)+1.7*h/x^(3/2));
  my(direct=11*max(0,ceil((h/phi-sqrt(x)*(c1+c2+c3))/log(b))));
  if(direct<bound,error("claimed bound exceeds direct evaluation at j=",j));
  print("j=",j," direct=",direct," conservative=",bound);
}
check_dgm(256,1979495588538353671967233436719882857893);
check_dgm(168,620470965985848807099864620264143597945);
check_dgm(128,1016009059325208929842845651764572861);
check_dgm(127,0);
quit
