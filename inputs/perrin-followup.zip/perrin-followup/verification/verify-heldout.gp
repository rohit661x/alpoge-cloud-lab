\\ Run with gp -fq verify-heldout.gp. Output columns are comma-separated.
check_counts(lower, upper) = {
  my(ells = [7,13,19,31,37,43], counts = matrix(#ells, 4));
  my(f = x^3-x-1);
  forprime(p = lower+1, upper,
    my(N = p^2+p+1);
    if(!sum(i=1,#ells,N%ells[i] == 0), next);
    my(fp = Mod(1,p)*f);
    if(!polisirreducible(fp), next);
    my(a = ffgen(fp,'a));
    if(a^N != 1, error("norm-one check failed at ",p));
    for(i=1,#ells,
      my(ell=ells[i]);
      if(N%ell, next);
      my(t=valuation(N,ell));
      my(has_index=(a^(N/ell) == 1));
      my(has_period=(a^(N/ell^t) != 1));
      counts[i,1]++;
      counts[i,2]+=has_index;
      counts[i,3]+=has_period;
      counts[i,4]+=has_index*has_period;
    );
  );
  print("ell,eligible,index,period,both");
  for(i=1,#ells,
    print(ells[i],",",counts[i,1],",",counts[i,2],",",counts[i,3],",",counts[i,4]);
  );
}
check_patterns() = {
  my(examples=[151,163,9781], expected=[[3,3,3,3,3,3,3],[21],[3,3,3,3,3,3,3]]);
  for(i=1,#examples,
    my(p=examples[i], factors=factormod(x^21-x^7-1,p));
    my(degrees=vector(matsize(factors)[1],j,poldegree(factors[j,1])));
    if(degrees != expected[i], error("factor pattern failed at ",p));
    print("p=",p," factor degrees=",degrees);
  );
}
check_patterns();
check_counts(10000,1000000);
quit
