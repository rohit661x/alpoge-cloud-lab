"""Re-run the checks in this release and compare all stored transcripts."""
import argparse
import hashlib
import os
from pathlib import Path
import subprocess
import sys

ROOT = Path(__file__).resolve().parent
ENV = {**os.environ, "PYTHONDONTWRITEBYTECODE": "1"}


def check_files():
    for line in (ROOT / "SHA256SUMS").read_text().splitlines():
        digest, name = line.split("  ", 1)
        if hashlib.sha256((ROOT / name).read_bytes()).hexdigest() != digest:
            raise ValueError("SHA-256 mismatch for " + name)
    print("PASS release manifest", flush=True)


def replay(command, folder, transcript=None):
    result = subprocess.run(command, cwd=ROOT / folder, env=ENV, text=True,
                            capture_output=True, check=False)
    if result.returncode or (command[0] != sys.executable and result.stderr.strip()):
        sys.stderr.write(result.stdout + result.stderr)
        raise RuntimeError("check failed: " + " ".join(command))
    if transcript and result.stdout != (ROOT / folder / transcript).read_text():
        raise ValueError("transcript differs: " + str(Path(folder) / transcript))
    print("PASS", command[-1], flush=True)
    return result.stdout


def run(args):
    check_files()
    py = [sys.executable, "-B"]
    census = replay(py + ["census.py"], "verification", "census.txt")
    replay(py + ["prime_windows.py"], "analytic", "results.txt")
    replay(py + ["audit_preceding_inequality.py"], "analytic", "audit-output.txt")
    replay(py + ["-m", "unittest", "test_rh_trace_window"], "analytic")
    if args.pari:
        pari = replay([args.gp, "-fq", "verify-heldout.gp"], "verification", "heldout.txt")
        replay([args.gp, "-fq", "check-dgm.gp"], "verification", "dgm.txt")
        rows = [line.replace(",", " ") for line in pari.splitlines() if line[:1].isdigit()]
        summary = census.split("ell eligible index period both\n", 1)[1].split("ell t w count", 1)[0]
        if rows != summary.splitlines():
            raise ValueError("Python and PARI disagree on a held-out count")
        print("PASS direct comparison of all six Python and PARI rows", flush=True)


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--pari", action="store_true", help="also run fresh PARI/GP computations")
    parser.add_argument("--gp", default="gp", help="PARI/GP executable path")
    run(parser.parse_args())
