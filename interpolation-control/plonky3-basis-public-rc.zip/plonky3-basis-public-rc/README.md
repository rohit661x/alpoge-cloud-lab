# Converting field bases in Plonky3

Release candidate 0.1.0-rc.1, November 22, 2026. The [research brief](study.pdf) presents the results and the limits of each claim. The strongest applications are a repaired cross-degree wire convention and moving coordinate conversion through base-field-linear interpolation. The performance evidence comes from two hardware environments. The native proof-transport and scalar fan-out measurements are local to the Apple M5 Pro.

## Reproduce the evidence

Run `python3 -B verify_data.py` from this archive with Python 3.10 or later, without optimized mode. It verifies the bundle's SHA-256 manifest, checks the remote code hashes, regenerates the number-theoretic certificates, checks the optimizer against exhaustive enumeration, and recalculates both machines' timing summaries, the retrospective decisions and the frozen fan-out predictions. This command uses only the Python standard library and does not modify the archived evidence.

Use `cargo build --release --locked --manifest-path tower-native/Cargo.toml` to build the tower interoperability CLI. Its crate README explains strict encode/decode, legacy and repaired profiles and the trace/norm regression. Run `python3 tower-native/verify_cli.py tower-native/target/release/tower-regression` to verify all archived native fixtures. The four benchmark directories document their exact release flags, sample counts and commands. To time a new run without modifying the saved dataset, use an extra working copy of the relevant experiment. Dependencies are pinned through Cargo.lock. Most timing magnitudes will vary by host. The independent polynomial-quotient verification can be replayed with PARI/GP in review/formal.

| Directory | Contents |
|---|---|
| tower-native, review | Native Rust CLI, profile-dependent wire vectors, mixed-degree trace/norm, higher-degree lifting derivation, Python certificates, PARI/GP verification and prior-art review |
| catalog | General Python generator and verifier, exhaustive ten-prime cohort and pair-specific example |
| linear, fri | Native Rust interpolation and multi-layer Plonky3 FRI tests with local raw timings and summaries |
| proof | Native Fibonacci STARK proving, three transport routes, bytes, negative controls, verification and six retained paired repetitions per case |
| placement, fanout | Exact two-basis placement solver, exhaustive small graphs, retrospective sample split, frozen prospective assignments and native synthetic benchmarks |
| remote | Completed GitHub Actions x86 run, source hashes, selected runner metadata, unmodified raw CSVs and within-host comparisons |
| history | Curated historical scalar-kernel evidence and replay instructions |
| paper | Source of the accompanying five-page research brief |

The shared polynomial convention is field-specific in its semantics. BabyBear and KoalaBear have different characteristics. The algebra uses separate maps within each field. At a wire boundary record field, degree and coordinate profile. The old scalar experiments use their original map for each degree. The new coherent profiles fix mixed-degree diagrams and were checked on field elements, trace and norm. The whole-proof benchmark uses the established single-degree convention per proof. Cross-profile proof migration would additionally require consistent public protocol constants, commitments and transcript encoding.

## Claims and review

Both CPU environments reproduced the direction of the interpolation and multi-layer FRI effects. The runs cover the supplied arrays, challenges and implementations. Code paths that fuse conversion into another kernel or use a fully shared prover deserve separate testing. The [cloud replay instructions](remote/README.md) reproduce the measured workloads from this archive. The raw records and source hashes are included. The prior-art search records established algorithms and specific overlaps. No production security designation, publication priority or general whole-prover speed gain is claimed.

## Attribution and release status

The archive includes [upstream attribution and notices](THIRD-PARTY.md). The responsible authors and distribution terms for the original paper, software and data await approval. OpenAI Codex and GPT-6.2 Astra agents were used in designing the experiments, deriving and checking the maps, implementing code, running the benchmarks, and drafting the text. This candidate has not undergone independent human peer review.
