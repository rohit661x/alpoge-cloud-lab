# Third-party material

## Plonky3 0.8.0

Plonky3's package manifests declare `MIT OR Apache-2.0`. The original MIT notice reads “Copyright (c) 2022 The Plonky3 Authors.” Both upstream license files are included verbatim in [third-party/plonky3](third-party/plonky3). Their scope here is the upstream Plonky3 material. [Pinned upstream repository](https://github.com/Plonky3/Plonky3/tree/a21e3ed42905040ad49c519e402f018381c12d0c)

| Files in this source package | Upstream material and changes |
|---|---|
| `fri/src/params.rs`, `fanout/src/params.rs`, `tower-native/src/params.rs`, `history/crate/src/bin/bench_support/params.rs` | These files adapt the BabyBear and KoalaBear field-marker implementations and reproduce the native base-field two-adic generator and small-root tables. The shared markers forward native Montgomery and packed parameters. Their extension relation uses 37, and the extension generator and two-adic extension roots are expressed in the shared coordinates. [BabyBear field parameters](https://github.com/Plonky3/Plonky3/blob/a21e3ed42905040ad49c519e402f018381c12d0c/baby-bear/src/baby_bear.rs) · [KoalaBear field parameters](https://github.com/Plonky3/Plonky3/blob/a21e3ed42905040ad49c519e402f018381c12d0c/koala-bear/src/koala_bear.rs) · [Montgomery field traits](https://github.com/Plonky3/Plonky3/blob/a21e3ed42905040ad49c519e402f018381c12d0c/monty-31/src/data_traits.rs) |
| `proof/src/main.rs` | The Fibonacci AIR, two-column trace, public endpoints and two-adic proving configuration follow the upstream Fibonacci test. This harness exercises two fields and extension degrees, builds traces of selectable length, changes the query count, measures three transport routes and adds independent tamper checks. [Upstream Fibonacci test](https://github.com/Plonky3/Plonky3/blob/a21e3ed42905040ad49c519e402f018381c12d0c/uni-stark/tests/fib_air.rs) |
| `fri/src/main.rs` | The benchmark calls the dependency's `FriFoldingStrategy::fold_matrix` implementation for two-adic folds and supplies its own scheduling, representation conversions and timing controls. [Two-adic fold implementation](https://github.com/Plonky3/Plonky3/blob/a21e3ed42905040ad49c519e402f018381c12d0c/fri/src/two_adic_pcs.rs) |

### Provenance checks

The SHA-256 digests of the published 0.8.0 crate archives for `p3-baby-bear`, `p3-koala-bear`, `p3-monty-31`, `p3-fri` and `p3-uni-stark` matched their entries in `proof/Cargo.lock`. The `.cargo_vcs_info.json` inside each verified archive identifies the same Git commit, `a21e3ed42905040ad49c519e402f018381c12d0c`, and the package-specific source directory. The repository's complete recursive tree at that commit lists two license files and no separate NOTICE file.

| Included file | Upstream Git blob ID | SHA-256 of supplied bytes |
|---|---|---|
| [LICENSE-MIT](https://github.com/Plonky3/Plonky3/blob/a21e3ed42905040ad49c519e402f018381c12d0c/LICENSE-MIT) | `ae8393261a5c288d5efe1208b7ea3de22b861f84` | `d6543a1b0a0a51d10b5f8c389324c7dfeba556b7f39815efd292927bde808700` |
| [LICENSE-APACHE](https://github.com/Plonky3/Plonky3/blob/a21e3ed42905040ad49c519e402f018381c12d0c/LICENSE-APACHE) | `1e5006dc141e22213c898c27abaded8d936c32f0` | `3708458dee7f359ac6c9c5558023ed481be87e5372c43ebd7f2ca7ad23c12026` |

External crates are resolved through each experiment's Cargo manifest and lockfile. Their published packages supply their respective license declarations.
