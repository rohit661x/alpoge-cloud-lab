# Mathematical census of two-adic prime fields

Exactly ten primes satisfy 2^27 < p < 2^31 and 2^24 divides p−1. The least prime quadratic nonresidue common to all ten is **3229**. Exhaustive trial division certified primality for each p = 1+k·2^24, 8 ≤ k ≤ 127. The ascending prime search tested all 457 primes through 3229 using Euler's criterion in the ten fields. The default cap was 100000, inclusive. With cap 3228 the tool exhausts all 456 prime candidates and returns an explicit incomplete-search status. This finite computation needs no hypothesis about the distribution of primes.

| p | Least positive native nonsquare w |
|---:|---:|
| 167772161 | 3 |
| 469762049 | 3 |
| 754974721 | 11 |
| 1107296257 | 5 |
| 1224736769 | 3 |
| 1711276033 | 5 |
| 1811939329 | 11 |
| 2013265921 | 11 |
| 2113929217 | 5 |
| 2130706433 | 3 |

The census defines w as the least positive nonsquare at each p. It supplies mathematical binomial presentations and makes no claim that a STARK implementation uses these ten fields. For each p and d in {1,2,4,8,16,32,64}, the JSON gives the exponent r and scale t for u_d ↦ t x_d^r, with u_d^d = W and x_d^d = w. At d=1 the anchor is (0,W mod p). At each doubling the generator chooses the smaller of the two possible square roots. An independently evaluated monomial-coordinate formula checks inclusion on every parent basis vector, in total 630 for the full census, as well as the generator equation for every row. The verifier rechecks field primality, the least shared prime W, coordinates and canonical root signs. The irreducibility argument follows from p ≡ 1 modulo 4 and the two quadratic nonresidues as explained in the dyadic lifting derivation.

Running the same algorithm on BabyBear and KoalaBear alone selects **37**. The deterministic BabyBear quartic/octic pair (3,699698306), (3,305087007) preserves the earlier octic map. The KoalaBear pair (1,168445237), (5,862755065) preserves the earlier quartic map. Thus fixing a single anchor rule picks different repair conventions in the two fields. The ten-field census uses 3229 throughout and has its own profiles.

Run from this directory with Python 3.9 or newer.

```sh
python3 tower_catalog.py --census
python3 tower_catalog.py --field 2013265921:11 --field 2130706433:3 --cap 100000 --degree 64
python3 tower_catalog.py --verify census.json
python3 tower_catalog.py --verify bear-pair.json
python3 check_catalog.py
```

The general input accepts distinct primes below 2^31 congruent to 1 modulo 4, native nonsquares given as canonical residues, and power-of-two degrees up to 4096. The cap limits the parameter search and is independent of the tower-lifting theorem. Integer trial division favors small finite searches. The verifier validates a certificate for the supplied field list; regenerating the census also checks that the list is complete. verifier-log.txt records reproduction, cap exhaustion, and rejection of five deliberately corrupted certificates, including a mathematically valid noncanonical sign.
