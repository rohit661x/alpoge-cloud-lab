"""Rebuild the recorded profiles, test the cutoff and reject corrupt certificates."""
import json
from copy import deepcopy
from pathlib import Path
from tower_catalog import census, generate, verify

here = Path(__file__).resolve().parent
full = json.loads((here / 'census.json').read_text())
pair = json.loads((here / 'bear-pair.json').read_text())
assert generate(census(),100000,64)==full
assert generate([(2013265921,11),(2130706433,3)],100000,64)==pair
assert len(full['fields'])==10 and full['W']==3229 and full['prime_candidates_tested']==457
assert pair['W']==37
cutoff = generate(census(),3228,64)
assert cutoff['status']=='cap_exhausted' and cutoff['prime_candidates_tested']==456 and verify(cutoff)
for name in ('wrong_W','corrupt_scale','wrong_exponent','opposite_root','wrong_status'):
    bad=deepcopy(full)
    row=bad['fields'][0]['levels'][-1]
    if name=='wrong_W':
        bad['W']=17
    elif name=='wrong_status':
        bad['status']='cap_exhausted'
    elif name=='corrupt_scale':
        row['t']+=1
    elif name=='wrong_exponent':
        row['r']^=2
    else:
        row['t']=bad['fields'][0]['p']-row['t']
    try:
        verify(bad)
    except ValueError as error:
        print('rejected',name,str(error))
    else:
        raise AssertionError(name)
print('10-field census and pair regenerated; cap=3228 correctly exhausted; all checks passed')
