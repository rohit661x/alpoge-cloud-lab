"""Generate and verify normalized dyadic binomial field profiles. Python 3.9+."""
import argparse
import json
from math import isqrt
from pathlib import Path


def require(ok, message):
    if not ok:
        raise ValueError(message)


def prime(n):
    return n >= 2 and all(n % k for k in range(2, isqrt(n) + 1))


def nonsquare(a, p):
    return pow(a, (p - 1) // 2, p) == p - 1


def root(a, p, w):
    odd = p - 1
    order = 0
    while odd % 2 == 0:
        odd //= 2
        order += 1
    c, x, b = pow(w, odd, p), pow(a, (odd + 1) // 2, p), pow(a, odd, p)
    while b != 1:
        i, y = 1, b*b % p
        while y != 1:
            i, y = i + 1, y*y % p
        require(i < order, "square root invariant")
        z = pow(c, 1 << (order-i-1), p)
        c, x = z*z % p, z*x % p
        b, order = b*c % p, i
    require(x*x % p == a, "bad square root")
    return min(x, p-x)


def census():
    result = []
    for k in range(8,128):
        p = k * 2**24 + 1
        if prime(p):
            w = next(n for n in range(2,p) if nonsquare(n,p))
            result.append((p,w))
    return result


def validate(fields, cap, degree):
    require(fields and len(set(p for p,w in fields)) == len(fields), "distinct nonempty fields")
    require(type(cap) is int and 2 <= cap < 2**31, "supported cap: 2 through 2^31-1")
    require(type(degree) is int and 1 <= degree <= 4096 and degree & (degree-1)==0,
            "degree must be a power of two up to 4096")
    for p,w in fields:
        require(type(p) is int and 2 < p < 2**31 and p % 4 == 1 and prime(p), "unsupported prime")
        require(type(w) is int and 0 < w < p and nonsquare(w,p), "invalid native nonsquare")


def search(fields,cap):
    tested = 0
    for n in range(2,cap+1):
        if prime(n):
            tested += 1
            if all(nonsquare(n,p) for p,w in fields):
                return n,tested
    return None,tested


def generate(fields,cap,degree):
    validate(fields,cap,degree)
    W,tested = search(fields,cap)
    doc = dict(cap=cap, degree=degree, status="found" if W else "cap_exhausted",
               W=W, prime_candidates_tested=tested, fields=[])
    for p,w in fields:
        levels = []
        if W:
            d,r,t = 1,0,W%p
            while True:
                levels.append(dict(d=d,r=r,t=t))
                if d == degree:
                    break
                e = int(nonsquare(t,p))
                r,t = r+e*d,root(t*pow(w,-e,p)%p,p,w)
                d *= 2
        doc['fields'].append(dict(p=p,w=w,levels=levels))
    return doc


def image(i,d,r,t,w,p):
    wraps,index = divmod(i*r,d)
    return index,pow(t,i,p)*pow(w,wraps,p)%p


def verify(doc):
    fields = [(f['p'],f['w']) for f in doc['fields']]
    degree,cap = doc['degree'],doc['cap']
    validate(fields,cap,degree)
    W,tested = search(fields,cap)
    require((W,tested)==(doc['W'],doc['prime_candidates_tested']),"incorrect W or candidate count")
    require(doc['status']==("found" if W else "cap_exhausted"),"incorrect status")
    for f in doc['fields']:
        p,w,levels = f['p'],f['w'],f['levels']
        require(len(levels)==(degree.bit_length() if W else 0),"incorrect level count")
        for j,row in enumerate(levels):
            d,r,t = row['d'],row['r'],row['t']
            require(all(type(v) is int for v in [d,r,t]) and d==2**j and 0<=r<d and 0<t<p,
                    "invalid coordinates")
            require(pow(t,d,p)*pow(w,r,p)%p==W%p,"generator relation")
            if j == 0:
                continue
            require(r%2==1 and 2*t<p,"noncanonical exponent or root sign")
            old = levels[j-1]
            h = d//2
            if h == 1:
                require(t*t*pow(w,r,p)%p == old['t'],"base inclusion")
            for i in range(h):
                k,c = image(i,h,old['r'],old['t'],w,p)
                require((2*k,c)==image(2*i,d,r,t,w,p),"basis inclusion")
    return True


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    group = parser.add_mutually_exclusive_group(required=True)
    group.add_argument('--census',action='store_true')
    group.add_argument('--field',action='append',metavar='p:w')
    group.add_argument('--verify',type=Path)
    parser.add_argument('--cap',type=int,default=100000)
    parser.add_argument('--degree',type=int,default=64)
    args = parser.parse_args()
    if args.verify:
        doc=json.loads(args.verify.read_text())
        verify(doc)
        print("verified",doc['status'])
        return
    fields=census() if args.census else [tuple(map(int,x.split(':'))) for x in args.field]
    doc=generate(fields,args.cap,args.degree)
    verify(doc)
    print(json.dumps(doc,indent=2))


if __name__=='__main__':
    main()
