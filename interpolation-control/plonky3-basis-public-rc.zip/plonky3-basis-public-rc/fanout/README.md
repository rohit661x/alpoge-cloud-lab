# Prospective fan-out placement test

The synthetic KoalaBear quartic DAG takes two shared inputs a and b and returns four shared values a b^K. Each branch is a whole repeated-multiplication kernel. All branches may reuse the same converted a and b. This runtime keeps those two values on the current row only. All sixteen ways to place the four branches are evaluated, along with a seventeenth all-native control that explicitly remaps each input at each branch. The assignment space excludes shared intermediate products across branches, so, for example, one branch cannot reuse a shorter branch's multiplication result.

## Frozen predictions

The planner used only the KoalaBear degree-four observations for calibration seed 205301 from the earlier resident-cost experiment. The included calibration CSV preserves numerical strings from its original inputs.csv and excludes boundary timings. For each K, resident chain and inverse costs are the medians of 11 observations; for each family the forward conversion cost is the pooled median across its four values of K. Costs are rounded to integer picoseconds per row. The input conversions are charged once each if any branch runs native, and each native branch pays one output conversion. All family lengths, the three fresh seed IDs, round/repeat counts and the 16 assignment scores were recorded in prediction.json before initial benchmark compilation. The timestamp and hashes in pre-timing.txt are local records.

Masks use bit j for native placement of the j-th listed branch counting from zero. Mask 0 is all shared, 15 is all native cached, and control method 16 is all native with repeated conversion.

| Family | Lengths | Predicted mask | Predicted native lengths | Model time / all shared | Observed time / all shared, three seed range | Observed time / cached all native |
| --- | --- | ---: | --- | ---: | ---: | ---: |
| Wide | 1, 3, 8, 16 | 14 | 3, 8, 16 | 0.6820 | 0.5983–0.5988 | 0.9539–0.9581 |
| Short | 1, 2, 4, 6 | 12 | 4, 6 | 0.7745 | 0.8170–0.8183 | 0.8919–0.8924 |

For both families the predicted assignment ranked first in each of the three seed processes. The runner-up was mask 12 for wide and mask 14 for short. Its paired time relative to the prediction ranged from 1.0123 to 1.0131 and 1.0461 to 1.0470 respectively. Repeated conversion relative to cached conversion for the all-native route ranged from 1.3388 to 1.3443 for wide, and 1.4435 to 1.4458 for short. The model selected the fastest measured assignment here, while the relative times it forecast differ from the measured ratios.

## Timing and correctness

* Each input array contains 2,048 independently drawn shared pairs. A seed's two families reuse these same pairs. Before timing, every method fills every output and compares all 8,192 values per family against independent shared-field exponentiation a·pow(b,K). All methods run once in shuffled order for this check and warm-up.
* A timed observation makes three complete passes, row-major, over immutable input and a reused output buffer. All methods use the same runtime chain loop and execution order. No timed allocation, transcript, commitment or prover step occurs. The chain is deliberately out of line to prevent cross-branch multiplication elimination. The forward mapping receives an opaque input to prevent the optimizer silently turning the repeated-conversion control into the cached strategy. Shared and cached paths omit calls for conversions they do not require.
* Each family has 17 rounds of all 17 methods. A randomly permuted cyclic Latin square with randomized round order places every method once at each position. Seeds run sequentially in separate processes. summarize.py verifies completeness, sample counts and positional balance. It ranks assignments for each seed/family by median within-round elapsed-time ratio relative to all shared. Each reported pairwise comparison independently uses its respective within-round ratio, so ratios need not multiply exactly.
* The local machine, its compiler and the row-wise scalar call/conversion policy define this workload. The solver optimizes its additive cost model. This experiment tests that model's placement predictions on two selected positive fixtures. It does not measure end-to-end prover performance or establish general optimizer accuracy.

## Replay

Run from the crate directory with Rust 2024 and Python 3. The recorded run used rustc 1.100.0 on the local Apple Silicon host with native CPU features. The published Plonky3 dependencies are locked to 0.8.0.

```sh
python3 freeze.py > replay-prediction.json
cmp prediction.json replay-prediction.json
export RUSTFLAGS='-C target-cpu=native'
cargo build --release --locked
mkdir -p replay-results
for seed in 1609009 2600033 3971723; do
  target/release/fanout-probe "$seed" > "replay-results/seed-$seed.csv" || exit 1
done
python3 summarize.py replay-results > replay-summary.csv
```

results/summary.csv contains all assignments, raw method medians in nanoseconds per complete row, and measured versus predicted rankings. The three seed CSVs preserve every individual timing.
