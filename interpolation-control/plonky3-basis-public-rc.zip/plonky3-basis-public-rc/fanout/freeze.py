from pathlib import Path
import csv,json
from statistics import median
from collections import defaultdict
from hashlib import sha256
from placement import Node,solve,score
costs=defaultdict(list)
for row in csv.DictReader(open('calibration.csv')):
    costs[int(row['length']),row['method']].append(float(row['ns']))
def ps(v): return round(1000*median(v))
results={}
for family,ks in [('wide',[1,3,8,16]),('short',[1,2,4,6])]:
    forward=ps([v for k in ks for v in costs[k,'forward']])
    nodes=[Node(name,fixed='shared',to_native=forward) for name in ['a','b']]
    for i,k in enumerate(ks):
        nodes.append(Node(f'c{i}',('a','b'),native=ps(costs[k,'native_chain']),shared=ps(costs[k,'shared_chain']),to_shared=ps(costs[k,'inverse'])))
    nodes.extend(Node(f'o{i}',(f'c{i}',),fixed='shared') for i in range(4))
    best=solve(nodes)
    mask=sum(1<<i for i in range(4) if best['basis'][f'c{i}']=='native')
    scores={}
    for m in range(16):
        labels={n.name:'shared' for n in nodes}
        for i in range(4):labels[f'c{i}']='native' if (m>>i)&1 else 'shared'
        scores[m]=score(nodes,labels)[0]
    results[family]=dict(lengths=ks,nodes=[vars(n) for n in nodes],scores_ps=scores,predicted=mask,mincut=best)
spec=dict(calibration_seed=205301,input_sha256=sha256(Path('calibration.csv').read_bytes()).hexdigest(),seeds=[1609009,2600033,3971723],items=2048,repeats=3,rounds=17,methods=list(range(17)),families=results)
print(json.dumps(spec,indent=2))
