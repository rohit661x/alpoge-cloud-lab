"""Minimum-cost choice of two representations, with reusable per-value conversions."""
from collections import deque
from dataclasses import dataclass
import argparse
import json


@dataclass(frozen=True)
class Node:
    name: str
    inputs: tuple[str, ...] = ()
    native: int = 0
    shared: int = 0
    to_native: int = 0
    to_shared: int = 0
    fixed: str | None = None


def score(nodes, labels):
    uses = {n.name: set() for n in nodes}
    work = 0
    for n in nodes:
        basis = labels[n.name]
        if n.fixed is not None and n.fixed != basis:
            raise ValueError("assignment violates fixed basis")
        work += getattr(n, basis)
        for argument in n.inputs:
            uses[argument].add(basis)
    conversions = {}
    for n in nodes:
        other = "native" if labels[n.name] == "shared" else "shared"
        if other in uses[n.name]:
            conversions[n.name] = other
            work += getattr(n, "to_" + other)
    return work, conversions


def solve(nodes):
    names = {}
    for idx, n in enumerate(nodes):
        if (n.name in names or any(arg not in names for arg in n.inputs)
                or n.fixed not in (None, "native", "shared")):
            raise ValueError("use unique names, topological order and valid fixed bases")
        if any(type(c) is not int or c < 0 for c in (n.native, n.shared, n.to_native, n.to_shared)):
            raise ValueError("costs must be nonnegative integers")
        names[n.name] = idx
    size = len(nodes)
    source, sink = 3 * size, 3 * size + 1
    inf = 1 + sum(n.native + n.shared + n.to_native + n.to_shared for n in nodes)
    residual = [{} for _ in range(sink + 1)]

    def edge(a, b, cost):
        residual[a][b] = residual[a].get(b, 0) + cost
        residual[b].setdefault(a, 0)

    # Native sits on the source side. Two auxiliaries per producer allow any
    # number of consumers to reuse a single conversion in a given direction.
    for i, n in enumerate(nodes):
        edge(source, i, n.shared + (inf if n.fixed == "native" else 0))
        edge(i, sink, n.native + (inf if n.fixed == "shared" else 0))
        edge(i, size+i, n.to_shared)
        edge(2*size+i, i, n.to_native)
        for arg in set(n.inputs):
            j = names[arg]
            edge(size+j, i, inf)
            edge(i, 2*size+j, inf)

    flow = 0
    while True:
        parents = {source: None}
        queue = deque([source])
        while queue and sink not in parents:
            a = queue.popleft()
            for b, capacity in residual[a].items():
                if capacity and b not in parents:
                    parents[b] = a
                    queue.append(b)
        if sink not in parents:
            break
        b, delta = sink, inf
        while b != source:
            a = parents[b]
            delta = min(delta, residual[a][b])
            b = a
        b = sink
        while b != source:
            a = parents[b]
            residual[a][b] -= delta
            residual[b][a] += delta
            b = a
        flow += delta
    labels = {n.name: "native" if i in parents else "shared" for i, n in enumerate(nodes)}
    cost, conversions = score(nodes, labels)
    if cost != flow:
        raise RuntimeError("min cut disagrees with independently scored assignment")
    return {"minimum_cost": cost, "basis": labels, "convert_once": conversions}


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("model", help="JSON array of nodes in topological order")
    args = parser.parse_args()
    with open(args.model) as f:
        nodes = [Node(**row) for row in json.load(f)]
    print(json.dumps(solve(nodes), indent=2))
