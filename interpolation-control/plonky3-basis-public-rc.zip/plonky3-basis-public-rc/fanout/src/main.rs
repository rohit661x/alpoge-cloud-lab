#[allow(dead_code)]
mod params;
use fanout_probe::BasisMap;
use p3_field::{BasedVectorSpace, PrimeCharacteristicRing, PrimeField32, extension::BinomialExtensionField};
use p3_koala_bear::KoalaBear as F;
use p3_monty_31::MontyField31;
use std::{hint::black_box,time::Instant};
type S=MontyField31<params::SharedKoala>;
type Shared=BinomialExtensionField<S,4>;
type Native=BinomialExtensionField<F,4>;
type Map=BasisMap<F,4>;

// Each call represents one actual demanded conversion. The same opaque input
// boundary in both policies prevents hoisting repeat conversions out of naive.
#[inline(never)]
fn forward(map:&Map,x:Shared)->Native{
    let v=black_box(x);
    let c:&[S]=v.as_basis_coefficients_slice();
    // Both concrete markers use the identical transparent Montgomery representation.
    map.to_native(&std::array::from_fn(|i|unsafe{std::mem::transmute::<S,F>(c[i])}))
}
#[inline(never)]
fn inverse(map:&Map,x:Native)->Shared{
    Shared::new(map.to_shared(&x).map(|c|unsafe{std::mem::transmute::<F,S>(c)}))
}
#[inline(never)]
fn chain<T:Copy+std::ops::MulAssign>(mut a:T,b:T,k:usize)->T {
    for _ in 0..k {a*=b;}
    a
}
fn evaluate(map:&Map, inputs:&[(Shared,Shared)],ks:&[usize;4],method:usize,out:&mut [[Shared;4]]){
    for (&(a,b),row) in inputs.iter().zip(out) {
        let cached=if method>0 && method<16 {Some((forward(map,a),forward(map,b)))} else {None};
        for (j,&k) in ks.iter().enumerate(){
            row[j]=if method==16{
                inverse(map,chain(forward(map,a),forward(map,b),k))
            }else if method & (1<<j)!=0{
                let (an,bn)=cached.unwrap();
                inverse(map,chain(an,bn,k))
            }else{chain(a,b,k)};
        }
    }
}
struct Rng(u64);
impl Rng{
    fn next(&mut self)->u64 {
        self.0=self.0.wrapping_add(0x9e3779b97f4a7c15);
        let mut z=self.0;
        z=(z^(z>>30)).wrapping_mul(0xbf58476d1ce4e5b9);
        z=(z^(z>>27)).wrapping_mul(0x94d049bb133111eb);
        z^(z>>31)
    }
    fn shuffle<T>(&mut self,x:&mut [T]){for i in (1..x.len()).rev(){x.swap(i,self.next() as usize%(i+1));}}
}
fn main(){
    let seed:u64=std::env::args().nth(1).expect("seed").parse().unwrap();
    let mut rng=Rng(seed);
    let mut order=Rng(seed^0xbb67ae8584caa73b);
    let map=Map::new();
    let mut draw=||Shared::new(std::array::from_fn(|_|S::from_u64(rng.next()%u64::from(S::ORDER_U32))));
    let inputs:Vec<_>=(0..2048).map(|_|(draw(),draw())).collect();
    let mut out=vec![[Shared::ZERO;4];inputs.len()];
    println!("seed,family,round,position,method,items,repeats,total_ns");
    for (family,ks) in [("wide",[1,3,8,16]),("short",[1,2,4,6])]{
        // Independently use the field's exponentiation, not the benchmark chain.
        let expected:Vec<_>=inputs.iter().map(|&(a,b)|ks.map(|k|a*b.exp_u64(k as u64))).collect();
        let mut perm:Vec<_>=(0..17).collect();
        order.shuffle(&mut perm);
        for &m in &perm{evaluate(&map,&inputs,&ks,m,&mut out);assert_eq!(out,expected);}
        let mut offsets:Vec<_>=(0..17).collect();
        order.shuffle(&mut offsets);
        for (round,offset) in offsets.into_iter().enumerate(){
            for pos in 0..17 {
                let m=perm[(pos+offset)%17];
                let start=Instant::now();
                for _ in 0..3 {
                    evaluate(black_box(&map),black_box(&inputs),black_box(&ks),black_box(m),black_box(&mut out));
                    black_box(&out);
                }
                let elapsed=start.elapsed().as_nanos();
                println!("{seed},{family},{},{pos},{m},2048,3,{elapsed}",round+1);
            }
        }
    }
}
