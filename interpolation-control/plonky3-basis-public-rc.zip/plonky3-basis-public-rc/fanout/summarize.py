import csv,json,statistics,sys
from pathlib import Path
spec=json.loads(Path('prediction.json').read_text())
root=Path(sys.argv[1])
writer=csv.writer(sys.stdout,lineterminator='\n')
writer.writerow(['seed','family','predicted','method','rank_cached_only','paired_over_shared','paired_over_predicted','paired_over_cached_native','absolute_median_ns_per_row','best_cached_by_shared_ratio'])
for seed in spec['seeds']:
    records=list(csv.DictReader((root/f'seed-{seed}.csv').open()))
    assert len(records)==578
    for family,fixture in spec['families'].items():
        predicted=fixture['predicted']
        measures={}
        positions={}
        for r in records:
            if r['family']!=family:continue
            assert int(r['seed'])==seed and int(r['total_ns'])>0 and int(r['repeats'])==3 and int(r['items'])==2048
            key=int(r['round']),int(r['method'])
            assert key not in measures
            measures[key]=int(r['total_ns'])
            positions[key]=int(r['position'])
        methods=range(17)
        rounds=range(1,18)
        for m in methods:assert sorted(positions[i,m] for i in rounds)==list(methods)
        for i in rounds:assert sorted(positions[i,m] for m in methods)==list(methods)
        def ratio(m,control):
            return statistics.median(measures[i,m]/measures[i,control] for i in rounds)
        ranks=sorted(range(16),key=lambda m:ratio(m,0))
        for m in methods:
            writer.writerow([seed,family,predicted,m,ranks.index(m)+1 if m<16 else '',f'{ratio(m,0):.6f}',f'{ratio(m,predicted):.6f}',f'{ratio(m,15):.6f}',f'{statistics.median(measures[i,m] for i in rounds)/6144:.6f}',ranks[0]])
