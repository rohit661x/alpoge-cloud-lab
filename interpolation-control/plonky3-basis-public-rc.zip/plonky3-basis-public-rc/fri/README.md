# Four-bit reductions through consecutive Plonky3 FRI folds

This standalone Rust crate compares four execution paths for the upstream Plonky3 0.8.0 two-adic FRI fold. The fields are BabyBear and KoalaBear, with extension degrees four and eight. Shared coefficients use the binomial constant 37. Native coefficients use the published field-specific extension. Both are concrete Montgomery marker types. The single-threaded build uses the default crate features and target-native instructions.

The schedules are arity sequences 2–2–2–2, 4–4 and 2–4–2. All reduce the input length by 16. Each layer takes a fresh supplied challenge. Different schedules generally produce different vectors. We compare only execution paths within the same schedule, input and challenges. No commitment, inter-layer injection, Fiat–Shamir transcript, opening or verification is modeled.

## Execution paths

* **shared** runs each fold in the shared basis. **native** runs on inputs and challenges already in native representation and returns native outputs. This is a kernel-residency control.
* **once** maps every input to native, converts one challenge per layer, executes the full chain there and maps the final output to shared.
* **every** repeats the native excursion at every layer including its own input, challenge and output mapping. This implementation allocates a short vector for mapped challenges once per excursion, in addition to whatever allocation reuse the compiler performs. The extra intermediate mapping operations versus once number twice the sum of intermediate vector lengths, excluding both endpoints. This identity counts extension-element maps.
* All timers include output allocation and deallocation and intermediate storage. Conversion scales and input fixtures are prepared once. Challenges and matrices are pseudorandom with base coefficients obtained by modular reduction. At each schedule prefix the program independently evaluates every shared output polynomial at the mapped generator by Horner's rule in the native extension and compares the full vector to a native fold chain. It also checks both endpoint routes return the exact shared vector, input/challenge round trips, and canonical equality of all base-field two-adic generators.

## Reproduce

Use the included Cargo.lock and a Rust 2024 toolchain with the pinned crates available. From this directory run:

```sh
export RUSTFLAGS='-C target-cpu=native'
cargo build --release --locked
mkdir -p replay
for seed in 370817 842771 1301081; do
  target/release/fold-probe "$seed" > "replay/seed-$seed.csv" || exit 1
done
python3 verify.py replay > replay/summary.csv
```

Every seed runs in a separate process. Each shape gets one discarded warmup and two four-round blocks. Within each block a random permutation, cyclic shifts and randomized round order place each method once at every position. All methods reuse the shape's data. Each observation times 16 whole chains at 4,096 inputs or one at 65,536. CSV values are total nanoseconds. For each pair and shape the verifier reports the median of eight within-round time ratios in each process and the median of those three medians. Ratios above one mean the numerator took longer. These are descriptive local measurements. Input working sets and cache residency depend on shape, method and allocation.

The recorded run used Rust 1.100.0 on aarch64-apple-darwin, macOS 27.2.1. See results/interpretation.md for the shape-level range and results/summary.csv for individual values.
