# Multi-layer FRI measurements

Three seeds, 24 configurations and 2,304 timed records completed on the local Apple Silicon host. At every tested shape the shared-resident chain took less elapsed time than either equal-endpoint native route. Converting once took less time than converting at every layer. Resident native/shared ratios ranged from 0.9930 to 1.0064.

Each entry is the range across the eight field, degree and input-size combinations for the specified schedule. Ratios use medians of three seed medians. The summary CSV preserves individual configurations and seed estimates.

| Arity sequence | Once / shared | Every / shared | Every / once | Native / shared |
| --- | ---: | ---: | ---: | ---: |
| 2–2–2–2 | 1.255–1.539 | 1.692–2.416 | 1.348–1.571 | 0.995–1.006 |
| 4–4 | 1.310–1.587 | 1.459–1.845 | 1.111–1.169 | 0.996–1.005 |
| 2–4–2 | 1.285–1.554 | 1.619–2.196 | 1.263–1.418 | 0.993–1.004 |

For starting length N, converting at every layer pays extra intermediate maps of 1.75N, 0.50N and 1.25N for sequences 2–2–2–2, 4–4 and 2–4–2 respectively. The results depend on this scalar element-map implementation and the upstream packed fold. They do not establish a lower bound for fused conversion kernels or measure a full prover.
