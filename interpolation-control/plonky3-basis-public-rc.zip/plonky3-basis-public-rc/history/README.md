# Historical scalar benchmark and calibration data

These scalar measurements supply the M5 Pro chain results in the paper and the training/holdout measurements in the placement and fan-out studies. The benchmark uses Plonky3 0.8.0 and its original degree-specific basis maps. The two mixed-degree repair profiles have their own implementation in [tower-native](../tower-native/README.md).

## Verify the recorded measurements

From the release root, run `python3 -B history/verify_history.py` using Python 3.10 or later. This reads the original scalar CSVs and regenerates the summaries and downstream calibration files in temporary storage. The historical Rust build is optional for this check.

Three primary seeds each produced 31 paired rounds. At K=16 the KoalaBear native excursion took 0.7023 times the shared-resident time at degree four and 0.8359 times at degree eight, savings of 29.8% and 16.4%. Each chain accepts two shared operands, reuses the second throughout, and returns a shared result. A separate sweep used 11 paired rounds at each integer K from 1 through 16 with three fresh seeds. The first K with at least a 5% saving in every process was six for KoalaBear quartics and seven for octics. Every greater tested length qualified. Neither BabyBear degree qualified. Ratios compare the two methods within each round and use the median within each process. The primary estimate takes the median of the three process medians.

There are 4,092 rows in results/run-*.csv and 23,232 in results/sweep. Each file name records the input seed passed to the executable. The seed column identifies the derived round fixture. File provenance matters when regenerating placement/inputs.csv. From the release root, `python3 -B placement/holdout.py --extract history/results/sweep` re-extracts the raw sweep measurements into placement/inputs.csv and rewrites placement/holdout.csv. The history verifier runs this step in temporary storage, compares both CSVs byte-for-byte, and filters the resulting input table to reproduce fanout/calibration.csv. It also regenerates wire/fixtures.json from the independent Python implementation.

## Rebuild the original scalar programs

The recorded scalar timings used rustc 1.100.0, default Cargo release settings with native CPU instructions, arm64 Apple M5 Pro and macOS 27.2.1. From the history directory, with Rust and Python available:

```sh
export RUSTFLAGS='-C target-cpu=native'
cargo build --release --locked --bins --manifest-path crate/Cargo.toml
cargo test --release --locked --manifest-path crate/Cargo.toml
crate/target/release/wire
crate/target/release/bridge encode babybear 4 2,2013265918,4,2013265916
```

Create a fresh directory for new timing results. Run the primary seeds sequentially, then start the length sweep.

```sh
mkdir replay-results
for seed in 370817 842771 1301081; do
  crate/target/release/bench --seed "$seed" --rounds 31 --items 256 --repeats 4096 --chain 16 > "replay-results/run-$seed.csv" || exit 1
done
python3 -B analysis/summarize.py replay-results/run-*.csv --out replay-results/summary.csv
python3 -B analysis/sweep.py --binary crate/target/release/bench --raw-dir replay-results/sweep --out replay-results/crossover.csv
```

The repo-local dependency and fixture paths used by the scalar binaries are preserved. The release's [FRI experiment](../fri/README.md) and [proof transport experiment](../proof/README.md) supply their own raw data and build instructions.
