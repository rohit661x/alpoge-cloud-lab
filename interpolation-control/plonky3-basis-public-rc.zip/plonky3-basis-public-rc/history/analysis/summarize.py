"""Validate raw samples and summarize paired ratios across fresh processes."""
import argparse
import csv
from collections import defaultdict
from pathlib import Path
from statistics import median

# Boundary comparisons always keep the caller's input and output basis fixed.
BASELINES = {
    "shared_mul": "native_mul",
    "control_mul": "native_mul",
    "shared_chain": "native_chain",
    "native_io_shared_mul": "native_mul",
    "native_io_shared_chain": "native_chain",
    "boundary_mul": "shared_mul",
    "boundary_chain": "shared_chain",
}
METHODS = set(BASELINES) | {"native_mul", "native_chain", "forward", "inverse"}
CONFIGS = {(f, d) for f in ("BabyBear", "KoalaBear") for d in (4, 8)}
COLS = ["field", "degree", "method", "baseline", "processes", "median_ns",
        "paired_ratio", "lowest_run_ratio", "highest_run_ratio", "five_percent_rule"]


def process(path):
    rounds = defaultdict(dict)
    positions = defaultdict(set)
    inputs = defaultdict(set)
    with path.open(newline="") as stream:
        for row in csv.DictReader(stream):
            key = row["field"], int(row["degree"]), int(row["round"])
            name = row["method"]
            position = int(row["position"])
            n = int(row["items"]) * int(row["repeats"])
            k = int(row["chain"])
            mul = int(row["multiplications"])
            conv = int(row["conversions"])
            elapsed = int(row["elapsed_ns"])
            value = float(row["ns_per_operation"])
            is_map = name in {"forward", "inverse"}
            is_boundary = name.startswith(("boundary_", "native_io_shared_"))
            if (name not in METHODS or name in rounds[key] or position in positions[key]
                    or not 0 <= position < len(METHODS) or n < 1 or k < 1 or elapsed < 1
                    or (not name.endswith("_chain") and k != 1)
                    or mul != (0 if is_map else n * k)
                    or conv != (n if is_map else 3 * n if is_boundary else 0)
                    or abs(value - elapsed / (mul or conv)) > 0.00000051):
                raise ValueError(f"Invalid sample {key}, {name} in {path}")
            rounds[key][name] = elapsed / (mul or conv)
            positions[key].add(position)
            inputs[key].add(row["seed"])
    if {key[:2] for key in rounds} != CONFIGS:
        raise ValueError(f"Missing field or degree in {path}")
    round_ids = {k[2] for k in rounds}
    if (round_ids != set(range(1, max(round_ids) + 1))
            or len(rounds) != len(round_ids) * len(CONFIGS)):
        raise ValueError(f"Incomplete rounds in {path}")
    times, ratios = defaultdict(list), defaultdict(list)
    for key, methods in rounds.items():
        if methods.keys() != METHODS or len(inputs[key]) != 1:
            raise ValueError(f"Incomplete or unpaired round {key} in {path}")
        for name, value in methods.items():
            group = (*key[:2], name)
            times[group].append(value)
            if name in BASELINES:
                ratios[group].append(value / methods[BASELINES[name]])
    return ({k: median(v) for k, v in times.items()},
            {k: median(v) for k, v in ratios.items()})


def summarize(paths):
    all_times, all_ratios = defaultdict(list), defaultdict(list)
    for path in paths:
        times, ratios = process(path)
        for key, value in times.items():
            all_times[key].append(value)
        for key, value in ratios.items():
            all_ratios[key].append(value)
    for (field, degree, name), times in sorted(all_times.items()):
        ratios = all_ratios[field, degree, name]
        row = [field, degree, name, BASELINES.get(name, ""), len(times), f"{median(times):.3f}"]
        if not ratios:
            yield row + ["", "", "", ""]
            continue
        verdict = "within 5% or mixed"
        if max(ratios) <= .95:
            verdict = "faster in every run"
        elif min(ratios) >= 1.05:
            verdict = "slower in every run"
        yield row + [f"{median(ratios):.4f}", f"{min(ratios):.4f}",
                     f"{max(ratios):.4f}", verdict]


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("csvs", nargs="+", type=Path)
    parser.add_argument("--out", required=True, type=Path)
    args = parser.parse_args()
    if len(set(p.resolve() for p in args.csvs)) != len(args.csvs):
        parser.error("Each process must supply a separate CSV")
    with args.out.open("w", newline="") as stream:
        writer = csv.writer(stream, lineterminator="\n")
        writer.writerow(COLS)
        writer.writerows(summarize(args.csvs))


if __name__ == "__main__":
    main()
