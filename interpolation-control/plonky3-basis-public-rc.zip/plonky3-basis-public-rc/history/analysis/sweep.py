"""Time the unchanged binary for chain lengths 1 through 16 in shuffled order."""
import argparse
import csv
from pathlib import Path
import random
import subprocess
from summarize import summarize

SEEDS = [205301, 405713, 760399]


def run(binary, destination):
    destination.mkdir(parents=True, exist_ok=True)
    for seed in SEEDS:
        lengths = list(range(1, 17))
        random.Random(seed).shuffle(lengths)
        for length in lengths:
            args = [str(binary.resolve()), "--seed", str(seed), "--rounds", "11",
                    "--items", "256", "--repeats", "1024", "--chain", str(length)]
            path = destination / f"k{length:02d}-seed{seed}.csv"
            with path.open("w") as stream:
                subprocess.run(args, stdout=stream, check=True)


def write_summary(directory, output):
    with output.open("w", newline="") as stream:
        writer = csv.writer(stream, lineterminator="\n")
        writer.writerow(["field", "degree", "length", "native_math_shared_io_over_shared_math",
                         "lowest_run_ratio", "highest_run_ratio", "five_percent_rule"])
        for length in range(1, 17):
            paths = [directory / f"k{length:02d}-seed{seed}.csv" for seed in SEEDS]
            for row in summarize(paths):
                if row[2] == "boundary_chain":
                    writer.writerow([row[0], row[1], length, *row[6:]])


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--binary", type=Path)
    parser.add_argument("--raw-dir", type=Path, required=True)
    parser.add_argument("--out", type=Path, required=True)
    args = parser.parse_args()
    if args.binary:
        run(args.binary, args.raw_dir)
    write_summary(args.raw_dir, args.out)


if __name__ == "__main__":
    main()
