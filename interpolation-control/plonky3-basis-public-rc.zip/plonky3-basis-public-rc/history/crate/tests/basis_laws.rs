//! Deterministic arithmetic checks for the map, with independently sampled inputs in each basis.
use p3_baby_bear::BabyBear;
use p3_field::extension::BinomialExtensionField;
use p3_koala_bear::KoalaBear;
use plonky3_native::{BasisMap, BasisParameters};

/// SplitMix64 with a fixed seed. Sampling serves coverage, not cryptography.
struct Stream(u64);
impl Stream {
    fn vector<F: BasisParameters<D>, const D: usize>(&mut self) -> [F; D] {
        core::array::from_fn(|_| {
            self.0 = self.0.wrapping_add(0x9e3779b97f4a7c15);
            let mut n = self.0;
            n = (n ^ (n >> 30)).wrapping_mul(0xbf58476d1ce4e5b9);
            n = (n ^ (n >> 27)).wrapping_mul(0x94d049bb133111eb);
            F::from_u64(n ^ (n >> 31))
        })
    }
}

fn schoolbook<F: BasisParameters<D>, const D: usize>(a: &[F; D], b: &[F; D]) -> [F; D] {
    let mut product = [F::ZERO; D];
    for (i, &x) in a.iter().enumerate() {
        for (j, &y) in b.iter().enumerate() {
            let power = i + j;
            let term = x * y;
            if power < D {
                product[power] += term;
            } else {
                product[power - D] += term * F::from_u32(37);
            }
        }
    }
    product
}

fn laws<F: BasisParameters<D>, const D: usize>() {
    let map = BasisMap::<F, D>::new();
    let mut shared_stream = Stream(0x6c8e9cf570932bd5 ^ F::ORDER_U32 as u64 ^ D as u64);
    let mut native_stream = Stream(0xe26d042f085ab473 ^ F::ORDER_U32 as u64 ^ D as u64);
    let check = |a: [F; D], b: [F; D], native_input: bool| {
        let (x, y, a, b) = if native_input {
            let x = BinomialExtensionField::new(a);
            let y = BinomialExtensionField::new(b);
            (x, y, map.to_shared(&x), map.to_shared(&y))
        } else {
            (map.to_native(&a), map.to_native(&b), a, b)
        };
        for (v, w) in [(a, x), (b, y)] {
            assert_eq!(map.to_native(&v), w);
            assert_eq!(map.to_shared(&w), v);
        }
        for (v, w) in [
            (core::array::from_fn(|i| a[i] + b[i]), x + y),
            (core::array::from_fn(|i| a[i] - b[i]), x - y),
            (schoolbook(&a, &b), x * y),
        ] {
            assert_eq!(map.to_native(&v), w);
            assert_eq!(map.to_shared(&w), v);
        }
    };

    let mut edge = vec![[F::ZERO; D], [-F::ONE; D]];
    edge.push(core::array::from_fn(|i| if i % 2 == 0 { F::ONE } else { -F::ONE }));
    for j in 0..D {
        edge.push(core::array::from_fn(|i| if i == j { F::ONE } else { F::ZERO }));
    }
    for &a in &edge {
        for &b in &edge {
            check(a, b, false);
            check(a, b, true);
        }
    }
    for _ in 0..256 {
        check(shared_stream.vector(), shared_stream.vector(), false);
        check(native_stream.vector(), native_stream.vector(), true);
    }
}

#[test]
fn baby_quartic() { laws::<BabyBear, 4>(); }
#[test]
fn baby_octic() { laws::<BabyBear, 8>(); }
#[test]
fn koala_quartic() { laws::<KoalaBear, 4>(); }
#[test]
fn koala_octic() { laws::<KoalaBear, 8>(); }
