"""Recompute scalar benchmark and downstream calibration evidence in temporary storage."""
import csv
from pathlib import Path
import shutil
from statistics import median
import subprocess
import sys
from tempfile import TemporaryDirectory

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
PRIMARY = (370817, 842771, 1301081)
SWEEP = (205301, 405713, 760399)


def run(script, *args):
    return subprocess.check_output([sys.executable, "-B", str(script), *map(str, args)])


def same(actual, expected):
    if actual != expected.read_bytes():
        raise ValueError(f"Regeneration differs from {expected.name}")


def paired(path, length, rounds):
    """Independently pair complete-chain elapsed time per input pair within each round."""
    samples = {}
    with path.open(newline="") as stream:
        data = list(csv.DictReader(stream))
    if len(data) != 4 * 11 * rounds:
        raise ValueError(f"Unexpected sample count in {path.name}")
    for row in data:
        method = row["method"]
        if method not in ("boundary_chain", "shared_chain"):
            continue
        key = row["field"], int(row["degree"]), int(row["round"]), method
        if key in samples or int(row["chain"]) != length:
            raise ValueError(f"Unexpected chain sample in {path.name}")
        samples[key] = int(row["elapsed_ns"]) / (int(row["items"]) * int(row["repeats"]))
    return {(f,d): median(samples[f,d,r,"boundary_chain"] / samples[f,d,r,"shared_chain"]
                         for r in range(1,rounds+1))
            for f in ["BabyBear","KoalaBear"] for d in [4,8]}


def main():
    raw = HERE / "results"
    paths = [raw / f"run-{s}.csv" for s in PRIMARY]
    summaries = [paired(p,16,31) for p in paths]
    savings = [round(100*(1-median(v["KoalaBear",d] for v in summaries)),1) for d in (4,8)]
    if savings != [29.8,16.4]:
        raise ValueError(f"Unexpected KoalaBear savings {savings}")
    baseline_keys = summaries[0].keys()
    qualifying = {key:[] for key in baseline_keys}
    for k in range(1,17):
        runs = [paired(raw/"sweep"/f"k{k:02d}-seed{s}.csv",k,11) for s in SWEEP]
        for key in baseline_keys:
            if all(run[key] <= .95 for run in runs):
                qualifying[key].append(k)
    if qualifying != {("KoalaBear",4):list(range(6,17)),("KoalaBear",8):list(range(7,17)),
                      ("BabyBear",4):[],("BabyBear",8):[]}:
        raise ValueError(f"Unexpected five-percent crossover lengths {qualifying}")
    with TemporaryDirectory() as temp:
        scratch = Path(temp)
        run(HERE/"analysis/summarize.py",*paths,"--out",scratch/"summary.csv")
        same((scratch/"summary.csv").read_bytes(),raw/"summary.csv")
        run(HERE/"analysis/sweep.py","--raw-dir",raw/"sweep","--out",scratch/"crossover.csv")
        same((scratch/"crossover.csv").read_bytes(),raw/"crossover.csv")
        for name in ("convert.py","make_fixtures.py","checks.txt"):
            shutil.copy(HERE/"wire"/name,scratch/name)
        run(scratch/"make_fixtures.py")
        same((scratch/"fixtures.json").read_bytes(),HERE/"wire/fixtures.json")
        for name in ("holdout.py","placement.py"):
            shutil.copy(ROOT/"placement"/name,scratch/name)
        same(run(scratch/"holdout.py","--extract",raw/"sweep"),ROOT/"placement/holdout-summary.txt")
        for name in ("inputs.csv","holdout.csv"):
            same((scratch/name).read_bytes(),ROOT/"placement"/name)
        with (scratch/"inputs.csv").open(newline="") as source, (scratch/"calibration.csv").open("w",newline="") as output:
            rows=csv.DictReader(source)
            writer=csv.DictWriter(output,fieldnames=rows.fieldnames,lineterminator="\n")
            writer.writeheader()
            for row in rows:
                if (row["seed"]=="205301" and row["field"]=="KoalaBear" and row["degree"]=="4"
                    and row["method"] in ("native_chain","shared_chain","forward","inverse")):
                    writer.writerow(row)
        same((scratch/"calibration.csv").read_bytes(),ROOT/"fanout/calibration.csv")
    print("Verified 4,092 primary and 23,232 sweep timings. KoalaBear K=16 savings: 29.8% (d=4), 16.4% (d=8).")
    print("All-seed five-percent crossovers: K=6 and K=7 respectively; neither BabyBear degree qualified through 16.")
    print("Verified both historical summaries, wire fixtures, downstream placement inputs and decisions, and prospective calibration.")


if __name__=="__main__":
    main()
