"""Canonical integer coefficient vectors, constant coefficient first (Python 3.8+)."""
from dataclasses import dataclass


@dataclass(frozen=True)
class BasisMap:
    p: int
    w: int
    d: int
    r: int
    t: int

    def convert(self, coefficients, *, inverse=False):
        """Map the 37 basis to the W basis; inverse=True reverses the map."""
        if len(coefficients) != self.d:
            raise ValueError(f"expected {self.d} coefficients")
        out = [0] * self.d
        for i in range(self.d):
            carry, k = divmod(self.r * i, self.d)
            scale = pow(self.t, i, self.p) * pow(self.w, carry, self.p) % self.p
            if inverse:
                out[i] = coefficients[k] * pow(scale, -1, self.p) % self.p
            else:
                out[k] = coefficients[i] * scale % self.p
        return out


MAPS = {
    ("BabyBear", 4): BasisMap(2013265921, 11, 4, 3, 58781239),
    ("BabyBear", 8): BasisMap(2013265921, 11, 8, 3, 305087007),
    ("KoalaBear", 4): BasisMap(2130706433, 3, 4, 1, 168445237),
    ("KoalaBear", 8): BasisMap(2130706433, 3, 8, 5, 94536886),
}


def multiply(a, b, modulus, constant):
    """Product modulo X^d - constant using monomial multiplication."""
    d = len(a)
    out = [0] * d
    for i, x in enumerate(a):
        for j, y in enumerate(b):
            carry, k = divmod(i + j, d)
            out[k] += x * y * (constant if carry else 1)
    return [x % modulus for x in out]


def verify():
    for (name, d), m in MAPS.items():
        assert pow(m.t, d, m.p) * pow(m.w, m.r, m.p) % m.p == 37
        basis = [[int(i == j) for i in range(d)] for j in range(d)]
        for a in basis:
            assert m.convert(m.convert(a), inverse=True) == a
            assert m.convert(m.convert(a, inverse=True)) == a
            for b in basis:
                ab = multiply(a, b, m.p, 37)
                assert m.convert(ab) == multiply(m.convert(a), m.convert(b), m.p, m.w)
        a = [(-1)**i * (i + 2) for i in range(d)]
        b = [3*i - 4 for i in range(d)]
        ab = multiply(a, b, m.p, 37)
        assert m.convert(ab) == multiply(m.convert(a), m.convert(b), m.p, m.w)
        assert m.convert(m.convert(a), inverse=True) == [x % m.p for x in a]
        assert m.convert(m.convert(ab), inverse=True) == ab
        print(name, d, "basis products", d*d, "basis round trips", 2*d)
        print("shared A", a, "B", b, "product", ab)
        print("mapped A", m.convert(a), "B", m.convert(b), "product", m.convert(ab))


if __name__ == "__main__":
    verify()
