"""Regenerate independent test vectors with the earlier Python basis implementation."""
import ast
import json
import re
from pathlib import Path
from convert import MAPS, multiply

root = Path(__file__).resolve().parent
original = (root / "checks.txt").read_text().splitlines()

def le(words):
    return b"".join(x.to_bytes(4, "little") for x in words).hex()

def payload(m, a):
    mapped = m.convert(a)
    monty = lambda v: le([c * (1 << 32) % m.p for c in v])
    return dict(shared=a, native=mapped, shared_le=le(a),
                shared_montgomery_le=monty(a), postcard=monty(mapped))

cases = []
for n, ((field, d), m) in enumerate(MAPS.items()):
    p = m.p
    def case(label, a, b):
        a, b = ([x % p for x in v] for v in (a, b))
        product = multiply(a, b, p, 37)
        mapped = m.convert(product)
        assert mapped == multiply(m.convert(a), m.convert(b), p, m.w)
        cases.append(dict(field=field, degree=d, label=label,
                          a=payload(m,a), b=payload(m,b), product=payload(m,product)))
    prev = [[ast.literal_eval(s) for s in re.findall(r'\[[^\]]*\]', line)]
            for line in original[3*n+1:3*n+3]]
    case("previous-dense", *prev[0][:2])
    c = cases[-1]
    assert c["product"]["shared"] == prev[0][2]
    assert [c[k]["native"] for k in ("a","b","product")] == prev[1]
    edge = [0, 1, p-1, p-2, 127, 128, (p-1)//2, 65536][:d]
    case("edge", edge, edge[::-1])
    case("generator", [0,1]+[0]*(d-2), [1]+[0]*(d-1))
    state = 0x38abc4 + p + d
    def vector():
        global state
        out = []
        for _ in range(d):
            state = (1664525*state + 1013904223) % 2**32
            out.append(state % p)
        return out
    for i in range(8):
        case(f"dense-{i}", vector(), vector())
(root / "fixtures.json").write_text(json.dumps(cases, indent=2)+"\n")
