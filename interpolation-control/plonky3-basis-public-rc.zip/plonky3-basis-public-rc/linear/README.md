# Base-field multilinear interpolation with native output

A producer has a table of N extension elements in shared coordinates. A consumer asks for the native coordinates of M multilinear evaluations. The table partitions into M contiguous Boolean cubes of size N/M. Every cube is evaluated at the same point of dimension log2(N/M), with the first variable in the least-significant index bit. This models a full MLE evaluation or the first four rounds of a partial evaluation.

For an F-linear change of basis T and r in the base field F, T(l + r(h-l)) = T(l) + r(T(h)-T(l)). All N-M pair interpolations can therefore run componentwise on shared coordinates, followed by M conversions. Converting early uses N conversions. Both produce the same native-coordinate vector and reuse unmodified input tables. This implementation applies to base-field points. An extension-valued point generally requires extension multiplication in the appropriate basis and mapping its coordinates consistently. The measurements here do not cover that operation.

## Comparators

| Mode | Input | Procedure |
|---|---|---|
| 0 | native | Clone table and fold in place |
| 1 | shared | Convert all N inputs into a new native table, fold in place |
| 2 | shared | Clone shared table, fold in place, convert M outputs |
| 3 | shared | Convert both inputs of each first-layer pair into native coordinates, interpolate directly into half-size scratch, finish in place |
| 4 | shared | Interpolate first-layer pairs directly into half-size shared scratch, finish in place, convert M outputs |
| 5 | native | Interpolate first-layer pairs directly into half-size native scratch, finish in place |

The same scalar coordinate-level Rust interpolation kernel computes all routes, with the release compiler free to vectorize. No path uses hand-tuned packed arithmetic. Every route allocates and returns an owned native vector, leaving the source table reusable. Fused paths avoid a full-size first-layer scratch allocation. Modes 3 and 4 compare the same shared-input/native-output job. Mode 5 represents a different starting point where native coordinates are already available. The timed interval includes result allocation, conversions, interpolation, and disposal of intermediate scratch. It ends before correctness checking and result destruction. Tables, point and basis maps are initialized outside measurements.

For correctness, the driver independently constructs the product Lagrange weight for every cube vertex and sums weighted table entries in the native extension field. The seed determines both the inputs and the evaluation point. All output coordinates are checked before timing and every timed output vector is checked against the same oracle afterward. All three deterministic seeds produced points with every coordinate outside {0,1}.

## Reproduction

Recorded platform aarch64-apple-darwin, rustc 1.100.0 (0ef1bc386), default release profile. From this directory:

```sh
cargo build --release --locked
mkdir -p replay-linear/results
for seed in 1021 4111 7963; do
  target/release/linear-frontier "$seed" > "replay-linear/results/seed-$seed.csv"
done
cp summarize.py replay-linear/
python3 -B replay-linear/summarize.py
```

Cargo supports an additional `--offline` flag when dependencies are cached. All local path dependencies are included. The three seeds run in separate, sequential processes. Within each process and case, a warmup checks all six modes, followed by six paired samples. The order rotates with seed and sample, so each mode occupies each position once per case per process. The result reports medians of the three per-seed medians. Paired speedups are the median of the within-seed paired time ratios, then the median across seeds. The diagnostic minimum and maximum describe variation among these three per-seed ratios. This single-host, warm-table experiment includes no transport or upstream proof engine. The raw nanosecond timings yield microseconds in the summary.

Across 16 cases, matched fused early conversion took 1.811 to 1.965 times the late-conversion time. The simpler full-buffer implementations gave ratios of 1.600 to 1.735. At N=65,536, M=1 and BabyBear degree 4, median fused time was 241.02 µs with early conversion, 121.00 µs with late conversion, and 121.88 µs with native input. The native-resident input already avoids the conversion obligation. The observed improvement therefore depends on an actual shared-coordinate source and a base-field-linear reduction.
