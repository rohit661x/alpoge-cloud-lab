# Where should a computation change basis?

This Python 3.10+ tool assigns each operation of a computation graph to one of two representations. An operation produces one value; each input must be available in that operation's chosen basis. A value may be converted once and the result reused by any number of consumers. A fixed input or output is represented by a node with a required basis. The example uses three consumers of one shared input.

```sh
python3 placement.py fanout.json
python3 -B check.py
python3 -B holdout.py
```

The result includes the assigned basis of every operation, the conversions to cache, and the minimum attainable **modeled** cost. Supply nonnegative integer costs in common units such as picoseconds. Each record contains a unique name, earlier node names as inputs, native and shared execution costs, two directional costs to convert its output, and an optional fixed basis. An omitted cost is zero. Costs may differ between fields, degrees, kernels and output lengths. There is no assumption that conversion in opposite directions has the same cost.

## Why the answer is exact for this model

Put a node on the source side of a cut to compute in native coordinates and on the sink side for shared coordinates. Directed edges source→v and v→sink charge respectively the shared and native operation costs. A sufficiently large cost enforces a required side.

For each producer v introduce two auxiliary vertices. For native-to-shared conversion, add v→a of cost to_shared(v), and a→c of effectively infinite cost for each consumer c. If v is native and any consumer is shared, a must be on the shared side and the cut pays once. Otherwise a can be placed to avoid that cost. For shared-to-native conversion use the reversed construction, with c→b infinite and b→v of cost to_native(v). Optimizing the auxiliaries for any fixed placement gives exactly its required one-time conversion costs. Finite infinity is one more than the sum of all allowed costs. A minimum source/sink cut therefore yields an optimal placement. The dependency order supplies a valid execution order. In the example, one 5-unit conversion serves all three consumers. Charging conversion per consumer would choose 9 units of shared work.

This is a specialization of known network-flow and hypergraph-cut representations. It assumes a reusable converted value, sufficient storage, a single chosen implementation per operation and additive costs. Fusion, eviction, parallel overlap and scheduling-dependent cache effects can change observed time. The Python implementation uses augmenting paths for clarity. [Veldt, Benson and Kleinberg](https://arxiv.org/abs/2001.02817)

## Validation

Brute-force enumeration of all 17,456 feasible assignments for 900 deterministic random DAGs of up to nine nodes agreed with the minimum cut. The measured audit used the prior package's sweep of chains with shared inputs and shared output. For each field, degree and chain length, train costs on seed 205301 using only resident chain times and independent forward/reverse map timings. Predict one choice for the entire chain, then compare against the actual two endpoint-matched implementations on seeds 405713 and 760399. This is a retrospective seed split of an existing single-host dataset. The DAGs with arbitrary fan-out were checked against exact enumeration, while the timed cases were simple chain-placement decisions.

Across 128 held-out field/degree/length/seed decisions, 112 chose the lower paired time exactly. A further nine fell within 5%. Seven exceeded 5% loss against the better measured choice; the largest loss was 12.52%. The model selected KoalaBear quartic native work at lengths 4–16 and octic at 10–16, while the measured 5% crossovers were 6 and 7. Incorporating end-to-end kernel measurements matters when paths fuse operations. The optimizer's exact cost result does not turn isolated costs into an exact runtime predictor.

inputs.csv includes all source measurements used by holdout.py in nanoseconds per map or per whole chain. To reconstruct it, use `python3 holdout.py --extract ../history/results/sweep` from the placement directory using the included historical observations. holdout.csv reports every decision, observed ratio and elapsed-time loss relative to the observed best path.
