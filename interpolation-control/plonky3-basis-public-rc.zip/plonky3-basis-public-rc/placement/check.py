"""Test the cut reduction against enumerating every valid basis assignment."""
from itertools import product
import json
from pathlib import Path
import random
from placement import Node, score, solve

def run():
    rng = random.Random(370917)
    cases = states = 0
    for size in range(1, 10):
        for _ in range(100):
            nodes = []
            for i in range(size):
                args = tuple(n.name for n in nodes if rng.random() < .32)
                nodes.append(Node(str(i), args, *(rng.randrange(11) for _ in range(4)),
                                  fixed=rng.choice([None, None, None, "native", "shared"])))
            candidates = product(*[(n.fixed,) if n.fixed else ("native","shared") for n in nodes])
            costs = [score(nodes, dict(zip((n.name for n in nodes), bs)))[0] for bs in candidates]
            assert solve(nodes)["minimum_cost"] == min(costs)
            cases += 1
            states += len(costs)
    example = json.loads(Path(__file__).with_name("fanout.json").read_text())
    result = solve([Node(**row) for row in example])
    assert result["minimum_cost"] == 5 and result["convert_once"] == {"input":"native"}
    print(f"Verified {cases} deterministic random DAGs against {states} feasible assignments.")
    print("Shared fan-out example: optimum 5 units, one conversion reused by all three consumers.")
if __name__ == "__main__":
    run()
