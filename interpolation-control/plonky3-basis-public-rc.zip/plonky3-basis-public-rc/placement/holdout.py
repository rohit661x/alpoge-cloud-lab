"""Fit on one archived seed, score decisions on two other process seeds."""
from pathlib import Path
from statistics import median
import argparse
import csv
from collections import defaultdict
from placement import Node, solve

HERE = Path(__file__).resolve().parent
TRAIN = 205301
TEST = (405713, 760399)
KEY = ["field", "degree", "length", "seed", "round", "method", "ns"]


def extract(source):
    # input corpus only, filtered to the 5 methods used below
    with (HERE / "inputs.csv").open("w", newline="") as fp:
        writer = csv.writer(fp)
        writer.writerow(KEY)
        for length in range(1, 17):
            for seed in (TRAIN, *TEST):
                with (source / f"k{length:02d}-seed{seed}.csv").open() as stream:
                    for row in csv.DictReader(stream):
                        name = row["method"]
                        if name not in {"forward", "inverse", "shared_chain", "native_chain", "boundary_chain"}:
                            continue
                        counts = int(row["items"]) * int(row["repeats"])
                        writer.writerow([row["field"], row["degree"], length, seed, row["round"],
                                         name, int(row["elapsed_ns"]) / counts])


def choose(t):
    # Integer costs in picoseconds, while input records store ns per whole chain or map.
    def ps(name):
        return round(1000 * median(t[name]))
    arg = dict(fixed="shared",to_native=ps("forward"))
    nodes = [Node("a", **arg),Node("b", **arg),
             Node("chain", ("a", "b"), native=ps("native_chain"),
                  shared=ps("shared_chain"), to_shared=ps("inverse")),
             Node("out", ("chain",), fixed="shared")]
    return solve(nodes)["basis"]["chain"]


def audit():
    groups = defaultdict(lambda:defaultdict(lambda:defaultdict(list)))
    with (HERE / "inputs.csv").open() as fp:
        for row in csv.DictReader(fp):
            group = (row["field"], int(row["degree"]), int(row["length"]))
            groups[group][int(row["seed"])][row["method"]].append(float(row["ns"]))
    assert len(groups) == 64
    header = ["field","degree","length","test_seed","choice","observed_boundary_over_shared",
              "choice_over_oracle","outcome"]
    result = []
    for (field, degree, length), seeds in sorted(groups.items()):
        training = seeds[TRAIN]
        decision = choose(training)  # boundary timings are never passed as costs
        for seed in TEST:
            held = seeds[seed]
            assert all(len(v)==11 for v in held.values())
            ratio = median(a/b for a,b in zip(held["boundary_chain"],held["shared_chain"]))
            # Oracle uses the lower paired ratio on the same held-out process.
            regret = (ratio if decision=="native" else 1) / min(1,ratio)
            outcome = "best" if regret == 1 else "within 5%" if regret <= 1.05 else "miss >5%"
            result.append([field,degree,length,seed,decision,ratio,regret,outcome])
    return header,result


if __name__ == "__main__":
    cli = argparse.ArgumentParser(description=__doc__)
    cli.add_argument("--extract", type=Path, help="original archived sweep directory")
    args=cli.parse_args()
    if args.extract:
        extract(args.extract)
    header, rows = audit()
    with (HERE/"holdout.csv").open("w",newline="") as fp:
        writer = csv.writer(fp,lineterminator="\n")
        writer.writerow(header)
        writer.writerows(rows)
    for s in ("best","within 5%","miss >5%"):
        print(s, sum(r[-1]==s for r in rows))
    print("maximum observed regret factor", max(r[-2] for r in rows))
    for field in ("BabyBear", "KoalaBear"):
        for degree in (4,8):
            print(field,degree,"native selections at K =",sorted(set(r[2] for r in rows if
                  r[0:2]==[field,degree] and r[4]=="native")))
