# Whole-proof opening transport

A native Plonky3 0.8.0 prover constructs a two-column Fibonacci STARK. A producer exports its proof, a consumer imports it, and the ordinary native verifier checks the recovered proof against the independently supplied statement. Every successful path must reproduce the original whole-proof postcard byte for byte. The experiment exercises a shared representation at an application boundary. Both the prover and verifier perform their arithmetic in the original native basis.

## Running

From this directory, use Rust 1.100.0 and the pinned Cargo.lock.

```sh
cargo build --release --locked
mkdir -p replay-proof/results
target/release/native-proof-check 10 7 > replay-proof/results/log10.csv
target/release/native-proof-check 14 7 > replay-proof/results/log14.csv
cp summarize.py replay-proof/
python3 -B replay-proof/summarize.py
```

Add `--offline` to Cargo when the lockfile's dependencies are already cached. The basis library is supplied in `basis/`. No other project checkout is required. The harness accepts log heights 4 through 16 inclusive, checks the repetition count (1 through 100), and emits CSV. Report generation expects the two prescribed seven-repetition runs. Normal profiles use the default Cargo release settings and no target-specific RUSTFLAGS.

## Paths and byte layout

| Mode | Transport |
|---|---|
| 0 | Native Plonky3 postcard production and consumption with full-consumption check |
| 1 | Application envelope carrying fixed-width canonical coefficients in the native basis |
| 2 | Identical envelope carrying fixed-width canonical coefficients in the shared basis with generator satisfying u^D=37 |

Envelope prefix comprises four-byte ASCII P3F1, a little-endian field modulus u32, four single bytes (degree, mode, log height, zero reserved), a little-endian u32 skeleton byte count and a little-endian u32 coefficient byte count. The skeleton is the original postcard proof with its transported extension-field values replaced by zero. Every transported extension element contributes D little-endian canonical u32 residues in ascending basis order to a separate flat payload. The traversal visits local trace openings, next trace openings, quotient chunks, FRI final polynomial coefficients, then commit-phase sibling values. Native Plonky3 0.8.0 encodes the skeleton's base-field data and authenticators. This versioned format therefore depends on the pinned upstream proof layout. The placeholder implementation increases wire size by 20 bytes plus the flat payload. It gives both envelope modes identical framing, validation, allocation strategy and size at each case.

The consumer checks the declared route, field, degree, height, reserved byte, exact lengths, 4 MiB frame limit, canonical skeleton re-encoding, supported opening profile, zero placeholders, canonical coefficient range and exact payload consumption. It then invokes native verification. Benchmark inputs are locally generated, and the size cap bounds the input frame. The program is a benchmark harness, without a general hostile-input resource audit of upstream deserialization.

## Protocol and measurement

Public values bind initial (0, 1) and the final row's second coordinate. The driver computes that endpoint in the base field for the exact trace length. The AIR binds initial and final states and every Fibonacci step. Both prime fields run at degrees 4 and 8. The FRI parameters specify log blowup 2, 16 queries, binary folds, four final polynomial coefficients, zero batch work bits and one bit each for commit and query work. Each field uses its standard width-16 Poseidon2 permutation. These are experimental parameters, with no production security claim.

Each repetition proves once and times three separately decoded copies of the same proof. Native proof generation, export, import and native verification use independent monotonic-clock intervals. Export consumes the owned input, including its disposal. Import includes the envelope's skeleton canonicality pass. The composed total adds the common proving interval to the three route-specific intervals. It excludes configuration, basis setup, witness construction, staging copies, raw reference creation, byte-equality checks and negative controls. No filesystem or network transfer is timed. A composed total does not measure independent whole-process latency. The benchmark interleaves paths using all six permutations over the six retained repetitions per field, degree and height. Repetition zero supplies warmup and negative controls. Each repetition emits one row per mode; the shared native proving time repeats in the three rows.

Every mode must verify and reproduce the native proof bytes. At warmup the harness additionally requires equal envelope sizes and differing coefficient payloads, rejects malformed tags, lengths, truncation, trailing bytes and out-of-range coefficients, and obtains verifier rejection after a canonical coefficient mutation, a wrong public endpoint and a relabelled basis. The comparison is in-process on one host. The raw CSV preserves individual samples, and medians.csv uses paired per-repetition ratios and medians of within-repetition sums.

## Recorded run

On aarch64-apple-darwin, rustc 1.100.0 (0ef1bc386, LLVM 23.1.5), all 56 proof-generation executions and 168 transport/verification paths passed. These counts include warmups. At 16,384 rows per proof, the median native prover time ranged from 54.17 to 69.99 ms across the four field/degree combinations. The shared route spent 63.94 to 74.75 μs on export plus import and 1.07 to 1.21 ms on native verification. Over all eight cases the paired median shared/native-envelope transport ratio ranged from 0.9995 to 1.0313. Against raw native postcard transport the shared envelope took an additional 11.42 to 29.00 μs (1.548 to 1.651 times as long). The paired composed-total ratio against the raw path ranged from 0.9996 to 1.0039. The six paired timings per case describe this run, and supply limited precision for differences near unity. Examine results/log10.csv and results/log14.csv for the raw timing order, individual costs and variability.

The pair of similarly performing envelope implementations and their overhead relative to ordinary postcard characterize the application boundary. They provide no measurement of a shared-field STARK prover.
