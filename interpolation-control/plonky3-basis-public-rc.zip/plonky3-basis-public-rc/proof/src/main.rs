//! Native Fibonacci STARK compatibility check using the Plonky3 0.8.0 two-adic test configuration.
use p3_air::{Air, AirBuilder, BaseAir, WindowAccess};
use p3_baby_bear::{BabyBear, Poseidon2BabyBear, default_babybear_poseidon2_16};
use p3_koala_bear::{KoalaBear, Poseidon2KoalaBear, default_koalabear_poseidon2_16};
use p3_challenger::DuplexChallenger;
use p3_commit::ExtensionMmcs;
use p3_dft::Radix2DitParallel;
use p3_field::extension::BinomialExtensionField;
use p3_field::{Field, PrimeCharacteristicRing};
use p3_fri::{FriParameters, TwoAdicFriPcs};
use p3_matrix::dense::RowMajorMatrix;
use p3_merkle_tree::MerkleTreeMmcs;
use p3_symmetric::{PaddingFreeSponge, TruncatedPermutation};
use p3_uni_stark::{Proof, StarkConfig, prove, verify};
use plonky3_native::BasisMap;

struct Fibonacci;
impl<F> BaseAir<F> for Fibonacci {
    fn width(&self) -> usize { 2 }
    fn num_public_values(&self) -> usize { 3 }
    fn max_constraint_degree(&self) -> Option<usize> { Some(2) }
}
impl<AB: AirBuilder> Air<AB> for Fibonacci {
    fn eval(&self, builder: &mut AB) {
        let main = builder.main();
        let (row, next) = (main.current_slice(), main.next_slice());
        let (a, b, last) = (builder.public_values()[0], builder.public_values()[1], builder.public_values()[2]);
        builder.when_first_row().assert_eq(row[0], a);
        builder.when_first_row().assert_eq(row[1], b);
        builder.when_transition().assert_eq(next[0], row[1]);
        builder.when_transition().assert_eq(next[1], row[0] + row[1]);
        builder.when_last_row().assert_eq(row[1], last);
    }
}

macro_rules! proof_case {
    ($field:ty, $degree:literal, $perm:ty, $default:ident, $log:expr, $rep:expr) => {{
        type F = $field;
        type E = BinomialExtensionField<F, $degree>;
        type H = PaddingFreeSponge<$perm, 16, 8, 8>;
        type C = TruncatedPermutation<$perm, 2, 8, 16>;
        type M = MerkleTreeMmcs<<F as Field>::Packing, <F as Field>::Packing, H, C, 2, 8>;
        type EM = ExtensionMmcs<F, E, M>;
        type Pcs = TwoAdicFriPcs<F, Radix2DitParallel<F>, M, EM>;
        type Ch = DuplexChallenger<F, $perm, 16, 8>;
        type Config = StarkConfig<Pcs, E, Ch>;
        let perm = $default();
        let m = M::new(H::new(perm.clone()), C::new(perm.clone()), 0);
        let params = FriParameters {
            log_blowup: 2, log_final_poly_len: 2, max_log_arity: 1, num_queries: 16,
            batch_proof_of_work_bits: 0, commit_proof_of_work_bits: 1, query_proof_of_work_bits: 1,
            mmcs: EM::new(m.clone()),
        };
        let config = Config::new(Pcs::new(Radix2DitParallel::default(), m, params), Ch::new(perm));
        let log = $log;
        let rep = $rep;
        let map = BasisMap::<F, $degree>::new();
        let rows = 1usize << log;
        let mut trace = Vec::with_capacity(2 * rows);
        let (mut a, mut b) = (F::ZERO, F::ONE);
        for _ in 0..rows {
            trace.extend([a, b]);
            (a, b) = (b, a + b);
        }
        let public = [F::ZERO, F::ONE, a];
        let start = Instant::now();
        let proof = prove(&config, &Fibonacci, RowMajorMatrix::new(trace, 2), &public).unwrap();
        let prove_ns = start.elapsed().as_nanos();
        let reference = postcard::to_allocvec(&proof).unwrap();
        let visit = |proof: &mut Proof<Config>, f: &mut dyn FnMut(&mut E) -> Result<(), &'static str>| {
            let o = &mut proof.opened_values;
            if proof.degree_bits != log || o.preprocessed.is_some() || o.random.is_some()
                || o.trace_local.len() != 2 || o.trace_next.as_ref().map(Vec::len) != Some(2) {
                return Err("unsupported proof profile");
            }
            for x in o.trace_local.iter_mut().chain(o.trace_next.iter_mut().flatten())
                .chain(o.quotient_chunks.iter_mut().flatten())
                .chain(proof.opening_proof.final_poly.iter_mut())
                .chain(proof.opening_proof.commit_phase_openings.iter_mut().flat_map(|r| r.sibling_values.iter_mut().flatten())) {
                f(x)?;
            }
            Ok(())
        };
        let encode = |mut p: Proof<Config>, mode: u8| {
            if mode == 0 {return postcard::to_allocvec(&p).unwrap();}
            let mut tail = Vec::new();
            visit(&mut p, &mut |x| {
                let coords: [F; $degree] = if mode == 2 {map.to_shared(x)} else {
                    x.as_basis_coefficients_slice().try_into().unwrap()
                };
                for c in coords {tail.extend(c.as_canonical_u32().to_le_bytes());}
                *x = E::ZERO;
                Ok(())
            }).unwrap();
            let skeleton = postcard::to_allocvec(&p).unwrap();
            let mut out = Vec::with_capacity(20 + skeleton.len() + tail.len());
            out.extend(b"P3F1");
            out.extend(F::ORDER_U32.to_le_bytes());
            out.extend([$degree, mode, log as u8, 0]);
            out.extend((skeleton.len() as u32).to_le_bytes());
            out.extend((tail.len() as u32).to_le_bytes());
            out.extend(skeleton);
            out.extend(tail);
            out
        };
        let decode = |buf: &[u8], mode: u8| -> Result<Proof<Config>, &'static str> {
            if buf.len() > 4*1024*1024 {return Err("frame size");}
            if mode == 0 {
                let (p, rest) = postcard::take_from_bytes(buf).map_err(|_| "postcard")?;
                return if rest.is_empty() {Ok(p)} else {Err("trailing postcard")};
            }
            let field = F::ORDER_U32.to_le_bytes();
            if buf.len() < 20 || &buf[..4] != b"P3F1" || buf[4..8] != field ||
                buf[8..12] != [$degree,mode,log as u8,0] {return Err("header");}
            let length = |i| u32::from_le_bytes(buf[i..i+4].try_into().unwrap()) as usize;
            if 20u64 + length(12) as u64 + length(16) as u64 != buf.len() as u64 {return Err("length");}
            let (skeleton, mut tail) = buf[20..].split_at(length(12));
            let (mut p, rest) = postcard::take_from_bytes::<Proof<Config>>(skeleton).map_err(|_| "postcard")?;
            if !rest.is_empty() || postcard::to_allocvec(&p).map_err(|_| "postcard")? != skeleton {return Err("skeleton");}
            visit(&mut p, &mut |x| {
                if *x != E::ZERO {return Err("nonzero placeholder");}
                let mut coords = [F::ZERO; $degree];
                for c in &mut coords {
                    let (bytes, rest) = tail.split_at_checked(4).ok_or("short coordinates")?;
                    let n = u32::from_le_bytes(bytes.try_into().unwrap());
                    if n >= F::ORDER_U32 {return Err("noncanonical");}
                    *c = F::from_u32(n);
                    tail = rest;
                }
                *x = if mode == 2 {map.to_native(&coords)} else {E::new(coords)};
                Ok(())
            })?;
            if !tail.is_empty() {return Err("extra coordinates");}
            Ok(p)
        };
        let mut negative = false;
        let mut sizes = [0;3];
        for i in 0..3 {
            const ORDERS: [[u8;3];6] = [[0,1,2],[1,2,0],[2,0,1],[2,1,0],[0,2,1],[1,0,2]];
            let mode = ORDERS[rep%6][i];
            let input = decode(&reference, 0).unwrap();
            let start = Instant::now();
            let bytes = encode(input, mode);
            let export_ns = start.elapsed().as_nanos();
            let start = Instant::now();
            let decoded = decode(&bytes, mode).unwrap();
            let import_ns = start.elapsed().as_nanos();
            let start = Instant::now();
            verify(&config, &Fibonacci, &decoded, &public).unwrap();
            let verify_ns = start.elapsed().as_nanos();
            assert_eq!(postcard::to_allocvec(&decoded).unwrap(), reference);
            sizes[mode as usize] = bytes.len();
            if mode == 2 && rep == 0 {
                let mut bad = bytes.clone();
                bad.extend([0]);
                assert!(decode(&bad,2).is_err());
                assert!(decode(&bytes[..bytes.len()-1],2).is_err());
                for offset in [0,4,8,9,10,11,12,16] {
                    let mut bad = bytes.clone(); bad[offset] ^= 1;
                    assert!(decode(&bad,2).is_err());
                }
                let pos = 20 + u32::from_le_bytes(bytes[12..16].try_into().unwrap()) as usize;
                let mut bad = bytes.clone();
                bad[pos..pos+4].copy_from_slice(&F::ORDER_U32.to_le_bytes());
                assert!(decode(&bad,2).is_err());
                let mut bad = bytes.clone();
                let n = u32::from_le_bytes(bad[pos..pos+4].try_into().unwrap());
                bad[pos..pos+4].copy_from_slice(&((n+1)%F::ORDER_U32).to_le_bytes());
                assert!(verify(&config,&Fibonacci,&decode(&bad,2).unwrap(),&public).is_err());
                let mut wrong = public;
                wrong[2] += F::ONE;
                assert!(verify(&config,&Fibonacci,&decoded,&wrong).is_err());
                let native = encode(decode(&reference,0).unwrap(),1);
                assert_ne!(native[pos..],bytes[pos..]);
                let mut confused = bytes.clone(); confused[9] = 1;
                assert!(verify(&config,&Fibonacci,&decode(&confused,1).unwrap(),&public).is_err());
                negative = true;
            }
            println!("{},{},{},{},{},{},{},{},{},{}",stringify!($field),$degree,log,rep,mode,prove_ns,export_ns,import_ns,verify_ns,bytes.len());
        }
        assert_eq!(sizes[1],sizes[2]);
        assert!(rep != 0 || negative);
    }};
}
use p3_field::{BasedVectorSpace, PrimeField32};
use std::time::Instant;
fn main() {
    let args: Vec<String> = std::env::args().collect();
    assert_eq!(args.len(),3,"arguments: log_rows repetitions");
    let log: usize = args[1].parse().unwrap();
    let reps: usize = args[2].parse().unwrap();
    assert!((4..=16).contains(&log) && (1..=100).contains(&reps));
    println!("field,degree,log_rows,rep,mode,prove_ns,export_ns,import_ns,verify_ns,wire_bytes");
    for rep in 0..reps {
        proof_case!(BabyBear,4,Poseidon2BabyBear<16>,default_babybear_poseidon2_16,log,rep);
        proof_case!(BabyBear,8,Poseidon2BabyBear<16>,default_babybear_poseidon2_16,log,rep);
        proof_case!(KoalaBear,4,Poseidon2KoalaBear<16>,default_koalabear_poseidon2_16,log,rep);
        proof_case!(KoalaBear,8,Poseidon2KoalaBear<16>,default_koalabear_poseidon2_16,log,rep);
    }
}
