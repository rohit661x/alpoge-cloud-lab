"""Report per-case medians with paired comparisons. Rep 0 is warmup."""
import csv
from pathlib import Path
from statistics import median

root = Path(__file__).resolve().parent / "results"
samples = []
for log in (10, 14):
    with (root / f"log{log}.csv").open() as f:
        rows = list(csv.DictReader(f))
    assert len(rows) == 4 * 7 * 3
    samples.extend(rows)
def transport(row):
    return int(row["export_ns"]) + int(row["import_ns"])
def total(row):
    return int(row["prove_ns"]) + transport(row) + int(row["verify_ns"])
with (root / "medians.csv").open("w") as f:
    writer = csv.writer(f)
    writer.writerow(["field","degree","log_rows","mode","pairs","native_prove_ms","export_us","import_us","native_verify_ms","transport_us","composed_total_ms","wire_bytes","paired_transport_ratio_to_native_envelope","paired_total_ratio_to_raw","paired_transport_ratio_to_raw","paired_transport_delta_to_raw_us"])
    for field in ("BabyBear","KoalaBear"):
        for degree in (4,8):
            for log in (10,14):
                lookup = {(int(r["rep"]),int(r["mode"])):r for r in samples if r["field"]==field and int(r["degree"])==degree and int(r["log_rows"])==log}
                assert len(lookup) == 21
                for mode in range(3):
                    group = [lookup[i,mode] for i in range(1,7)]
                    env = [lookup[i,1] for i in range(1,7)]
                    raw = [lookup[i,0] for i in range(1,7)]
                    assert all(r["prove_ns"]==s["prove_ns"] for r,s in zip(group,raw))
                    m = lambda key,scale: round(median(int(r[key])/scale for r in group),5)
                    writer.writerow([field,degree,log,mode,len(group),m("prove_ns",1e6),m("export_ns",1e3),m("import_ns",1e3),m("verify_ns",1e6),round(median(map(transport,group))/1000,4),round(median(map(total,group))/1e6,5),m("wire_bytes",1),round(median(transport(r)/transport(s) for r,s in zip(group,env)),6),round(median(total(r)/total(s) for r,s in zip(group,raw)),6),round(median(transport(r)/transport(s) for r,s in zip(group,raw)),6),round(median((transport(r)-transport(s))/1000 for r,s in zip(group,raw)),5)])
