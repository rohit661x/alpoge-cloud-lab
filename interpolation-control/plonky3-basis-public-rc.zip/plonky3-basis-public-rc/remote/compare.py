"""Pair architecture summaries by complete workload key, retaining raw ratios."""
import argparse
import csv
from pathlib import Path

def read(path, keys):
    with path.open() as f:
        rows = list(csv.DictReader(f))
    result = {tuple(r[k] for k in keys): r for r in rows}
    assert len(result) == len(rows)
    return result

def compare(local, remote, kind, keys, metrics):
    arm = read(local/kind/'results/summary.csv', keys)
    x86 = read(remote/kind/'results/summary.csv', keys)
    assert arm.keys() == x86.keys()
    with (remote/f'{kind}-architecture-comparison.csv').open('w') as f:
        out = csv.writer(f)
        out.writerow([*keys, 'metric', 'mac_arm64', 'linux_x86_64'])
        for key in arm:
            for metric in metrics:
                out.writerow([*key,metric,arm[key][metric],x86[key][metric]])

if __name__ == '__main__':
    cli = argparse.ArgumentParser(description=__doc__)
    cli.add_argument('arm_root', type=Path)
    cli.add_argument('remote_root', type=Path)
    args = cli.parse_args()
    compare(args.arm_root,args.remote_root,'linear',['field','degree','inputs','outputs'],
            ['early_over_late','fused_early_over_late','fused_late_over_native'])
    compare(args.arm_root,args.remote_root,'fri',['field','degree','items','schedule','ratio'],['median'])
