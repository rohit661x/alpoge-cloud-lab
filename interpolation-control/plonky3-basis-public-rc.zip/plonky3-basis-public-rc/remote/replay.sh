#!/bin/sh
# Repeat the two cross-platform experiments using the archive's directory layout.
set -eu
if [ "$#" != 1 ] || [ -e "$1" ]; then
  echo "Usage: sh remote/replay.sh NEW_OUTPUT_DIRECTORY" >&2
  exit 2
fi
mkdir "$1"
dest=$(cd "$1" && pwd)
root=$(cd "$(dirname "$0")/.." && pwd)
export CARGO_TARGET_DIR="$dest/target"
{
  uname -sm
  rustc -Vv
  cargo -V
} > "$dest/platform.txt"
mkdir -p "$dest/linear/results" "$dest/fri/results"
unset RUSTFLAGS
cargo build --release --locked --manifest-path "$root/linear/Cargo.toml"
for seed in 1021 4111 7963; do
  "$CARGO_TARGET_DIR/release/linear-frontier" "$seed" > "$dest/linear/results/seed-$seed.csv"
done
cp "$root/linear/summarize.py" "$dest/linear/"
python3 -B "$dest/linear/summarize.py"
export RUSTFLAGS="-C target-cpu=native"
cargo build --release --locked --manifest-path "$root/fri/Cargo.toml"
for seed in 370817 842771 1301081; do
  "$CARGO_TARGET_DIR/release/fold-probe" "$seed" > "$dest/fri/results/seed-$seed.csv"
done
python3 -B "$root/fri/verify.py" "$dest/fri/results" > "$dest/fri/results/summary.csv"
echo "Wrote new run data and summaries under $dest"
