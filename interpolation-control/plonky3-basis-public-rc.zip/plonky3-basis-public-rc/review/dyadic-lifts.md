# Coherent dyadic extensions of the original quartic profiles

For each of the two prime fields separately, the original quartic map extends through every finite tower of power-of-two degrees. Exactly two normalized monomial maps lift each parent, and exactly one of the two candidate exponents works. The original octic maps published in the first profile belong to different branches above different quartic maps. Grades above eight here are mathematical examples. These results do not imply a degree-64 implementation in Plonky3.

Let p ≡ 1 mod 4 and let w and 37 be quadratic nonresidues modulo p. For d a power of two, both X^d − w and X^d − 37 are irreducible. One direct argument starts at d = 1. The norm of the native root at degree d is −w for even d, and its quadratic character in the extension equals the base-field character of its norm by Euler's criterion. Since −1 is square, this root remains a nonsquare. Adjoining its square root doubles the degree and proves the induction. The same reasoning applies to 37.

At degree d, write the map as u_d ↦ t x_d^r, with r odd, 0 < r < d and t^d w^r = 37 modulo p. The natural inclusions send each old generator to the square of the next generator. Write a candidate at degree 2d as u_2d ↦ s x_2d^R. Commutativity on the generator forces R = r + ed, e in {0,1}, and s² w^e = t. Choose e = 0 when t is a square, e = 1 otherwise. Multiplying by w flips quadratic character, so the other branch is impossible. Each of the two square roots s gives a different map. Raising s² w^e = t to power d yields the required defining relation. Restriction recovers the unique parent. There are exactly D/4 compatible final maps above one prescribed quartic profile at D = 4·2^j, each with its own uniquely determined path of restrictions. Pre-specifying a deeper map imposes its restriction on the anchor.

For an independent check on the observed common exponent in each row, take discrete logarithms relative to a primitive g. The equation at degree D gives r log_g(w) ≡ log_g(37) modulo gcd(D,p−1). The coefficient log_g(w) is odd, so r is unique modulo this gcd. For all displayed degrees D divides p−1, uniquely determining the normalized exponent modulo D even before a quartic anchor is fixed. Beyond the 2-adicity of p−1 this statement only fixes r modulo the gcd. The elementary doubling criterion still holds there and does not require a discrete logarithm.

| D | BabyBear canonical (r,t) | KoalaBear canonical (r,t) | Maps per original quartic |
|---:|---|---|---:|
| 4 | (3, 58781239) | (1, 168445237) | 1 |
| 8 | (3, 926186420) | (5, 862755065) | 2 |
| 16 | (3, 660558599) | (13, 439202238) | 4 |
| 32 | (19, 623642998) | (13, 704552768) | 8 |
| 64 | (19, 417128855) | (13, 358877068) | 16 |

Canonical here means choosing the smaller nonnegative modular square root at each step. Forcing the old exponent at every step fails for BabyBear from 16 to 32 and for KoalaBear from 4 to 8 and 8 to 16 on these paths. Allowing the permitted exponent shift repairs each obstruction.

Run dyadic_lifts.py alongside tower_certificate.py with ordinary Python assertions enabled. The former evaluates generator identities and checks both commuting paths on every parent basis monomial for all 60 child maps over the two fields combined. The JSON stores all children in deterministic parent-then-root order. One path uses one quadratic-character computation and one modular square root per doubling, plus checks. Enumerating every path requires work proportional at least to its D/4 terminal maps. Coordinates at degree D can be converted with O(D) base-field operations after precomputing the index and scale arrays. No benchmark was performed.

A search of local Markdown and Python materials for tower coherence, compatible monomials and doubling embeddings located the newly written review. The finite-field literature already treats compatible lattices and general embeddings. The evidence here supports a complete explicit solution for the two anchored parameter sets under this monomial convention and its independently reproducible vectors. Priority for the underlying recurrence is unresolved. [Compatible lattices](https://arxiv.org/abs/1906.00870) · [Computing embeddings](https://arxiv.org/abs/1705.01221)
