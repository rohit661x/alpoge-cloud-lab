"""Classify normalized monomial tower maps over the two pinned prime fields."""
import json
from tower_certificate import FIELDS, embed, transport


def square_root(a, p, nonsquare):
    """Tonelli–Shanks, with a supplied nonsquare and deterministic sign."""
    odd = p - 1
    s = 0
    while odd % 2 == 0:
        odd //= 2
        s += 1
    c = pow(nonsquare, odd, p)
    x = pow(a, (odd + 1) // 2, p)
    b = pow(a, odd, p)
    while b != 1:
        i = 1
        v = b*b % p
        while v != 1:
            i += 1
            v = v*v % p
        assert i < s
        z = pow(c, 1 << (s-i-1), p)
        x = x*z % p
        c = z*z % p
        b = b*c % p
        s = i
    assert x*x % p == a
    return min(x, p-x)


def lifts(p, w, d, r, t):
    assert pow(t,d,p)*pow(w,r,p) % p == 37 and 0 < r < d and r % 2
    e = int(pow(t,(p-1)//2,p) != 1)
    square = t*pow(w,-e,p) % p
    rejected = t*pow(w,e-1,p) % p
    assert pow(rejected,(p-1)//2,p) == p-1
    root = square_root(square,p,w)
    result = [(r+e*d,root),(r+e*d,p-root)]
    for exponent, scale in result:
        assert pow(scale,2*d,p)*pow(w,exponent,p) % p == 37
        assert scale*scale*pow(w,e,p) % p == t
        for i in range(d):
            basis = [0]*d
            basis[i] = 1
            assert embed(transport(basis,t,r,w,p)) == transport(embed(basis),scale,exponent,w,p)
    return result


def classify(field):
    name,p,w,_,r,t,*_ = field
    states = [(r,t)]
    result = {'anchor':[r,t], 'levels':{}}
    for d in (4,8,16,32):
        parents = states
        states = [child for r,t in parents for child in lifts(p,w,d,r,t)]
        assert len(set(states)) == len(states) == d//2
        result['levels'][2*d] = {'canonical_path_choice':states[0],
                                  'all_compatible_maps':states}
    return name,result


if __name__ == '__main__':
    print(json.dumps(dict(classify(field) for field in FIELDS),indent=2))
