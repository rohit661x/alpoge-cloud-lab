# Independent finite-field check with PARI/GP

Run `gp -fq check-towers.gp`. The saved verdict was generated locally by GP/PARI 2.17.3 on arm64 Darwin. It uses polynomial quotient arithmetic over Mod(1,p) and PARI's polynomial irreducibility test. For both fields at degrees 4, 8, 16, 32 and 64 it checked the primality of the characteristic, irreducibility of both defining polynomials, the image generator's relation, and transport of a dense product. At each doubling it compared the two paths on every parent basis vector. At degree eight it separately verified the original mismatch, its phase, and the two conventions for repairing it. The test covers the canonical quartic-anchored paths at higher degrees. The separate Python enumeration covers all branches.

A local Lean executable was absent from PATH, the standard elan toolchain directory, and the searched project binaries. No Lean proof was executed for this result.
