\\ Tested with GP/PARI 2.17.3. Run gp -fq check-towers.gp.
checktower(p,w,profile,old8,other8,phase,t4repair) = {
  my(one=Mod(1,p), old4=profile[1], good8=profile[2], q=old4[1], rr=good8[1]);
  my(z8=Mod(one*x,one*(x^8-w)), original=(old8*z8^rr)^2, from4=old4[2]*(z8^2)^q);
  if(!isprime(p),error("composite"));
  if(original==from4 || original!=phase*from4 || Mod(phase,p)^2!=-1,error("phase"));
  if(original!=t4repair*(z8^2)^q || (other8*z8^rr)^2!=from4,error("alternate repair"));
  for(j=1,#profile,
    my(d=2^(j+1),r=profile[j][1],t=profile[j][2],src=one*(x^d-37),dst=one*(x^d-w));
    if(!polisirreducible(src)||!polisirreducible(dst),error("reducible"));
    my(u=Mod(one*x,src),v=Mod(one*x,dst),image=t*v^r);
    if(image^d!=37,error("relation"));
    my(a=sum(i=0,d-1,(i+1)^2*u^i),b=sum(i=0,d-1,(2*i+3)*u^i));
    if(subst(lift(a*b),x,image)!=subst(lift(a),x,image)*subst(lift(b),x,image),error("product"));
    if(j>1,
      my(prev=profile[j-1],h=d/2,vs=Mod(one*x,one*(x^h-w)),us=Mod(one*x,one*(x^h-37)));
      for(i=0,h-1,
        if(subst(lift((prev[2]*vs^prev[1])^i),x,v^2)!=subst(lift(us^i),x,image^2),error("basis inclusion"))
      )
    );
    print("pass p=",p," d=",d," both irreducible, defining relation, dense product; inclusion basis count=",if(j==1,0,d/2))
  );
  print("pass p=",p," original mismatch, order-four phase, both repair conventions")
}
{
  iferr(
    checktower(2013265921,11,[[3,58781239],[3,926186420],[3,660558599],[19,623642998],[19,417128855]],305087007,1087079501,284861408,699698306);
    checktower(2130706433,3,[[1,168445237],[5,862755065],[13,439202238],[13,704552768],[13,358877068]],94536886,1267951368,16711679,749507076);
    print("ALL CHECKS PASSED"),
    err, print(err); quit(1))
}
