# Review of the W = 37 extension-field experiment

Reviewed 21 November 2026, Toronto time. The publishable engineering question is whether two concrete implementations of the same extension field can produce interoperable proof data through a documented coordinate map. Algebraic invariance alone gives neither proof-byte equality nor a performance improvement.

## Known results and implementations

- The explicit isomorphism problem for finite fields, including Kummer methods, has established algorithms and benchmarks. Choosing a root of a defining polynomial in the destination field defines the map. For binomials a monomial root gives a permutation and a diagonal scaling by direct substitution. [Computing isomorphisms and embeddings of finite fields](https://arxiv.org/abs/1705.01221) · [FLINT implementation](https://flintlib.org/doc/algorithms/finite-fields/embeddings.html)
- Standard representations and coherence along field towers have an extensive literature. Pairwise isomorphisms alone allow Frobenius twists around a diagram. [Bosma, Cannon and Steel](https://www.math.ru.nl/~bosma/pubs/JSC1997FiFi.pdf) · [Standard lattices of compatibly embedded finite fields](https://arxiv.org/abs/1906.00870)
- Cantor constructs efficient polynomial evaluation on additive subgroups. Gao–Mateer use Taylor expansions in characteristic two. Their evaluation domains and polynomial bases are distinct from the extension coefficient basis used by this multiplicative two-adic FRI experiment. They establish precedent for basis choice in transforms. [Cantor](https://www.sciencedirect.com/science/article/pii/0097316589900204) · [Gao and Mateer](https://www.math.clemson.edu/~sgao/papers/GM10.pdf)
- Binius implements arguments over binary field towers with architecture-specific arithmetic. Plonky3 already offers binary tower and GHASH polynomial representations and an additive transform stack. Plonky3 exposes extension basis coordinates and explicitly allows basis choice to vary by version. Any protocol encoding using those coordinates needs a version and convention. [Binius implementation](https://github.com/IrreducibleOSS/binius) · [Plonky3 recursion book](https://plonky3.github.io/Plonky3-recursion/advanced_topics/binary_fields.html) · [Plonky3 field traits](https://github.com/Plonky3/Plonky3/blob/a21e3ed42905040ad49c519e402f018381c12d0c/field/src/field.rs)
- FRI folds Reed–Solomon words recursively. Mapping the word, evaluation points, and challenges through a field isomorphism commutes with its arithmetic. Hash input order, coordinate serialization, and sampling a challenge from transcript words introduce implementation choices. Upstream Plonky3 already implements two-adic FRI PCS and benchmarks extension arithmetic. [FRI paper](https://eccc.weizmann.ac.il/report/2017/134/) · [PCS implementation](https://github.com/Plonky3/Plonky3/blob/a21e3ed42905040ad49c519e402f018381c12d0c/fri/src/two_adic_pcs.rs) · [Extension benchmark](https://github.com/Plonky3/Plonky3/issues/130)

## Recomputed constants and a coherence counterexample

Write x^d = w in the native field, and send u to t x^r for u^d = 37. Independently reducing t^d w^r by Python integer modular exponentiation returned 37 on all four rows. Since each r is odd and d is a power of two, reducing the exponents modulo d permutes the basis. The two prime characteristics differ. Each map is within one characteristic. Native w values are 11 and 3, respectively. [BabyBear source](https://raw.githubusercontent.com/Plonky3/Plonky3/a21e3ed42905040ad49c519e402f018381c12d0c/baby-bear/src/baby_bear.rs) · [KoalaBear source](https://raw.githubusercontent.com/Plonky3/Plonky3/a21e3ed42905040ad49c519e402f018381c12d0c/koala-bear/src/koala_bear.rs)

| Field | d | r | Original t |
|---|---:|---:|---:|
| BabyBear | 4 | 3 | 58781239 |
| BabyBear | 8 | 3 | 305087007 |
| KoalaBear | 4 | 1 | 168445237 |
| KoalaBear | 8 | 5 | 94536886 |

For this pair of primes an exhaustive Euler-criterion check on 1 through 37 returns exactly 33 and 37 as simultaneous quadratic nonresidues. Thus 37 is the least *prime* satisfying the condition for this pair. No analytic number theory enters this computation.

Under the natural inclusions u4 ↦ u8² and x4 ↦ x8², the two paths send u4 to coefficients differing by a factor of 284861408 for BabyBear and 16711679 for KoalaBear (octic path divided by quartic path). Both factors square to −1. For commuting maps with the same octic choices, replace the quartic t by 699698306 and 749507076 respectively. The formula is t8² w^floor(r8/4) modulo p, with r4 = r8 mod 4. Recompute all quartic transported constants before using this convention in production. A degree-four data set alone cannot detect this mismatch.

## What the archived Lean theorem establishes

Sutherland's verification page prints the challenge statement LFunction_eq_zero_re for every nonzero natural modulus and every Dirichlet character. A zero in the open strip 0 < Re(s) < 1 satisfies Re(s) = 1/2. This can underwrite an explicit bound on a search over primes after supplying the relevant analytic estimates. Four fixed basis-map certificates and their fold tests need only modular arithmetic. The local project dossier uses the Dirichlet theorem for prime counts in a separate interval problem. It reports a prior published independent full comparison and local background replay. This review inspected the stated result without conducting a kernel replay. [Independent verification and theorem signatures](https://math.mit.edu/~drew/grh/)


## Defensible applications and falsifiers

1. A differential compatibility fixture for a specific release of Plonky3, covering two characteristics and two extension degrees. Demonstrate an independent implementation reproduces the vector. When claiming proof-wire compatibility, compare identical serialized proofs or cross-verify both directions with a fixed transcript, commitment and sampling convention. A self-verified proof from each backend establishes less.
2. A tower-coherent conversion fixture for mixed-degree code. Check both paths on every quartic basis vector. The original constants supply a reproducible failing control and the two replacements give a constructive repair. Previously published matching vectors would defeat a priority claim. Existing general algorithms already establish the underlying result.
3. A reproducible sensitivity test for how parameter and representation choices affect an actual proof workload. Record compiler, ISA, build flags, input distribution, repeated runs, costs at format boundaries and hardware. Native KoalaBear has specialized multiplication by 3, so differences cannot automatically be attributed to basis transport. Claims of speed require workload-specific measurements.

The source search used public indexed web results for Cantor/Gao–Mateer, Binius binary-tower and AES isomorphism, Plonky3 field isomorphism/binomial extensions/GHASH, compatible finite-field embedding lattices, and the strings “37 BabyBear KoalaBear binomial W37” and “58781239 305087007 BabyBear”. No retrieved primary source identified these four exact maps. The search did not exhaust unindexed Git histories, private implementations, alternate generators, patents, or all academic databases. Algebraically equivalent coordinates can look different in keyword search. The warranted claim is a documented parameter set and integration experiment, with priority unresolved.

### Classification of single-degree repairs

The native quartic generator embeds as x8², and the shared quartic generator as u8². Hence the two coefficients of x4^r4 are t4 and t8² w^k, where k = floor(r8/4). Equality on the generator suffices for equality on the field. Among normalized monomial maps preserving the octic map, the compatible quartic map is unique. Keeping both original maps is impossible for these specified natural inclusions since their ratio has order four. Altering one degree per characteristic suffices and is minimal in number of maps changed.

To preserve the original quartic map, replace t8 by c t8 for c in the eighth roots of unity, with c² equal to the inverse phase. Each of the two solutions has order eight. The resulting t8 values are 926186420 or 1087079501 for BabyBear, and 862755065 or 1267951368 for KoalaBear. Keeping r8, either sign works. The only other normalized candidate exponent with the required quartic image is r8 + 4 modulo 8. This changes the coefficient square requirement by the nonsquare w or its inverse, so no such t8 exists. Select and version a repair explicitly when both degrees need to interoperate. Existing single-degree wire fixtures can retain their original coordinates.

The companion tower_certificate.py checks both moduli by trial division and evaluates both paths on every quartic basis monomial plus two dense vectors. Its JSON output, tower_vectors.json, records the original discrepancy and repaired images. Rerun the script with ordinary Python assertions enabled. Equality on the entire basis establishes equality of the two linear maps for all inputs. Prior work on compatible lattices already supplies the general concept. The counterexample and repair choices above concern the four listed parameter records.
