"""Recompute the two natural inclusion diagrams using Python integer arithmetic."""
import json
from math import isqrt

FIELDS = (
    ("BabyBear", 2013265921, 11, 31, 3, 58781239, 3, 305087007),
    ("KoalaBear", 2130706433, 3, 3, 1, 168445237, 5, 94536886),
)


def transport(a, t, r, w, p):
    d = len(a)
    result = [0] * d
    for i, coefficient in enumerate(a):
        wraps, index = divmod(r * i, d)
        result[index] = coefficient * pow(t, i, p) * pow(w, wraps, p) % p
    return result


def embed(a):
    return [c for coefficient in a for c in (coefficient, 0)]


def diagram(a, t4, t8, r4, r8, w, p):
    return (embed(transport(a, t4, r4, w, p)),
            transport(embed(a), t8, r8, w, p))


def analyze(name, p, w, g, r4, t4, r8, t8):
    assert all(p % q for q in range(2, isqrt(p) + 1))
    assert pow(w, (p - 1) // 2, p) == p - 1
    assert pow(37, (p - 1) // 2, p) == p - 1
    assert r4 == r8 % 4
    def valid(t, d, r):
        return pow(t, d, p) * pow(w, r, p) % p == 37
    assert valid(t4, 4, r4) and valid(t8, 8, r8)
    t4_fixed = t8**2 * w**(r8 // 4) % p
    phase = t4_fixed * pow(t4, -1, p) % p
    assert pow(phase, 2, p) == p - 1 and valid(t4_fixed, 4, r4)
    zeta = pow(g, (p - 1) // 8, p)
    assert pow(zeta, 4, p) == p - 1
    choices = sorted(t8 * pow(zeta, j, p) % p for j in range(8)
                     if phase * pow(zeta, 2*j, p) % p == 1)
    assert len(choices) == 2 and sum(choices) == p
    assert all(valid(t, 8, r8) for t in choices)
    alternative_r = (r8 + 4) % 8
    ratio = t4 * pow(w**(alternative_r // 4), -1, p) % p
    assert pow(ratio, (p-1)//2, p) == p-1
    basis = [[int(i == j) for j in range(4)] for i in range(4)]
    vectors = basis + [[1,2,3,4], [p-1,p-2,p-3,p-4]]
    examples = []
    for a in vectors:
        old = diagram(a,t4,t8,r4,r8,w,p)
        repaired = diagram(a,t4_fixed,t8,r4,r8,w,p)
        assert (old[0] == old[1]) == (a == basis[0])
        assert repaired[0] == repaired[1]
        for t in choices:
            alternate = diagram(a,t4,t,r4,r8,w,p)
            assert alternate[0] == alternate[1] == old[0]
        examples.append(dict(shared_quartic=a,original_quartic_path=old[0],
                             original_octic_path=old[1],fixed_quartic_path=repaired[0]))
    return dict(field=name,p=p,w=w,r4=r4,t4=t4,r8=r8,t8=t8,phase=phase,
                phase_order=4,new_t4=t4_fixed,alternative_new_t8=choices,vectors=examples)


if __name__ == "__main__":
    rows = [analyze(*field) for field in FIELDS]
    nrs = [n for n in range(1,38)
           if all(pow(n,(field[1]-1)//2,field[1]) == field[1]-1 for field in FIELDS)]
    assert nrs == [33,37]
    print(json.dumps(dict(simultaneous_nonresidues_through_37=nrs,fields=rows),indent=2))
