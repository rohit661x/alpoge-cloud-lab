# Compatible quartic and octic Plonky3 basis profiles

The shared fields use u₄⁴ = u₈⁸ = 37. The native fields use x₄⁴ = x₈⁸ = w, where w is 11 for BabyBear and 3 for KoalaBear. The natural tower embeddings chosen here are u₄ ↦ u₈² and x₄ ↦ x₈². All maps send u_D ↦ t_D x_D^r_D. Coordinate arrays are in ascending order of powers.

| Field | Profile | (r₄, t₄) | (r₈, t₈) | Diagram commutes |
| --- | --- | --- | --- | --- |
| BabyBear | legacy | 3, 58781239 | 3, 305087007 | No |
| BabyBear | keep_octic | 3, 699698306 | 3, 305087007 | Yes |
| BabyBear | keep_quartic | 3, 58781239 | 3, 926186420 | Yes |
| KoalaBear | legacy | 1, 168445237 | 5, 94536886 | No |
| KoalaBear | keep_octic | 1, 749507076 | 5, 94536886 | Yes |
| KoalaBear | keep_quartic | 1, 168445237 | 5, 862755065 | Yes |

Squaring the octic map gives t₈² w^floor(r₈/4) x₈^(2(r₈ mod 4)). Thus compatibility requires r₄ = r₈ mod 4 and t₄ = t₈² w^floor(r₈/4). This fixes the restriction when the octic is retained. When the quartic is retained, multiplying the legacy octic scale by each eighth root of unity enumerates two admissible scales. We choose the smaller canonical residue. Its negative gives the other extension. The two corresponding octic maps differ by a sign on odd powers, so their equalizer is the even-power quartic subfield. The legacy tower paths differ on monomial i by δ^i, where δ = 284861408 for BabyBear and 16711679 for KoalaBear. Both defects square to −1. The power basis is independent, so the legacy paths agree exactly on constants.

## Run

Use Rust 2024 and the enclosed Cargo.lock. The checked run used rustc 1.100.0, Plonky3 0.8.0 and postcard 1.2.0.

```sh
cargo build --release --locked
target/release/tower-regression > replay.csv
cmp fixtures.csv replay.csv
python3 verify_cli.py target/release/tower-regression
```

The Rust executable verifies all basis monomials and every ordered product of the basis vectors and 32 dense vectors per field, degree and profile using actual shared and native Plonky3 field multiplication. It checks inverses of the coefficient maps by round trip, examines all quartic support masks in both diagram paths and all octic support masks for the two octic lifts. The 36-row fixtures file records exact native postcard generator and dense values and the two octic embedding paths on the quartic generator. In path rows the scale column identifies the degree-specific map applied on that path. The CLI verifier also reads the earlier independent native postcard fixtures in legacy-wire.csv, extracted verbatim as shared coordinates and byte strings from the previous wire experiment. It tests preservation on the unchanged degree and explicit migration on the changed degree.

## Profile selection and migration

```sh
target/release/tower-regression encode baby 4 legacy 0,1,0,0
target/release/tower-regression decode baby 4 legacy 000000000000000000000000588c8638
target/release/tower-regression encode baby 4 keep_octic 0,1,0,0
```

The first two commands round-trip the legacy generator. The third encodes the same shared element in the keep_octic profile. To migrate a native payload with known provenance, decode with its original profile, then encode the resulting shared coefficients with the destination profile. Enclosing applications must supply field, degree and profile together. The bare native postcard element contains only Montgomery coefficient words, and changed profiles can successfully parse the same bytes with different shared meanings. Existing legacy data stays readable by explicit legacy selection. These are scalar field-element fixtures, not proof, transcript or protocol-version compatibility guarantees.

## Relative trace and norm as a mixed-degree application

Use the octic shared coordinate vector (1, 2, 3, 4, 5, 6, 7, 8) in either field. Write it as z = a + y b, where y is the octic generator, y² = u₄, a = (1, 3, 5, 7) and b = (2, 4, 6, 8). The relative conjugate sends y to −y. Quartic arithmetic therefore gives trace 2a = (2, 6, 10, 14) and norm a² − u₄ b² = (−480, −1108, −1736, −2364) modulo the field prime.

The independent native route first maps z at degree eight, applies the upstream octic repeated_frobenius(4) operation, computes the sum or product with z's image, checks all odd coefficients vanish, and reads the four even coefficients as the native quartic result. The test also checks the same Frobenius identity inside the shared octic field. In each field the legacy-profile quartic conversion disagrees with the native route for both operations. The two coherent profiles give identical bytes along their respective routes. The profiles can produce different native bytes from one another because they choose different basis maps. All twelve rows, including both native postcard outputs of each comparison, are in trace-norm.csv.

```sh
target/release/tower-regression trace-norm > relative-replay.csv
cmp trace-norm.csv relative-replay.csv
```
