mod legacy;
mod relative;
#[allow(dead_code)]
mod params;
use legacy::{BasisMap, BasisParameters};
use p3_baby_bear::BabyBear;
use p3_field::{BasedVectorSpace, PrimeField32};
use p3_field::extension::{BinomialExtensionField, BinomiallyExtendable};
use p3_koala_bear::KoalaBear;
use p3_monty_31::MontyField31;

type E<F, const D: usize> = BinomialExtensionField<F, D>;

#[derive(Clone, Copy)]
struct Scale { r: usize, t: u32 }

fn map<F: PrimeField32 + BinomiallyExtendable<D>, const D: usize>(
    a: &[F; D], scale: Scale,
) -> E<F,D> {
    let mut out = [F::ZERO; D];
    let w = <F as BinomiallyExtendable<D>>::W;
    let t = F::from_u32(scale.t);
    assert_eq!(t.exp_u64(D as u64)*w.exp_u64(scale.r as u64), F::from_u32(37));
    for (i, &coefficient) in a.iter().enumerate() {
        let exponent = i * scale.r;
        out[exponent % D] = coefficient * t.exp_u64(i as u64) * w.exp_u64((exponent / D) as u64);
    }
    E::new(out)
}

fn unmap<F: PrimeField32 + BinomiallyExtendable<D>, const D:usize>(
    x: &E<F,D>, scale: Scale,
) -> [F;D] {
    let coefficients: &[F] = x.as_basis_coefficients_slice();
    let w = <F as BinomiallyExtendable<D>>::W;
    std::array::from_fn(|i|{
        let exponent=i*scale.r;
        coefficients[exponent%D] / (F::from_u32(scale.t).exp_u64(i as u64)*w.exp_u64((exponent/D) as u64))
    })
}

fn lift<F:PrimeField32>(x:&[F;4])->[F;8] {
    std::array::from_fn(|i|if i%2==0{x[i/2]}else{F::ZERO})
}
fn basis<F:PrimeField32,const D:usize>(i:usize)->[F;D]{
    std::array::from_fn(|j|if i==j {F::ONE} else {F::ZERO})
}
fn wire<F:PrimeField32+BinomiallyExtendable<D>,const D:usize>(x:&E<F,D>)->String {
    postcard::to_allocvec(x).unwrap().iter().map(|b|format!("{b:02x}")).collect()
}
fn check_degree<F,S,const D:usize>(field:&str,profile:&str,s:Scale)
where F:BasisParameters<D>, S:PrimeField32+BinomiallyExtendable<D> {
    let legacy=BasisMap::<F,D>::new();
    let mut samples:Vec<[F;D]>=(0..D).map(basis).collect();
    let mut state=0x89abd3844732u64;
    for _ in 0..32 {
        samples.push(std::array::from_fn(|_|{
            state=state.wrapping_mul(6364136223846793005).wrapping_add(1);
            F::from_u64(state>>17)
        }));
    }
    for (i,a) in samples.iter().enumerate() {
        let x=map(a,s);
        assert_eq!(unmap(&x,s),*a);
        if profile=="legacy" {
            assert_eq!(x,legacy.to_native(a));
            assert_eq!(legacy.to_shared(&x),*a);
        }
        let raw=postcard::to_allocvec(&x).unwrap();
        let (decoded,rest)=postcard::take_from_bytes::<E<F,D>>(&raw).unwrap();
        assert!(rest.is_empty());
        assert_eq!(unmap(&decoded,s),*a);
        if i==1 || i==D {println!("{field},{profile},{D},{},{},{}",s.t,if i==1{"generator"}else{"dense"},wire(&x));}
        for b in &samples {
            let shared=|v:&[F;D]|E::<S,D>::new(v.map(|c|S::from_u32(c.as_canonical_u32())));
            let product=shared(a)*shared(b);
            let c:&[S]=product.as_basis_coefficients_slice();
            let ab=std::array::from_fn(|j|F::from_u32(c[j].as_canonical_u32()));
            assert_eq!(map(&ab,s),x*map(b,s));
        }
    }
}
fn field<F,S>(name:&str,g:u32,expected_q:u32,expected_o:u32,relative_only:bool)
where F:BasisParameters<4>+BasisParameters<8>, S:PrimeField32+BinomiallyExtendable<4>+BinomiallyExtendable<8> {
    let q=Scale{r:<F as BasisParameters<4>>::R,t:<F as BasisParameters<4>>::T};
    let o=Scale{r:<F as BasisParameters<8>>::R,t:<F as BasisParameters<8>>::T};
    let w=<F as BinomiallyExtendable<8>>::W;
    assert_eq!(w,<F as BinomiallyExtendable<4>>::W);
    assert_eq!(q.r,o.r%4);
    let factor=w.exp_u64((o.r/4) as u64);
    let restrict=|scale:Scale| (F::from_u32(scale.t).square()*factor).as_canonical_u32();
    let new_q=Scale{r:q.r,t:restrict(o)};
    let zeta=F::from_u32(g).exp_u64(((F::ORDER_U32-1)/8).into());
    assert_ne!(zeta.exp_u64(4),F::ONE);
    assert_eq!(zeta.exp_u64(8),F::ONE);
    let mut extensions:Vec<_>=(0..8).map(|j|Scale{r:o.r,t:(F::from_u32(o.t)*zeta.exp_u64(j)).as_canonical_u32()}).filter(|&c|restrict(c)==q.t).collect();
    extensions.sort_by_key(|c|c.t);
    assert_eq!(extensions.len(),2);
    let new_o=extensions[0];
    assert_eq!(extensions[1].t,F::ORDER_U32-new_o.t);
    assert_eq!((new_q.t,new_o.t),(expected_q,expected_o));
    let defect=F::from_u32(new_q.t)/F::from_u32(q.t);
    assert_eq!(defect.square(),-F::ONE);
    for (profile,quartic,octic) in [("legacy",q,o),("keep_octic",new_q,o),("keep_quartic",q,new_o)] {
        if relative_only {relative::check::<F,S>(name,profile,quartic,octic);continue;}
        check_degree::<F,S,4>(name,profile,quartic);
        check_degree::<F,S,8>(name,profile,octic);
        let compare=|a:&[F;4]|{
            let left=map(&lift(a),octic);
            let qx=map(a,quartic);
            let c:&[F]=qx.as_basis_coefficients_slice();
            let right=E::<F,8>::new(lift(c.try_into().unwrap()));
            assert_eq!(left==right,profile!="legacy" || a[1..].iter().all(|v|*v==F::ZERO));
            if a==&basis(1) {
                println!("{name},{profile},8,{},lift_then_map,{}",octic.t,wire(&left));
                println!("{name},{profile},8,{},map_then_lift,{}",quartic.t,wire(&right));
            }
        };
        for mask in 0..16 {compare(&std::array::from_fn(|i|if mask&(1<<i)!=0{F::from_usize(i+17)}else{F::ZERO}));}
        for i in 0..4 {compare(&basis(i));}
    }
    // The two coherent octic extensions of the original quartic agree on the full
    // embedded quartic. Their odd coefficients have opposite signs.
    for mask in 0..256 {
        let a:[F;8]=std::array::from_fn(|i|if mask&(1<<i)!=0{F::from_usize(i+11)}else{F::ZERO});
        assert_eq!(map(&a,new_o)==map(&a,extensions[1]),mask&0xaa==0);
    }
    // A changed profile can parse old bytes as a native element while recovering a
    // different shared generator. Profile selection belongs to the enclosing format.
    fn confusion<F:PrimeField32+BinomiallyExtendable<D>,const D:usize>(old:Scale,new:Scale) {
        let u=basis::<F,D>(1);
        let v=map(&u,old);
        let bytes=postcard::to_allocvec(&v).unwrap();
        let (parsed,rest)=postcard::take_from_bytes::<E<F,D>>(&bytes).unwrap();
        assert!(rest.is_empty());
        assert_ne!(map(&u,new),v);
        assert_ne!(unmap(&parsed,new),u);
        assert_eq!(unmap(&parsed,old),u);
    }
    confusion::<F,4>(q,new_q);
    confusion::<F,8>(o,new_o);
}
fn verify(relative_only:bool){
    if relative_only {println!("field,profile,operation,shared_quartic,converted_quartic_postcard,native_frobenius_quartic_postcard,equal");} else {println!("field,profile,degree,map_scale,sample,postcard_hex");}
    field::<BabyBear,MontyField31<params::SharedBaby>>("baby",31,699698306,926186420,relative_only);
    field::<KoalaBear,MontyField31<params::SharedKoala>>("koala",3,749507076,862755065,relative_only);
}

fn cli<F:BasisParameters<D>,const D:usize>(operation:&str,profile:&str,data:&str,keep_octic:u32,keep_quartic:u32)->Result<String,String> {
    let t=match profile {
        "legacy"=>F::T,
        "keep_octic"=>if D==4 {keep_octic}else{F::T},
        "keep_quartic"=>if D==8 {keep_quartic}else{F::T},
        _=>return Err("unknown profile".into()),
    };
    let scale=Scale{r:F::R,t};
    match operation {
        "encode"=>{
            let words:Vec<_>=data.split(',').map(|word|word.parse::<u32>().map_err(|_|"invalid unsigned decimal coefficient")).collect::<Result<_,_>>()?;
            if words.len()!=D || words.iter().any(|&word|word>=F::ORDER_U32){return Err("wrong coefficient count or coefficient outside the field".into());}
            let a:[F;D]=std::array::from_fn(|i|F::from_u32(words[i]));
            Ok(wire(&map(&a,scale)))
        }
        "decode"=>{
            if data.len()!=8*D || !data.is_ascii(){return Err("wrong postcard hex length".into());}
            let bytes:Vec<_>=(0..data.len()).step_by(2).map(|i|u8::from_str_radix(&data[i..i+2],16).map_err(|_|"invalid hexadecimal")).collect::<Result<_,_>>()?;
            let (value,rest)=postcard::take_from_bytes::<E<F,D>>(&bytes).map_err(|_|"invalid native postcard")?;
            if !rest.is_empty(){return Err("trailing bytes".into());}
            Ok(unmap(&value,scale).map(|c|c.as_canonical_u32().to_string()).join(","))
        }
        _=>Err("unknown operation".into())
    }
}
fn entry()->Result<(),String>{
    let args:Vec<_>=std::env::args().skip(1).collect();
    if args.is_empty(){verify(false);return Ok(());}
    if args==["trace-norm"] {verify(true);return Ok(());}
    let [op,f,d,profile,data]=args.as_slice() else{return Err("use encode|decode baby|koala 4|8 legacy|keep_octic|keep_quartic DATA".into())};
    let result=match (f.as_str(),d.as_str()) {
        ("baby","4")=>cli::<BabyBear,4>(op,profile,data,699698306,926186420),
        ("baby","8")=>cli::<BabyBear,8>(op,profile,data,699698306,926186420),
        ("koala","4")=>cli::<KoalaBear,4>(op,profile,data,749507076,862755065),
        ("koala","8")=>cli::<KoalaBear,8>(op,profile,data,749507076,862755065),
        _=>Err("unknown field or degree".into())
    }?;
    println!("{result}");
    Ok(())
}
fn main(){
    if let Err(error)=entry(){eprintln!("{error}");std::process::exit(2);}
}
