//! Relative trace and norm down the octic-to-quartic tower.
use super::{basis, map, wire, E, Scale};
use p3_field::{BasedVectorSpace, PrimeCharacteristicRing, PrimeField32};
use p3_field::extension::{BinomiallyExtendable, HasFrobenius};

fn project<F:PrimeField32+BinomiallyExtendable<4>+BinomiallyExtendable<8>>(x:&E<F,8>)->E<F,4> {
    let c:&[F]=x.as_basis_coefficients_slice();
    assert!(c.iter().skip(1).step_by(2).all(|v|*v==F::ZERO));
    E::new(std::array::from_fn(|i|c[2*i]))
}

pub(super) fn check<F,S>(field:&str, profile:&str, quartic:Scale, octic:Scale)
where F:PrimeField32+BinomiallyExtendable<4>+BinomiallyExtendable<8>,
      S:PrimeField32+BinomiallyExtendable<4>+BinomiallyExtendable<8> {
    // The shared octic coordinates are [1,2,3,4,5,6,7,8] in ascending powers.
    let words:[u32;8]=[1,2,3,4,5,6,7,8];
    let z=E::<S,8>::new(words.map(S::from_u32));
    let a=E::<S,4>::new(std::array::from_fn(|i|S::from_u32(words[2*i])));
    let b=E::<S,4>::new(std::array::from_fn(|i|S::from_u32(words[2*i+1])));
    let u4=E::<S,4>::new(basis(1));
    let trace=a+a;
    let norm=a.square()-u4*b.square();
    let conjugate=z.repeated_frobenius(4);
    assert_eq!(trace,project(&(z+conjugate)));
    assert_eq!(norm,project(&(z*conjugate)));
    let native=map(&words.map(F::from_u32),octic);
    let native_conjugate=native.repeated_frobenius(4);
    for (operation,shared,oracle) in [
        ("trace",trace,project(&(native+native_conjugate))),
        ("norm",norm,project(&(native*native_conjugate))),
    ] {
        let coefficients:&[S]=shared.as_basis_coefficients_slice();
        let canonical:[u32;4]=std::array::from_fn(|i|coefficients[i].as_canonical_u32());
        let converted=map(&canonical.map(F::from_u32),quartic);
        assert_eq!(converted==oracle,profile!="legacy");
        let values=canonical.map(|v|v.to_string()).join(" ");
        println!("{field},{profile},{operation},{values},{},{},{}",wire(&converted),wire(&oracle),converted==oracle);
    }
}
