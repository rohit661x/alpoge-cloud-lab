"""CLI regression against earlier independent byte fixtures and profile invariants."""
import csv
import subprocess
import sys
from pathlib import Path

binary = Path(sys.argv[1]).resolve()
def call(*args, ok=True):
    p = subprocess.run([binary, *args], text=True, capture_output=True)
    assert (p.returncode == 0) == ok, (args,p.stderr)
    return p.stdout.strip()

fixtures = Path(__file__).parent
assert call() == (fixtures / "fixtures.csv").read_text().strip()
assert call("trace-norm") == (fixtures / "trace-norm.csv").read_text().strip()
with (fixtures / "legacy-wire.csv").open() as f:
    legacy = list(csv.DictReader(f))
for row in legacy:
    field, d, shared, expected = [row[k] for k in ("field","degree","shared","postcard")]
    preserved = "keep_octic" if d=="8" else "keep_quartic"
    for profile in ["legacy",preserved]:
        assert call("encode",field,d,profile,shared)==expected
        assert call("decode",field,d,profile,expected)==shared
    changed = "keep_quartic" if d=="8" else "keep_octic"
    new = call("encode",field,d,changed,shared)
    assert call("decode",field,d,changed,new)==shared
    assert call("encode",field,d,"legacy",call("decode",field,d,changed,new))==expected
for args in [
    ["decode","baby","4","legacy","ff"*16],
    ["decode","baby","4","legacy","00"*17],
    ["decode","koala","8","keep_quartic","?"*64],
    ["encode","baby","4","legacy","2013265921,0,0,0"],
    ["encode","koala","8","keep_octic","1,2"],
    ["encode","other","4","legacy","1,2,3,4"],
    ["encode","baby","4","unspecified","1,2,3,4"],
]:
    call(*args,ok=False)
print(f"PASS: {len(legacy)} prior fixture values; both unchanged profile selections; changed profile migrations; 36 native wire fixtures; 12 relative trace/norm rows; 7 invalid input classes.")
