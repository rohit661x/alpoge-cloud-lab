"""Recompute the finite certificates and benchmark summaries without re-timing."""
from pathlib import Path
import hashlib
import shutil
import subprocess
import sys
from tempfile import TemporaryDirectory

ROOT = Path(__file__).resolve().parent


def run(script, *args, cwd=None):
    return subprocess.check_output([sys.executable, "-B", str(script), *map(str, args)], cwd=cwd or ROOT)


def same(actual, expected):
    if actual.replace(b"\r\n", b"\n") != expected.read_bytes().replace(b"\r\n", b"\n"):
        raise ValueError(f"Regeneration differs from {expected}")


def digests(lines, directory):
    for line in lines:
        sha, filename = line.split(maxsplit=1)
        if hashlib.sha256((directory/filename.strip()).read_bytes()).hexdigest() != sha:
            raise ValueError(f"Checksum mismatch for {filename}")


def main():
    if not __debug__:
        raise SystemExit("Run verify_data.py with Python assertions enabled.")
    digests((ROOT/"SHA256SUMS").read_text().splitlines(),ROOT)
    digests((ROOT/"remote/source-sha256.txt").read_text().splitlines(),ROOT)
    fanout = ROOT/"fanout"
    digests((fanout/"pre-timing.txt").read_text().splitlines()[1:],fanout)
    same(run(fanout/"freeze.py",cwd=fanout),fanout/"prediction.json")
    same(run(fanout/"summarize.py",fanout/"results",cwd=fanout),fanout/"results/summary.csv")
    for script, name in (("tower_certificate", "tower_vectors"), ("dyadic_lifts","dyadic_lifts")):
        same(run(ROOT/"review"/(script+".py")),ROOT/"review"/(name+".json"))
    run(ROOT/"catalog/check_catalog.py")
    run(ROOT/"history/verify_history.py")
    same(run(ROOT/"placement/check.py"), ROOT/"placement/exhaustive.txt")
    with TemporaryDirectory() as temp:
        scratch = Path(temp)
        for group in ("placement",):
            shutil.copytree(ROOT/group, scratch/group)
            same(run(scratch/group/"holdout.py"),ROOT/group/"holdout-summary.txt")
            same((scratch/group/"holdout.csv").read_bytes(),ROOT/group/"holdout.csv")
        for platform in ("arm", "remote"):
            src = ROOT if platform == "arm" else ROOT/"remote"
            dest = scratch/platform
            for stage in ("fri", "linear"):
                data = dest/stage/"results"
                data.mkdir(parents=True)
                for f in (src/stage/"results").glob("seed-*.csv"):
                    shutil.copy(f,data)
                if stage == "fri":
                    summary = run(ROOT/"fri/verify.py",data)
                    (data/"summary.csv").write_bytes(summary)
                else:
                    shutil.copy(ROOT/"linear/summarize.py",data.parent)
                    run(data.parent/"summarize.py")
                same((data/"summary.csv").read_bytes(),src/stage/"results/summary.csv")
        run(ROOT/"remote/compare.py",scratch/"arm",scratch/"remote")
        for s in ("linear","fri"):
            name = s+"-architecture-comparison.csv"
            same((scratch/"remote"/name).read_bytes(), ROOT/"remote"/name)
        pr = scratch/"proof"
        shutil.copytree(ROOT/"proof/results",pr/"results")
        shutil.copy(ROOT/"proof/summarize.py",pr)
        run(pr/"summarize.py")
        same((pr/"results/medians.csv").read_bytes(), ROOT/"proof/results/medians.csv")
    print("PASS: archive and remote hashes, tower certificates, catalog, optimizer, frozen predictions, ARM and x86 summaries, and proof-transport medians.")


if __name__ == "__main__":
    main()
