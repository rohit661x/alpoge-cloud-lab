"""Offline evidence replay. Run this with stock Python 3.11+ from the extracted kit."""
from collections import Counter
from hashlib import sha256
from pathlib import Path
import json
import subprocess
import sys
import tempfile


def run(script,*args):
    subprocess.run([sys.executable,str(script),*map(str,args)],check=True,stdout=subprocess.DEVNULL)


def read(p):
    return json.loads(p.read_text())


def main():
    base=Path(__file__).resolve().parent
    for row in (base/'SHA256SUMS').read_text().splitlines():
        digest,name=row.split('  ',1)
        if sha256((base/name).read_bytes()).hexdigest()!=digest:
            raise ValueError(f'digest mismatch: {name}')
    w=base/'work/switchtrial'
    run_roots=[w/'run',w/'lazy-run']
    hist=Counter()
    for file in sorted((w/'external/shards').glob('*.json')):
        shard=read(file)
        assert sum(shard['counts'].values()) == shard['rows']
        hist.update(shard['counts'])
    saved=read(w/'external/histogram.json')
    assert dict(hist)==saved['counts'] and sum(hist.values())==saved['n']
    with tempfile.TemporaryDirectory() as folder:
        t=Path(folder)
        run(w/'audit/verify.py','--run',run_roots[0],'--out',t/'audit','--require-complete')
        for file in (t/'audit').iterdir():
            assert file.read_bytes()==(w/'results/audit'/file.name).read_bytes(),file.name
        run(w/'harness/lazy_audit.py','--run',run_roots[1],'--out',t/'lazy-audit.json')
        run(w/'audit/crosscheck_lazy.py','--primary',run_roots[0],'--lazy',run_roots[1],
            '--reported',t/'lazy-audit.json','--out',t/'lazy-crosscheck.json')
        for cohort, name in zip(run_roots,['main','lazy']):
            run(w/'results_extra.py','--run',cohort,'--out',t/(name+'-extra.json'))
            run(w/'landmark/score.py','--run',cohort,'--out',t/(name+'-landmark'))
            dest=w/'results' if name=='main' else w/'results/lazy-landmark'
            for n in ['landmark.json','landmark.csv']:
                assert (t/(name+'-landmark')/n).read_bytes()==(dest/n).read_bytes()
            run(w/'external/score.py','--run',cohort,'--out',t/(name+'-external.json'))
        for f in t.glob('*.json'):
            assert f.read_bytes()==(w/'results'/f.name).read_bytes(),f.name
        # A separate raw-receipt reconstruction matches weighted primary times from both auditors.
        e=read(t/'main-extra.json')['laws']['primary']['latency_ms']
        audited=read(t/'audit/summary.json')['primary']['elapsed_ns']['mean_by_arm']
        l=read(t/'lazy-extra.json')['laws']['primary']['latency_ms']
        l_audited=read(t/'lazy-audit.json')['mean_by_arm']
        assert max(abs(e[k]-audited[k]/1e6) for k in e) < 1e-7
        assert max(abs(l[k]-l_audited[k]['mixture_s']*1000) for k in l) < 1e-7
    print('PASS: archive hashes, primary and on-demand audits, landmark, external length scores and 1,536 encrypted prediction records.')


if __name__=='__main__':
    main()
