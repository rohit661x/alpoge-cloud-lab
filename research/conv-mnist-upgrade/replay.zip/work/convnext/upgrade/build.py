"""Build the small native adapter against the exact companion TenSEAL/SEAL checkout."""
import argparse
from pathlib import Path
import shutil
import subprocess
import sysconfig

HERE = Path(__file__).resolve().parent

def build(companion):
    patched = companion.resolve()/'patched'
    deps = patched/'deps'
    seal = deps/'com_microsoft_seal'
    built = patched/'build/_deps/com_microsoft_seal-build'
    lib = built/'lib'
    includes = [sysconfig.get_paths()['include'], deps/'com_pybind_pybind11/include',
                seal/'native/src', built/'native/src', deps/'msgsl/include']
    output = HERE/('_conv_key_update' + sysconfig.get_config_var('EXT_SUFFIX'))
    cmd = [shutil.which('c++') or 'c++','-std=c++17','-O2','-fPIC','-fvisibility=hidden']
    if sysconfig.get_platform().startswith('macosx'):
        cmd += ['-bundle', '-undefined', 'dynamic_lookup']
    else:
        cmd += ['-shared']
    cmd += ['-I'+str(p) for p in includes]
    cmd += [str(HERE/'install_one.cpp'),str(lib/'libseal-4.3.a'),str(lib/'libzstd.a'),str(lib/'libz.a'),'-o',str(output)]
    subprocess.run(cmd, check=True)
    print(output.name)

if __name__=='__main__':
    a=argparse.ArgumentParser(description=__doc__);a.add_argument('--companion',type=Path,required=True)
    build(a.parse_args().companion)
