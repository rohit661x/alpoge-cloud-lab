#include <pybind11/pybind11.h>
#include <seal/seal.h>

#include <cstdint>
#include <sstream>
#include <stdexcept>
#include <string>

namespace py = pybind11;

// Load and validate one public rotation key before modifying the resident catalog.
// The caller supplies the expected element for this model and session transition.
std::size_t install_one(seal::GaloisKeys &resident, const seal::SEALContext &context,
                        py::bytes serialized, std::uint32_t element) {
    std::string input = serialized;
    std::istringstream stream(input, std::ios::binary);
    seal::GaloisKeys delta;
    auto consumed = delta.load(context, stream);
    if (static_cast<std::size_t>(consumed) != input.size() ||
        delta.parms_id() != resident.parms_id() || delta.size() != 1 ||
        !delta.has_key(element) || resident.has_key(element)) {
        throw std::invalid_argument("unexpected rotation-key update");
    }
    auto index = seal::GaloisKeys::get_index(element);
    if (index >= resident.data().size()) {
        throw std::invalid_argument("missing destination slot");
    }
    resident.data()[index].swap(delta.data()[index]);
    return resident.size();
}

PYBIND11_MODULE(_conv_key_update, m) {
    m.def("install_one", &install_one);
    m.def("serialize_public_keys", [](const seal::GaloisKeys &keys) {
        std::ostringstream wire(std::ios::binary);
        keys.save(wire);
        return py::bytes(wire.str());
    });
}
