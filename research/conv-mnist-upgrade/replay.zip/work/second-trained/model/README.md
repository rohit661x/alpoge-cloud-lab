# TenSEAL ConvMNIST 0.1 checkpoint and MNIST test fixtures

OpenMined publishes 17,298 learned parameters in `tutorials/parameters/ConvMNIST-0.1.pickle`. The release tag v0.3.18 resolves to `c962074f0aa82cf30eeaddf17af887a8ea0e66fe`. Its benchmark loads this file, normalizes grayscale pixels as `(pixel / 255 − 0.1307) / 0.3081`, and evaluates a 1-to-4 valid 7×7 cross-correlation at stride 3, a square, a 256-to-64 affine layer, a second square and a 64-to-10 affine layer. Each affine layer has a learned bias. Channel, row and column order matches the PyTorch flatten operation. The tutorial notebook illustrates the architecture with a separate training run. [Checkpoint](https://github.com/OpenMined/TenSEAL/blob/c962074f0aa82cf30eeaddf17af887a8ea0e66fe/tutorials/parameters/ConvMNIST-0.1.pickle) · [Checkpoint-specific evaluator and normalization](https://github.com/OpenMined/TenSEAL/blob/c962074f0aa82cf30eeaddf17af887a8ea0e66fe/tests/python/benchmarks/test_mnist_eval.py) · [Tutorial 4](https://github.com/OpenMined/TenSEAL/blob/c962074f0aa82cf30eeaddf17af887a8ea0e66fe/tutorials/Tutorial%204%20-%20Encrypted%20Convolution%20on%20MNIST.ipynb)

The fixtures use the first eight records in stored order from the canonical 10,000-image test split. The recorded labels are 7, 2, 1, 0, 4, 1, 4, 9. The portable scalar reference normalizes and computes logits in binary64. PyTorch 2.7.1 CPU in binary32 classified 9,777 of all 10,000 images correctly. For the first eight, its classes agree with the scalar reference and the labels. The maximum deviation across the 80 logits from the scalar reference is 2.26 × 10⁻⁵ with PyTorch binary32 and 1.78 × 10⁻¹⁴ with binary64. Exact scores and class counts are in `framework-validation.json`. [MNIST test split and image source](https://github.com/cvdfoundation/mnist)

## Reproduce the data

Run Python 3.10+ from this directory. The first command accepts `--fetch` to download missing source files. It verifies all three SHA-256 digests before reading or unpickling data. The second command requires PyTorch and evaluates the whole test split.

```sh
python3 prepare_model.py --fetch
python3 validate_framework.py
```

`weights.bin` contains contiguous little-endian binary64 values in C row-major order. From the beginning, the shapes are conv kernel [4,1,7,7], conv bias [4], FC1 weights [64,256], FC1 bias [64], FC2 weights [10,64], and FC2 bias [10]. The upstream dense arrays use the opposite matrix orientation. The preparation script transposes these arrays during export. `samples.bin` contains 8 × 784 unmodified raw image bytes, `labels.bin` contains 8 raw label bytes, and `logits.bin` contains 8 × 10 contiguous little-endian binary64 logits. The JSON alternatives contain the same weights, normalized images, labels, and logits, with their shapes preserved. `derived.sha256` contains output digests.

## Effect of the published FC1 bias addition

`bias_effect.py` evaluates the published slot layout in float64 before any homomorphic approximation. It compares all 10,000 inputs against the intended dense-layer graph using the same checkpoint. Both graphs classify 9,777 inputs correctly. Their predicted classes differ at exactly five zero-based test indices (659, 2185, 2573, 2995, 3550), and their largest absolute difference across 100,000 logits is 0.1996993. The first-eight maximum absolute logit difference is 0.0612305. The underlying issue is visible in the rectangular dense product after the 64-entry FC1 bias vector has been added only to the first 64 physical slots. `bias-effect.json` contains the exact measured values and the first eight source-default ideal logits. [Bias addition](https://github.com/OpenMined/TenSEAL/blob/c962074f0aa82cf30eeaddf17af887a8ea0e66fe/tenseal/cpp/tensors/ckksvector.cpp#L269-L295) · [Matrix product](https://github.com/OpenMined/TenSEAL/blob/c962074f0aa82cf30eeaddf17af887a8ea0e66fe/tenseal/cpp/tensors/encrypted_vector.h#L182-L217)

## Attribution

OpenMined TenSEAL provides its benchmark, tutorial and checkpoint under Apache 2.0. The original license is enclosed as `TenSEAL-LICENSE`. The weights here are a representation conversion from the upstream checkpoint.

Yann LeCun, Corinna Cortes and Christopher J. C. Burges created the MNIST handwritten digit database from NIST data. Yann LeCun and Corinna Cortes hold the MNIST copyright. The raw and normalized image excerpts in this directory are shared under the Creative Commons Attribution-ShareAlike 3.0 license. [Dataset license and attribution](https://keras.io/api/datasets/mnist/) · [CC BY-SA 3.0 license](https://creativecommons.org/licenses/by-sa/3.0/)
