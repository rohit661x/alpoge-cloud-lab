"""Measure the source-default slot-bias effect in real arithmetic on MNIST."""

import json

import torch
from torch.nn import functional as f

from prepare_model import CHECKPOINT, IMAGES, LABELS, ROOT, load_checked, parameters, test_set


def main():
    p = parameters(load_checked(ROOT, CHECKPOINT, False))
    weights = {key: torch.tensor(value, dtype=torch.float64) for key, value in p.items()}
    data, target = test_set(load_checked(ROOT, IMAGES, False), load_checked(ROOT, LABELS, False))
    images = torch.frombuffer(bytearray(data), dtype=torch.uint8).reshape(-1, 1, 28, 28)
    target = torch.frombuffer(bytearray(target), dtype=torch.uint8)
    corrected = []
    source = []
    torch.set_num_threads(1)
    with torch.inference_mode():
        for batch in images.split(256):
            x = (batch.double() / 255.0 - 0.1307) / 0.3081
            x = f.conv2d(x, weights["conv"], weights["conv_bias"], stride=3)
            u = f.linear(x.square().flatten(1), weights["fc1"])
            h = (u + weights["fc1_bias"]).square()
            corrected.append(f.linear(h, weights["fc2"], weights["fc2_bias"]))
            # In output j, incoming physical slots are j..j+63. The wrapped
            # logical inputs 0..j-1 use a replica without the FC1 bias.
            vals = []
            for j in range(10):
                phys = torch.cat([h[:, j:], u[:, :j].square()], 1)
                wr = torch.cat([weights["fc2"][j, j:], weights["fc2"][j, :j]])
                vals.append(f.linear(phys, wr.unsqueeze(0), weights["fc2_bias"][j:j+1]))
            source.append(torch.cat(vals, 1))
    corrected = torch.cat(corrected)
    source = torch.cat(source)
    reference_label = corrected.argmax(1)
    source_label = source.argmax(1)
    mismatch = source_label != reference_label
    magnitude = (source - corrected).abs()
    report = {
        "n": len(target),
        "torch": str(torch.__version__),
        "precision": "float64",
        "trained_correct": (reference_label == target).sum().item(),
        "source_default_ideal_arithmetic_correct": (source_label == target).sum().item(),
        "top1_disagreements": mismatch.sum().item(),
        "first_disagreement_indices": mismatch.nonzero().flatten()[:10].tolist(),
        "max_abs_logit_delta_all": magnitude.max().item(),
        "max_abs_logit_delta_first8": magnitude[:8].amax(1).tolist(),
        "source_default_ideal_first8": source[:8].tolist(),
    }
    (ROOT / "bias-effect.json").write_text(json.dumps(report, indent=2) + "\n")
    print({k:v for k,v in report.items() if k != "source_default_ideal_first8"})


if __name__ == "__main__":
    main()
