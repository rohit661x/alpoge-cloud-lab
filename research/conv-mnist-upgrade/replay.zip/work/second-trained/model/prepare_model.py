#!/usr/bin/env python3
"""Derive the checkpoint and first eight MNIST fixtures from pinned source bytes."""

import argparse
import gzip
import hashlib
import io
import json
import math
import pickle
import struct
import urllib.request
from pathlib import Path

ROOT = Path(__file__).resolve().parent
COMMIT = "c962074f0aa82cf30eeaddf17af887a8ea0e66fe"
RAW = f"https://raw.githubusercontent.com/OpenMined/TenSEAL/{COMMIT}"
MNIST = "https://storage.googleapis.com/cvdf-datasets/mnist"
CHECKPOINT = "ConvMNIST-0.1.pickle"
IMAGES = "t10k-images-idx3-ubyte.gz"
LABELS = "t10k-labels-idx1-ubyte.gz"
SOURCES = {
    CHECKPOINT: (f"{RAW}/tutorials/parameters/{CHECKPOINT}", "3732916e8ebcb57978ba1b029073f043b8b6b59651413c6de7612a34311a67d3"),
    IMAGES: (f"{MNIST}/{IMAGES}", "8d422c7b0a1c1c79245a5bcf07fe86e33eeafee792b84584aec276f5a2dbc4e6"),
    LABELS: (f"{MNIST}/{LABELS}", "f7ae60f92e00ec6debd23a6088c31dbd2371eca3ffa0defaefb259924204aec6"),
}
SHAPES = {
    "conv": (4, 1, 7, 7),
    "conv_bias": (4,),
    "fc1": (64, 256),
    "fc1_bias": (64,),
    "fc2": (10, 64),
    "fc2_bias": (10,),
}


def sha256(data):
    return hashlib.sha256(data).hexdigest()


def load_checked(directory, name, fetch):
    url, expected = SOURCES[name]
    path = directory / name
    if path.exists():
        data = path.read_bytes()
    elif fetch:
        with urllib.request.urlopen(url, timeout=40) as response:
            data = response.read()
        if sha256(data) == expected:
            path.write_bytes(data)
    else:
        raise FileNotFoundError(f"{path} is missing. Pass --fetch to obtain the source inputs.")
    if sha256(data) != expected:
        raise ValueError(f"Source digest mismatch for {name}")
    return data


class DataOnlyUnpickler(pickle.Unpickler):
    def find_class(self, module, name):
        raise ValueError("Unexpected class in numeric checkpoint")


def flatten(array, shape):
    if not shape:
        if not isinstance(array, float) or not math.isfinite(array):
            raise ValueError("Expected a finite checkpoint value")
        yield array
        return
    if len(array) != shape[0]:
        raise ValueError(f"Array shape differs from {shape}")
    for row in array:
        yield from flatten(row, shape[1:])


def parameters(checkpoint):
    data = DataOnlyUnpickler(io.BytesIO(checkpoint)).load()
    if data["windows_nb"] != 64:
        raise ValueError("Unexpected window count")
    return {
        "conv": [[kernel] for kernel in data["conv1_weight"]],
        "conv_bias": data["conv1_bias"],
        "fc1": list(zip(*data["fc1_weight"], strict=True)),
        "fc1_bias": data["fc1_bias"],
        "fc2": list(zip(*data["fc2_weight"], strict=True)),
        "fc2_bias": data["fc2_bias"],
    }


def normalize(image):
    return [(pixel / 255.0 - 0.1307) / 0.3081 for pixel in image]


def plain_forward(image, weights):
    # Cross-correlation uses PyTorch's (channel, row, col) flatten order.
    activations = []
    for channel, bias in zip(weights["conv"], weights["conv_bias"], strict=True):
        kernel = channel[0]
        for y in range(0, 22, 3):
            for x in range(0, 22, 3):
                dot = math.fsum(kernel[i][j] * image[(y + i) * 28 + x + j]
                                for i in range(7) for j in range(7))
                activations.append((bias + dot) ** 2)

    def linear(inputs, rows, biases):
        return [bias + math.fsum(a * b for a, b in zip(inputs, row, strict=True))
                for row, bias in zip(rows, biases, strict=True)]

    hidden = linear(activations, weights["fc1"], weights["fc1_bias"])
    return linear([value ** 2 for value in hidden], weights["fc2"], weights["fc2_bias"])


def test_set(images, labels):
    images = gzip.decompress(images)
    labels = gzip.decompress(labels)
    if struct.unpack(">IIII", images[:16]) != (2051, 10000, 28, 28):
        raise ValueError("Unexpected image IDX header")
    if struct.unpack(">II", labels[:8]) != (2049, 10000):
        raise ValueError("Unexpected label IDX header")
    if len(images) != 16 + 10000 * 784 or len(labels) != 8 + 10000:
        raise ValueError("Unexpected IDX length")
    return images[16:], labels[8:]


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--source-dir", type=Path, default=ROOT)
    parser.add_argument("--out", type=Path, default=ROOT)
    parser.add_argument("--fetch", action="store_true")
    args = parser.parse_args()
    args.source_dir.mkdir(parents=True, exist_ok=True)
    args.out.mkdir(parents=True, exist_ok=True)
    weights = parameters(load_checked(args.source_dir, CHECKPOINT, args.fetch))
    weights_flat = [v for key, shape in SHAPES.items() for v in flatten(weights[key], shape)]
    images, labels = test_set(load_checked(args.source_dir, IMAGES, args.fetch),
                              load_checked(args.source_dir, LABELS, args.fetch))
    samples = []
    for index in range(8):
        image = normalize(images[index * 784:(index + 1) * 784])
        samples.append(dict(index=index, label=labels[index], input=image,
                            logits=plain_forward(image, weights)))
    logits = [v for row in samples for v in row["logits"]]

    def json_bytes(value):
        return (json.dumps(value, separators=(",", ":"), allow_nan=False) + "\n").encode()

    outputs = {
        "weights.bin": struct.pack(f"<{len(weights_flat)}d", *weights_flat),
        "weights.json": json_bytes(weights),
        "samples.bin": images[:8 * 784],
        "labels.bin": labels[:8],
        "logits.bin": struct.pack(f"<{len(logits)}d", *logits),
        "samples.json": json_bytes(samples),
    }
    for name, contents in outputs.items():
        (args.out / name).write_bytes(contents)
    hashes = "".join(f"{sha256(contents)}  {name}\n" for name, contents in outputs.items())
    (args.out / "derived.sha256").write_text(hashes)
    for row in samples:
        predictions = row["logits"]
        print(row["index"], row["label"], max(range(10), key=predictions.__getitem__),
              f"{max(predictions):.10f}")
    print(hashes, end="")


if __name__ == "__main__":
    main()
