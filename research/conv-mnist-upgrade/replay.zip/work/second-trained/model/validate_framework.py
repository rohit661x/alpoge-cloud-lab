#!/usr/bin/env python3
"""Compare the eight portable fixtures to PyTorch and score the public checkpoint."""

import argparse
import json
from pathlib import Path

import torch
from torch.nn import functional as F

from prepare_model import CHECKPOINT, IMAGES, LABELS, ROOT, load_checked, parameters, test_set


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--source-dir", type=Path, default=ROOT)
    parser.add_argument("--out", type=Path, default=ROOT)
    args = parser.parse_args()
    model = parameters(load_checked(args.source_dir, CHECKPOINT, False))
    image_bytes, label_bytes = test_set(load_checked(args.source_dir, IMAGES, False),
                                        load_checked(args.source_dir, LABELS, False))
    images = torch.frombuffer(bytearray(image_bytes), dtype=torch.uint8).reshape(-1, 1, 28, 28)
    labels = torch.frombuffer(bytearray(label_bytes), dtype=torch.uint8)
    fixtures = json.loads((args.out / "samples.json").read_text())
    reference = torch.tensor([sample["logits"] for sample in fixtures], dtype=torch.float64)

    def logits(batch, dtype):
        w = {k: torch.tensor(v, dtype=dtype) for k, v in model.items()}
        x = (batch.to(dtype) / 255.0 - 0.1307) / 0.3081
        x = F.conv2d(x, w["conv"], w["conv_bias"], stride=3)
        x = F.linear(x.square().flatten(1), w["fc1"], w["fc1_bias"])
        return F.linear(x.square(), w["fc2"], w["fc2_bias"])

    torch.set_num_threads(1)
    with torch.inference_mode():
        f64 = logits(images[:len(fixtures)], torch.float64)
        f32 = torch.cat([logits(batch, torch.float32) for batch in images.split(256)])
        predicted = f32.argmax(1)
        correct = predicted == labels
        result = {
            "torch": str(torch.__version__),
            "device": "CPU",
            "full_test": {
                "samples": len(labels),
                "correct_float32": int(correct.sum()),
                "by_digit_correct": [int(correct[labels == digit].sum()) for digit in range(10)],
                "by_digit_total": [int((labels == digit).sum()) for digit in range(10)],
            },
            "first_eight": {
                "indices": [row["index"] for row in fixtures],
                "labels": labels[:len(fixtures)].tolist(),
                "predicted_f32": predicted[:len(fixtures)].tolist(),
                "max_abs_error_vs_portable_f64": {
                    "torch_f64": (f64 - reference).abs().max().item(),
                    "torch_f32": (f32[:len(fixtures)].double() - reference).abs().max().item(),
                },
                "min_top_two_margin_f64": min(x[0] - x[1] for x in reference.topk(2).values.tolist())
            }
        }
    if result["first_eight"]["max_abs_error_vs_portable_f64"]["torch_f64"] > 1e-10:
        raise ValueError("Portable reference differs from PyTorch float64")
    if predicted[:len(fixtures)].tolist() != reference.argmax(1).tolist():
        raise ValueError("Framework and portable classifications differ")
    (args.out / "framework-validation.json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
