# Patched TenSEAL extension for the full-operator comparison

The CPython extension builds from the OpenMined/TenSEAL v0.3.18 tag, commit `c962074f0aa82cf30eeaddf17af887a8ea0e66fe`, with Microsoft SEAL v4.3.3 and the dependency revisions declared upstream. The two patches implement independent experiment controls. [Upstream release](https://github.com/OpenMined/TenSEAL/tree/c962074f0aa82cf30eeaddf17af887a8ea0e66fe)

* `rotation-repair.patch` checks each positive even rotation in the encrypted matrix/plain vector reduction used by convolution. If the direct Galois key exists, it uses the original rotation. If only the half-step key exists, it rotates twice by that half step and performs the original accumulation afterward. A missing pair raises an error. This path allows a missing +2048 key with +1024 present and a missing +512 key with +256 present.
* `periodic-plaintext.patch` adds `CKKSVector.add_plain_periodic_` on the native Python object. Given a plaintext vector of matching logical length, it cyclically repeats the vector to the available slots, then calls the existing plaintext addition implementation. It is selected only by an explicit call. Use `hidden.data.add_plain_periodic_(fc1_bias)` after the first dense product and before squaring in every arm of a corrected-model comparison. The original `hidden += fc1_bias` preserves the published benchmark operation. The final 10-entry bias needs only the ten reported logits.

For each final class j, the subsequent dense product reads physical slots j through j+63. Standard 64-entry plaintext addition zero-pads the bias after slot 63, while the unshifted FC1 dot products already repeat with period 64. Thus in exact arithmetic the published implementation uses the unbiased value for hidden coordinates 0 through j−1 in class j. Writing u for the FC1 dot products, b for the FC1 bias and W for the FC2 matrix in output-by-input order, the published logit minus the trained logit is `−sum(W[j,r]*(2*u[r]*b[r]+b[r]²), r < j)`. Periodic addition supplies the missing bias to all physical replicas. [Bias addition](https://github.com/OpenMined/TenSEAL/blob/c962074f0aa82cf30eeaddf17af887a8ea0e66fe/tenseal/cpp/tensors/ckksvector.cpp#L269-L295) · [Rectangular matrix diagonal indexing](https://github.com/OpenMined/TenSEAL/blob/c962074f0aa82cf30eeaddf17af887a8ea0e66fe/tenseal/cpp/tensors/encrypted_vector.h#L182-L217)

## Build and import

Use a C++17 toolchain, CMake 3.31, curl, git and a Python 3.12 environment containing `tenseal==0.3.18`. From this directory run

```sh
CMAKE_BIN="$(command -v cmake)" PYTHON_BIN="$(command -v python3.12)" ./build_extension.sh
PYTHONPATH="$PWD/lib" python3.12 -c 'import _tenseal_cpp as native; print(native.__file__, hasattr(native.CKKSVector, "add_plain_periodic_"))'
```

The module path should end in the build directory's `lib/_tenseal_cpp…so`. Keep this PYTHONPATH for client and server processes. The v0.3.18 Python package and its standard sealapi extension continue to come from the Python environment. `build_extension.sh` pins the exact TenSEAL commit, downloads its upstream dependencies, and uses up to two compilation workers. Source archives, the generated extension and all build products live beneath this directory.
