#!/usr/bin/env bash
set -euo pipefail
root="$(cd "$(dirname "$0")" && pwd)"
cmake_bin="${CMAKE_BIN:-cmake}"
python_bin="${PYTHON_BIN:-python3.12}"
export CMAKE_BUILD_PARALLEL_LEVEL=2
# Nested protobuf CMake also builds during configure. Restrict both phases.
export CMAKE_POLICY_VERSION_MINIMUM=3.5
export MACOSX_DEPLOYMENT_TARGET="${MACOSX_DEPLOYMENT_TARGET:-14.0}"
if [ ! -d "$root/upstream/.git" ]; then
    git clone --depth=1 --branch v0.3.18 https://github.com/OpenMined/TenSEAL.git "$root/upstream"
fi
test "$(git -C "$root/upstream" rev-parse HEAD)" = c962074f0aa82cf30eeaddf17af887a8ea0e66fe
for patch in rotation-repair.patch periodic-plaintext.patch; do
    if ! git -C "$root/upstream" apply --reverse --check "$root/$patch" 2>/dev/null; then
        git -C "$root/upstream" apply "$root/$patch"
    fi
done
"$python_bin" "$root/fetch_dependencies.py" "$root/deps"
args=()
while IFS= read -r arg; do args+=("$arg"); done < "$root/deps/configure-args.txt"
"$cmake_bin" -S "$root/upstream" -B "$root/build" -DCMAKE_BUILD_TYPE=Release \
    -DPYTHON_EXECUTABLE="$python_bin" -DCMAKE_LIBRARY_OUTPUT_DIRECTORY="$root/lib" \
    -DSEAL_USE_INTEL_HEXL=OFF "${args[@]}"
"$cmake_bin" --build "$root/build" --target _tenseal_cpp --parallel 2
