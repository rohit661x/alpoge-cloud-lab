"""Fetch the upstream release's build dependencies to an isolated directory."""
import concurrent.futures
import hashlib
import tempfile
from pathlib import Path
import subprocess
import sys

root = Path(sys.argv[1]).resolve()
root.mkdir(parents=True, exist_ok=True)
repos = {
    "com_microsoft_seal": ("microsoft/SEAL", "v4.3.3"),
    "protocolbuffers_protobuf": ("protocolbuffers/protobuf", "v3.15.8"),
    "com_pybind_pybind11": ("pybind/pybind11", "v2.12.0"),
    "com_nlohmann_json": ("nlohmann/json", "v3.9.1"),
    "com_xtensorstack_xtl": ("xtensor-stack/xtl", "0.7.2"),
    "com_xtensorstack_xsimd": ("xtensor-stack/xsimd", "7.4.10"),
    "com_xtensorstack_xtensor": ("xtensor-stack/xtensor", "0.23.5"),
    "msgsl": ("microsoft/GSL", "249146590e322123cd0b378b1f364d6069717687"),
    "zlib": ("madler/zlib", "da607da739fa6047df13e66a2af6b8bec7c2a498"),
    "zstd": ("facebook/zstd", "f8745da6ff1ad1e7bab384bd1f9d742439278e99"),
}


DIGESTS = {
    "com_microsoft_seal": "423e5fde0e49c761785ebd849dc0c71fcd94ce2c663f1d52e0fe01a60e0fea80",
    "com_nlohmann_json": "4cf0df69731494668bdd6460ed8cb269b68de9c19ad8c27abc24cd72605b2d5b",
    "com_pybind_pybind11": "bf8f242abd1abcd375d516a7067490fb71abd79519a282d22b6e4d19282185a7",
    "com_xtensorstack_xsimd": "df00f476dea0c52ffebad60924e3f0db2a016b80d508f8d5a2399a74c0d134cd",
    "com_xtensorstack_xtensor": "0811011e448628f0dfa6ebb5e3f76dc7bf6a15ee65ea9c5a277b12ea976d35bc",
    "com_xtensorstack_xtl": "95c221bdc6eaba592878090916383e5b9390a076828552256693d5d97f78357c",
    "msgsl": "24939a9943762e428f6242dd11fed9e0df843219157d04c4e93bab1186cd8ff4",
    "protocolbuffers_protobuf": "0cbdc9adda01f6d2facc65a22a2be5cecefbefe5a09e5382ee8879b522c04441",
    "zlib": "b9258cf6254e7f7c37f1cd61dba943a1c5ea3cff5718c789834dac359094f5f7",
    "zstd": "4b0bd1f0cfb25e61b9103c35f27395530ff5b4c0d2513a00fd745849e85ea52c",
}


def fetch(item):
    name, (repo, revision) = item
    path = root / name
    digest = DIGESTS[name]
    marker = path / ".source-sha256"
    if marker.exists() and marker.read_text().strip() == digest:
        return
    if path.exists():
        raise ValueError(f"Existing dependency tree {path} has no matching source digest")
    archive = root / (name + ".tar.gz")
    if not archive.exists():
        subprocess.run(["curl", "-fsSL", "--retry", "2",
                        f"https://codeload.github.com/{repo}/tar.gz/{revision}",
                        "-o", str(archive)], check=True)
    if hashlib.sha256(archive.read_bytes()).hexdigest() != digest:
        raise ValueError(f"Source digest mismatch for {archive}")
    with tempfile.TemporaryDirectory(dir=root) as staging:
        extracted = Path(staging) / name
        extracted.mkdir()
        subprocess.run(["tar", "-xzf", str(archive), "-C", str(extracted),
                        "--strip-components=1"], check=True)
        (extracted / marker.name).write_text(digest + "\n")
        extracted.rename(path)
    print(name, revision, flush=True)


with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
    list(pool.map(fetch, repos.items()))
(root / "configure-args.txt").write_text("\n".join(f"-DFETCHCONTENT_SOURCE_DIR_{name.upper()}={root/name}" for name in repos) + "\n")
