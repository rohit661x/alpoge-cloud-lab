"""Send official TenSEAL public contexts and encrypted predictions over a real loopback connection."""
import argparse
import gc
import hashlib
import json
import multiprocessing as mp
import os
from pathlib import Path
import socket
import struct
import tempfile
import time
import traceback

import numpy as np
import tenseal as ts
import tenseal.sealapi as sa

HEADER = struct.Struct('!BBQ')
ROOT = Path(__file__).resolve().parents[1]
SINGLE = [2**i for i in range(12)]+[-(2**i) for i in range(7)]
ARMS = {'default':0,'pruned':1,'split':2,'split17':3}

def send(s,kind,arm,data,mbps=0):
    header=HEADER.pack(kind,arm,len(data))
    s.sendall(header)
    if mbps and data:
        # Application upload pacing across frame bytes on a physical TCP socket.
        # Absolute deadlines prevent cumulative sleep drift and a free final burst.
        start=time.perf_counter()
        raw=memoryview(data)
        for i in range(0,len(data),64*1024):
            chunk=raw[i:i+64*1024]
            deadline=start+8*(len(header)+i+len(chunk))/(mbps*1e6)
            remaining=deadline-time.perf_counter()
            if remaining>0:time.sleep(remaining)
            s.sendall(chunk)
    else:s.sendall(data)
    return len(header)+len(data)

def take(s,n):
    buf=bytearray(n); view=memoryview(buf)
    while view:
        count=s.recv_into(view)
        if count==0:raise EOFError('incomplete TCP frame')
        view=view[count:]
    return buf

def receive(s):
    op,arm,length=HEADER.unpack(take(s,HEADER.size))
    if length>400_000_000:raise ValueError('oversized frame')
    return op,arm,bytes(take(s,length)),length+HEADER.size

class Classifier:
    def __init__(self,periodic):
        self.periodic=periodic
        weights=json.loads((ROOT/'model/weights.json').read_text())
        self.k=np.array(weights['conv'])[:,0].tolist()
        self.b=weights['conv_bias']
        self.d1=np.array(weights['fc1']).T.tolist()
        self.b1=weights['fc1_bias']
        self.d2=np.array(weights['fc2']).T.tolist()
        self.b2=weights['fc2_bias']
    def forward(self,ct):
        channels=[ct.conv2d_im2col(k,64)+b for k,b in zip(self.k,self.b)]
        flat=ts.CKKSVector.pack_vectors(channels)
        flat.square_()
        h=flat.mm(self.d1)
        if self.periodic:h.data.add_plain_periodic_(self.b1)
        else:h=h+self.b1
        h.square_()
        return h.mm(self.d2)+self.b2

def server(ready,periodic):
    model=Classifier(periodic)
    with socket.socket() as listener:
        listener.bind(('127.0.0.1',0));listener.listen(1)
        ready.send(listener.getsockname()[1]);ready.close()
        s,_=listener.accept()
        with s:
            s.setsockopt(socket.IPPROTO_TCP,socket.TCP_NODELAY,1)
            contexts={}
            while True:
                kind,arm,data,n=receive(s)
                if kind==0:return
                try:
                    if kind==1:
                        ctx=ts.context_from(data,n_threads=1)
                        assert not ctx.is_private() and ctx.has_galois_keys() and ctx.has_relin_keys()
                        contexts[arm]=ctx
                        response=json.dumps({'received':n,'keys':ctx.galois_keys().data.size()}).encode()
                    elif kind==2:
                        start=time.perf_counter_ns()
                        ct=ts.ckks_vector_from(contexts[arm],data)
                        out=model.forward(ct).serialize()
                        ns=time.perf_counter_ns()-start
                        response=struct.pack('!QQ',n,ns)+out
                    else:raise ValueError(kind)
                    send(s,kind,arm,response)
                except Exception:
                    send(s,255,arm,traceback.format_exc().encode())
                    return

def getctx():
    ctx=ts.context(ts.SCHEME_TYPE.CKKS,poly_modulus_degree=8192,
                   coeff_mod_bit_sizes=[31]+[26]*6+[31], n_threads=1)
    ctx.global_scale=2**26
    return ctx

def install_keys(ctx,arm):
    if arm=='default':
        ctx.generate_galois_keys()
    else:
        omit={'pruned':set(),'split':{2048},'split17':{2048,512}}[arm]
        directions=[v for v in SINGLE if v not in omit]
        kg=sa.KeyGenerator(ctx.seal_context().data,ctx.secret_key().data)
        keys=sa.GaloisKeys()
        elements=[pow(3,s%4096,16384) for s in directions]
        kg.create_galois_keys(elements,keys)
        assert keys.size()==len(elements) and all(keys.has_key(g) for g in elements)
        with tempfile.TemporaryDirectory() as d:
            p=str(Path(d)/'public.keys')
            keys.save(p)
            ctx.galois_keys().data.load(ctx.seal_context().data,p)

def check_reply(s,kind,tag):
    op,arm,data,num=receive(s)
    if op==255:raise RuntimeError(data.decode())
    assert (op,arm)==(kind,tag)
    return data,num

def parse():
    p=argparse.ArgumentParser()
    p.add_argument('--arms',nargs='+',choices=ARMS,default=['default','pruned'])
    p.add_argument('--keys',type=int,default=1)
    p.add_argument('--images',type=int,default=4)
    p.add_argument('--repeat',type=int,default=1)
    p.add_argument('--periodic-bias',action='store_true')
    p.add_argument('--upload-mbps',type=float,default=0)
    p.add_argument('--samples',type=Path,default=ROOT/'model/samples.json')
    p.add_argument('--paired-stress',action='store_true',help='Reuse an identical encrypted input and retain class disagreements.')
    return p.parse_args()

def main():
    a=parse()
    assert len(a.arms)==len(set(a.arms))
    samples=json.loads(a.samples.read_text())[:a.images]
    m=mp.get_context('spawn');r,w=m.Pipe(duplex=False); proc=m.Process(target=server,args=(w,a.periodic_bias))
    proc.start();w.close()
    try:
        with socket.create_connection(('127.0.0.1',r.recv()),timeout=120) as s:
            s.setsockopt(socket.IPPROTO_TCP,socket.TCP_NODELAY,1)
            def log(**kw):print(json.dumps(kw,separators=(',',':')),flush=True)
            for cohort in range(a.keys):
                begin=time.perf_counter_ns()
                ctx=getctx()
                ctxgen=time.perf_counter_ns()-begin
                begin=time.perf_counter_ns();ctx.generate_galois_keys()
                defaultgen=time.perf_counter_ns()-begin
                public=ctx.serialize(save_public_key=True,save_secret_key=False,save_galois_keys=False,save_relin_keys=False)
                pubhash=hashlib.sha256(public).hexdigest()
                pending={}
                for arm in a.arms:
                    tag=ARMS[arm]
                    if arm=='default':key_ns=defaultgen
                    else:
                        begin=time.perf_counter_ns();install_keys(ctx,arm);key_ns=time.perf_counter_ns()-begin
                    begin=time.perf_counter_ns()
                    payload=ctx.serialize(save_secret_key=False)
                    serialize_ns=time.perf_counter_ns()-begin
                    pending[arm]=(payload,serialize_ns,key_ns)
                for rep in range(a.repeat):
                    for j,v in enumerate(samples):
                        order=list(a.arms)
                        ordinal=(j+rep+cohort)%len(order)
                        order=order[ordinal:]+order[:ordinal]
                        if len(order)>2 and (j//len(order)+cohort)%2:order.reverse()
                        image=np.array(v['input']).reshape(28,28).tolist()
                        shared=None
                        for position,arm in enumerate(order):
                            tag=ARMS[arm]
                            cold_start=time.perf_counter_ns() if arm in pending else None
                            if arm in pending:
                                payload,serialize_ns,key_ns=pending.pop(arm)
                                sent=send(s,1,tag,payload,a.upload_mbps)
                                ack,_=check_reply(s,1,tag)
                                receive_ns=time.perf_counter_ns()-cold_start
                                ack=json.loads(ack)
                                assert ack['received']==sent and ack['keys']=={'default':24,'pruned':19,'split':18,'split17':17}[arm]
                                log(type='setup',cohort=cohort,arm=arm,context_ns=ctxgen,galois_ns=key_ns,serialize_ns=serialize_ns,
                                    transfer_install_ack_ns=receive_ns,client_upload_bytes=sent,galois_key_count=ack['keys'],
                                    public_key_fingerprint=pubhash,ts_version=ts.__version__,rate=a.upload_mbps,periodic=a.periodic_bias)
                            begin=time.perf_counter_ns()
                            if shared is None:
                                ct,nwindows=ts.im2col_encoding(ctx,image,7,7,3)
                                assert nwindows==64
                                req=ct.serialize()
                                if a.paired_stress:shared=req
                            else:req=shared
                            sent=send(s,2,tag,req,a.upload_mbps)
                            blob,reply_bytes=check_reply(s,2,tag)
                            n,eval_ns=struct.unpack('!QQ',blob[:16])
                            out=ts.ckks_vector_from(ctx,blob[16:]).decrypt()
                            finish=time.perf_counter_ns()
                            elapsed=finish-begin
                            assert n==sent and len(out)==10 and np.isfinite(out).all()
                            err=max(abs(x-y) for x,y in zip(out,v['logits']))
                            if not a.paired_stress and int(np.argmax(out))!=v['label']:raise ValueError(('class mismatch',v['index'],out))
                            log(type='query',cohort=cohort,arm=arm,index=v['index'],rep=rep,position=position,
                                upload=sent,download=reply_bytes,e2e_ns=elapsed,eval_serialize_ns=eval_ns,
                                cold_ready_to_prediction_ns=None if cold_start is None else finish-cold_start,
                                logits=out,max_error_vs_pytorch=err,label=v['label'],prediction=int(np.argmax(out)),input_sha256=hashlib.sha256(req).hexdigest(),public_key_fingerprint=pubhash)
                del ctx
                gc.collect()
            send(s,0,0,b'')
    finally:
        proc.join(5)
        if proc.is_alive():proc.kill();proc.join()
        if proc.exitcode:raise RuntimeError(f'server exit {proc.exitcode}')

if __name__=='__main__':main()
