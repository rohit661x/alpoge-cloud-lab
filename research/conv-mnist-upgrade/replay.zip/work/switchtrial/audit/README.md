# Replaying the four-arm ConvMNIST trial

Run the verifier with Python 3.10 or newer from the unpacked study directory.

```sh
python3 work/switchtrial/audit/verify.py --run work/switchtrial/run --out replay-audit --require-complete
```

The verifier uses the Python standard library. Keep `analysis-plan.md`, `oracle.py`, `statistics_trial.py` and `verify.py` together. It resolves the frozen design, harness and model fixture relative to their original locations. The arguments `--model`, `--harness` and `--freeze` accept alternative paths. Model inputs are `weights.json`, `samples.json` and both original MNIST test IDX gzip files. The replay reads logged native observations. It does not regenerate ciphertexts or repeat the timing trial.

Use the same command without `--require-complete` for a running collector. Each key enters the analysis only after all four arms have committed. The missing-key mask and planned denominator appear in `coverage.csv` and `summary.json`. Incomplete runs have a null `primary` field. The `observed` field describes only completed keys. A malformed committed attempt stops the replay with an error. Keep each replay in a fresh output directory to avoid confusion with earlier replays.

| File | Contents |
| --- | --- |
| `summary.json` | Deterministic primary, secondary, mixture, preparation and bootstrap summaries, source hashes and independent checks |
| `endpoints.csv` | One row per key, arm and request. Nanoseconds to the decrypted prefix, prefix increments, reply/decryption durations, cumulative bytes and preparation-added estimate |
| `paired-prefixes.csv` | Within-key adaptive minus fixed differences for three fixed policies. Hindsight columns independently select the fastest fixed arm at that key and prefix |
| `prefix-summary.csv` | Each comparator's observed mean, median, range, leave-one-key-out mean range, and counts of faster, tied and slower key blocks at each prefix |
| `workload-by-key.csv` | Exact integer time numerators and shared denominator for each key and prespecified length distribution |
| `crossovers.csv` | First strict adaptive lead, first prefix of a final uninterrupted lead, strict leadership reversals and ties within each observed path |
| `installations.csv` | Every setup and add, its framed byte counts, write-to-acknowledgment duration and corresponding server processing duration |
| `coverage.csv` | Each planned key and canonical attempt, with missing key blocks explicitly masked |

## Endpoint definitions

The directly measured timer begins just before the first application-frame write. It stops after client decryption of the ten output logits. Each arm uses a fresh evaluator process and connection. The client prepares public catalogs and the encrypted input panel before this clock. The prefix includes idle and logging intervals inside that arm's traced session. TCP connect, initial key generation, image encryption and the final close frame are outside the primary endpoint. The next request is issued by the harness directly after the previous request, without workload think time. The signed timing difference is adaptive minus fixed. Negative values mean the adaptive policy is faster.

The upload columns include the 10-byte application header on every setup, update and encrypted query. Server acknowledgments include the 10-byte header plus a nine-byte receipt. Query responses additionally include the encrypted result. `catalog_upload` sums setup and any singleton frames. `query_upload` sums encrypted query frames. Both directions exclude operating-system transport headers. `increment_ns` is the difference of signed-off consecutive prefix times within one arm. At request six it includes both live update acknowledgments in the adaptive arm. `query_request_to_reply_ns` starts after those acknowledgments.

`stage_adjusted_ns` adds separately measured preparation costs to the direct timer. All arms receive the common context creation and Galois-holder allocation charge. Each fixed arm then receives the cost of its direct-generation/install and serialization probe under that key. The adaptive arm receives base-17 generation/install and serialization. Starting at request six, it also receives the singleton generator initialization and generation and serialization of both singletons. Client merges and intermediate full snapshots are experimental fixture bookkeeping. Cumulative comparisons omit these costs and the common, pre-encrypted input preparation cost. A fixed-18 or fixed-19 direct-generation probe uses fresh evaluation-key randomness under the same secret as its timed nested catalog. The sum is a component-added estimate rather than an observed end-to-end generation run.

## Comparison and uncertainty

The primary calculation uses (4 × prefix 5 + prefix 24) / 5 for each arm on each key, averaged across twelve complete blocks. The comparator `best_pooled_fixed` is the single fixed policy with the smallest sample-wide mean under that workload. A key-wise hindsight minimum and the fastest fixed catalog at each prefix answer different questions. The short-only uniform 5–10 law and the individual endpoints are in `observed.workloads`. Two-point mixture boundaries in `observed.mixture` use exact rational arithmetic and encode strict inequality. Null denotes an empty strict-winning interval.

The paired 20,000-replicate bootstrap resamples whole key blocks. The three comparator-specific percentile bands are exploratory and pointwise. The best-fixed statistic reselects the globally fastest fixed arm in every resample. The per-comparator leave-one-out summaries omit a block at a time, and the best-fixed sensitivity also reselects the comparator after each omission. The sample measures twelve key/time blocks on a single host, rotating eight repeated images on a paced local socket. Times at 5 and 24 within a block are dependent. The block bootstrap cannot establish deployment-level uncertainty. No future lead is implied by a lead through prefix 24.

## What the verifier authenticates

The frozen arguments fix the survival trigger, link rate, block count, horizons and counterbalanced session order. Client and evaluator records must agree on the exact physical rotation steps after every install, the SHA-256 of each transmitted input, directional application bytes, ordinals, installed counts and timing boundaries. Public fingerprints must be unique among committed blocks and disjoint from nine fingerprints in the prior pilot, long-session and upgrade datasets. The pinned original MNIST IDX bytes and weights reproduce the clear reference with a scalar forward pass. The checker recomputes every stored logit residual and argmax. Output coordinates, repeated inputs and nested session prefixes do not count as new independent replications.

## Second native cohort

After running `harness/lazy_audit.py` on the separate four-key on-demand cohort, the following independent check uses its original socket and preparation journals. It verifies each production singleton was generated after the fifth decryption, reconciles the weighted pooled comparison, checks initial client-only directions, tests for overlapping keys and ciphertexts, and rebuilds all 3,840 decrypted-coordinate residuals from the scalar model.

```sh
python3 work/switchtrial/audit/crosscheck_lazy.py --primary work/switchtrial/run --lazy work/switchtrial/lazy-run --reported lazy-audit-summary.json --out independent-lazy-crosscheck.json
```

The on-demand clock begins immediately before fresh relinearization-key generation, after a shared keypair and input ciphertext panel exist and an evaluator connection is open. Every selected rotation-key generation, serialization, upload, acknowledgment and decryption occurs on that clock. These four measured blocks use different keys and a different initialization path from the twelve-key prepared-payload trial.
