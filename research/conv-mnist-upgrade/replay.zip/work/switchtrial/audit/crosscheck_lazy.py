"""Cross-check the on-demand scores and its 384 decryptions against the scalar model."""
import argparse
import json
from math import isclose, isfinite
from pathlib import Path

from oracle import argmax, distance, read_oracle, require
from statistics_trial import ARMS, FIXED, LAWS, best_names
from verify import CATALOGS, lines, load, PRIOR, valid_digest


def check(primary_dir, lazy_dir, reported, model):
    scalar=read_oracle(model)
    previous=set(PRIOR)
    inputs=set()
    for k in range(12):
        d=primary_dir/f"key-{k:03d}"
        marker=load(d/"complete.json")
        meta=load(d/marker["attempt"]/"key.json")
        previous.add(meta["fingerprint"])
        inputs.update(r["payload_sha256"] for r in meta["panel"])
    keys=[]
    scores=[]
    mistakes=0
    errors=[]
    base=load(reported)
    for k in range(4):
        d=lazy_dir/f"key-{k:03d}"
        marker=load(d/"complete.json")
        path=d/marker["attempt"]
        meta=load(path/"key.json")
        fp=meta["fingerprint"]
        require(valid_digest(fp) and fp not in previous and fp not in keys,"Overlapping fresh-key cohorts")
        keys.append(fp)
        current={r["payload_sha256"] for r in meta["panel"]}
        require(len(current)==24 and current.isdisjoint(inputs),"Overlapping ciphertext panels")
        inputs.update(current)
        observed={}
        for arm in ARMS:
            prep=lines(path/f"{arm}-preparation.jsonl")
            socket=lines(path/f"{arm}-socket-client.jsonl")
            first=prep[0]["start_ns"]
            initial=prep[0]
            size=17 if arm=="adaptive" else int(arm[-2:])
            require(initial["client_has_galois_holder"] is False and
                    size==initial["initial_galois_key_count"]==len(initial["requested_initial_steps"]) and
                    set(initial["requested_initial_steps"])==set(initial["initial_present_steps"])==CATALOGS[size],
                    "Selected-only initial client generation from an empty Galois holder")
            timed={(r["kind"],r["query"],r["keys"]):r for r in socket}
            if arm == "adaptive":
                five=timed[2,5,17]
                six=timed[2,6,19]
                require([(e["kind"],e["query"],e["keys"]) for e in prep] == [(1,0,17),(3,6,18),(3,6,19)],
                        "Adaptive key generation sequence")
                require(five["end_ns"] <= prep[1]["start_ns"] <= prep[1]["serialized_ns"] <=
                        timed[3,6,18]["start_ns"] < timed[3,6,18]["reply_ns"] <= prep[2]["start_ns"] <=
                        prep[2]["serialized_ns"] <= timed[3,6,19]["start_ns"] <
                        timed[3,6,19]["reply_ns"] <= six["start_ns"],
                        "Native plus-512 and plus-2048 generation must occur after five results, in order")
            else:
                require(len(prep) == 1 and prep[0]["kind"] == 1 and prep[0]["keys"] == int(arm[-2:]),
                        "Fixed arm should generate only its initial catalog")
            stop={}
            for row in socket:
                if row["kind"]!=2:
                    continue
                q=row["query"]
                require(row["payload_sha256"]==meta["panel"][q-1]["payload_sha256"],"Fresh input pairing")
                ref=scalar[row["index"]]
                logits=row["logits"]
                require(len(logits)==10 and all(map(isfinite,logits)),"Finite decrypted output")
                prediction=argmax(logits)
                mistakes+=int(prediction!=ref[0])
                residual=distance(logits,ref[1])
                require(abs(residual-row["error"])<1e-11 and prediction==row["prediction"], "Scalar residual and argmax")
                errors.append(residual)
                stop[q]=row["end_ns"]-first
            require(sorted(stop)==list(range(1,25)),"Complete raw prefixes")
            observed[arm]=sum(w*stop[q] for q,w in LAWS["primary_80_20"].items())
            require(isclose(observed[arm]/5e9,base["blocks"][k]["by_arm"][arm]["mixture_s"],abs_tol=1e-13),
                    "Raw generation start and raw decrypt times disagree with on-demand score")
        scores.append(observed)
    totals={a:sum(s[a] for s in scores) for a in ARMS}
    best=best_names(totals)
    differences={a:(totals["adaptive"]-totals[a])/20 for a in FIXED}
    require(base["best_fixed_mixture"] in best and
            isclose(base["active_minus_best_fixed_mixture_s"],differences[best[0]]/1e9,abs_tol=1e-13),
            "On-demand pooled fixed comparison")
    require(mistakes==base["class_errors"] and abs(max(errors)-base["maximum_absolute_logit_error"])<1e-11,
            "On-demand native correctness summary")
    return dict(fresh_keys_disjoint_from_all_21_prior=len(keys), paired_distinct_inputs=96,
                native_predictions=len(errors), checked_decrypted_coordinates=10*len(errors), class_errors=mistakes,
                max_abs_error_vs_scalar=max(errors), pooled_best_fixed=best, adaptive_minus_each_fixed_ns=differences)


if __name__=="__main__":
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument("--primary",type=Path,required=True)
    p.add_argument("--lazy",type=Path,required=True)
    p.add_argument("--reported",type=Path,required=True)
    p.add_argument("--model",type=Path,default=Path(__file__).resolve().parents[2]/"second-trained/model")
    p.add_argument("--out",type=Path,required=True)
    a=p.parse_args()
    a.out.write_text(json.dumps(check(a.primary,a.lazy,a.reported,a.model),sort_keys=True,indent=2)+"\n")
