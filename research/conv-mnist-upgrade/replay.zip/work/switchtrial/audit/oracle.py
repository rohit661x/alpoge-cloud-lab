"""Rebuild the eight ConvMNIST predictions from the original IDX fixtures and weights."""
import gzip
from hashlib import sha256
import json
from math import fsum
import struct

EXPECTED = {
    "weights.json": "ce0a279f87c5433e72c3be3ab39f2c57dc6a11914dc4850a2883824874cf89a2",
    "samples.json": "d7053f8724714357287092240ced8f16c2c1121e9e8e5eec61b754f32070c621",
    "t10k-images-idx3-ubyte.gz": "8d422c7b0a1c1c79245a5bcf07fe86e33eeafee792b84584aec276f5a2dbc4e6",
    "t10k-labels-idx1-ubyte.gz": "f7ae60f92e00ec6debd23a6088c31dbd2371eca3ffa0defaefb259924204aec6",
}


def require(condition, description):
    if not condition:
        raise ValueError(description)


def hashfile(file):
    return sha256(file.read_bytes()).hexdigest()


def argmax(coords):
    return max(range(len(coords)), key=coords.__getitem__)


def distance(left, right):
    return max(abs(a-b) for a,b in zip(left, right, strict=True))


def read_oracle(model):
    for name, digest in EXPECTED.items():
        require(hashfile(model / name) == digest, f"Input hash mismatch for {name}")
    w = json.loads((model / "weights.json").read_text())
    samples = json.loads((model / "samples.json").read_text())
    idx = gzip.decompress((model / "t10k-images-idx3-ubyte.gz").read_bytes())
    labels = gzip.decompress((model / "t10k-labels-idx1-ubyte.gz").read_bytes())
    require(struct.unpack_from(">4I", idx) == (2051, 10000, 28, 28) and
            struct.unpack_from(">2I", labels) == (2049,10000), "Unexpected IDX fixtures")
    require(len(samples) == 8, "Expected eight input images")

    def dense(layer, values):
        return [bias + fsum(x * weight for x, weight in zip(values, row, strict=True))
                for bias, row in zip(w[layer + "_bias"], w[layer], strict=True)]

    oracle = []
    for i, sample in enumerate(samples):
        pixels = idx[16+784*i : 16+784*(i+1)]
        values = [(p / 255 - .1307) / .3081 for p in pixels]
        label = labels[8+i]
        require((sample["index"], sample["label"], sample["input"]) == (i, label, values),
                "Committed image/label differs from normalized IDX")
        activations = []
        for (kernel,), bias in zip(w["conv"], w["conv_bias"], strict=True):
            for y in range(0,22,3):
                for x in range(0,22,3):
                    dot = fsum(values[(y+dy)*28+x+dx]*weight for dy, row in enumerate(kernel)
                               for dx, weight in enumerate(row))
                    activations.append((dot+bias)**2)
        logits = dense("fc2", [x*x for x in dense("fc1", activations)])
        require(len(logits) == 10 and distance(logits, sample["logits"]) < 1e-11 and argmax(logits) == label,
                "Fixtures disagree with independent scalar classification")
        oracle.append((label, logits, sample["logits"]))
    return oracle
