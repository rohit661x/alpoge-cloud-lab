"""Paired endpoint analysis, using integer raw durations and whole-key resampling."""
import itertools
import math
import random
from fractions import Fraction as F
from statistics import mean, median

ARMS = ("adaptive", "fixed17", "fixed18", "fixed19")
FIXED = ARMS[1:]
LAWS = {
    "primary_80_20": {5: 4, 24: 1},
    "short_5": {5: 1},
    "long_24": {24: 1},
    "short_uniform_5_to_10": dict.fromkeys(range(5, 11), 1),
}


def describe(values):
    n = len(values)
    omitted = [(sum(values) - x) / (n - 1) for x in values] if n > 1 else []
    return dict(n=n, mean=mean(values), median=median(values), min=min(values), max=max(values),
                range=max(values) - min(values) if n > 1 else None,
                leave_one_key_out_mean_range=[min(omitted), max(omitted)] if omitted else None,
                faster=sum(v < 0 for v in values), tied=values.count(0), slower=sum(v > 0 for v in values))


def law_costs(endpoints, law, field):
    return {key: {arm: sum(w * endpoints[key][arm][q][field] for q, w in law.items())
                        for arm in ARMS} for key in endpoints}


def best_names(totals):
    fastest = min(totals[a] for a in FIXED)
    return [a for a in FIXED if totals[a] == fastest]


def contrast(scores, denominator):
    n = len(scores)
    totals = {a: sum(row[a] for row in scores.values()) for a in ARMS}
    winners = best_names(totals)
    drop_results = []
    if n > 1:
        for key, row in scores.items():
            drop = {a: totals[a] - row[a] for a in ARMS}
            best = best_names(drop)
            drop_results.append(dict(omitted_key=key, best_fixed=best,
                                     adaptive_minus_best_pooled_fixed=(drop["adaptive"] - drop[best[0]]) / (denominator * (n - 1))))
    return dict(keys=n, mean_by_arm={a: totals[a] / (n * denominator) for a in ARMS},
                adaptive_minus_fixed={a: describe([(r["adaptive"] - r[a]) / denominator for r in scores.values()]) for a in FIXED},
                best_pooled_fixed=winners, adaptive_minus_best_pooled_fixed=(totals["adaptive"]-totals[winners[0]]) / (n * denominator),
                strict_win_vs_all=totals["adaptive"] < totals[winners[0]],
                leave_one_key_out_reselected=drop_results)


def percentile(sample, p):
    """Linear interpolation between adjacent order statistics, inclusive endpoints."""
    index = p * (len(sample) - 1)
    lo = math.floor(index)
    return sample[lo] + (sample[math.ceil(index)] - sample[lo]) * (index - lo)


def paired_bootstrap(scores, denominator):
    rows = [[r["adaptive"] - r[a] for a in FIXED] for r in scores.values()]
    n = len(rows)
    rng = random.Random(240605)
    draws = {label: [] for label in (*FIXED, "best_pooled_fixed_reselected")}
    for _ in range(20_000):
        sampled = [rows[rng.randrange(n)] for _ in rows]
        results = [sum(column) / (denominator*n) for column in zip(*sampled, strict=True)]
        for arm, value in zip(FIXED, results, strict=True):
            draws[arm].append(value)
        # A-minus-min(F) equals max(A-F).
        draws["best_pooled_fixed_reselected"].append(max(results))
    return {a: [percentile(sorted(vec), .025), percentile(sorted(vec), .975)] for a, vec in draws.items()}


def mixture(endpoints):
    def d(q, a):
        return sum(by_arm["adaptive"][q]["elapsed_ns"] - by_arm[a][q]["elapsed_ns"] for by_arm in endpoints.values())
    differences = {a: [d(5, a), d(24, a)] for a in FIXED}

    def region(pairs):
        # A pair is strictly negative below/above its root according to its slope.
        low, high = F(0), F(1)
        low_closed, high_closed = True, True
        for s, l in pairs:
            slope = l - s
            if slope == 0:
                if s >= 0:
                    return None
                continue
            root = F(-s, slope)
            if slope > 0 and root <= high:
                high, high_closed = root, False
            if slope < 0 and root >= low:
                low, low_closed = root, False
        if low > high or (low == high and not (low_closed and high_closed)):
            return None
        return dict(lower_exact=str(low), upper_exact=str(high), lower=float(low), upper=float(high),
                    lower_inclusive=low_closed, upper_inclusive=high_closed)

    out = {}
    for arm, (s, l) in differences.items():
        root = F(-s, l-s) if l != s else None
        out[arm] = dict(short_mean_delta_ns=s/len(endpoints), long_mean_delta_ns=l/len(endpoints),
                        tie_probability_exact=str(root) if root is not None and 0 <= root <= 1 else None,
                        tied_everywhere=(s == l == 0), strict_win_region=region([(s, l)]))
    return dict(per_comparator=out, strict_win_vs_all=region(differences.values()))


def crossovers(deltas):
    wins = [i for i, delta in enumerate(deltas, 1) if delta < 0]
    last_run = None
    if deltas[-1] < 0:
        last_run = max((i for i, delta in enumerate(deltas, 1) if delta >= 0), default=0) + 1
    signs = [(d > 0) - (d < 0) for d in deltas if d]
    return dict(first_strict_lead=wins[0] if wins else None, final_uninterrupted_lead=last_run,
                strict_leader_reversals=sum(a != b for a,b in itertools.pairwise(signs)), ties=deltas.count(0),
                endpoint_adaptive_minus_fixed_ns=deltas[-1])


def summarize(endpoints, complete):
    if not endpoints:
        return dict(workloads={}, observed_primary_bootstrap_ns=None, mixture=None), [], [], []
    weighted, by_key, by_prefix, crossing_rows = {}, [], [], []
    for name, law in LAWS.items():
        denominator = sum(law.values())
        fields = ("elapsed_ns", "upload", "download", "catalog_upload", "query_upload", "stage_adjusted_ns")
        for field in fields:
            scores = law_costs(endpoints, law, field)
            result = contrast(scores, denominator)
            if field not in ("elapsed_ns", "stage_adjusted_ns"):
                result.pop("leave_one_key_out_reselected")
            weighted.setdefault(name, {})[field] = result
            if field == "elapsed_ns":
                for k, row in scores.items():
                    by_key.append(dict(key=k, workload=name, denominator=denominator,
                                       **{a+"_ns_numerator": row[a] for a in ARMS},
                                       **{"adaptive_minus_"+a+"_ns_numerator":row["adaptive"]-row[a] for a in FIXED}))
    for q in range(1, 25):
        scores = law_costs(endpoints, {q:1}, "elapsed_ns")
        out = contrast(scores, 1)
        for a in FIXED:
            by_prefix.append(dict(query=q, comparator=a, **out["adaptive_minus_fixed"][a],
                                  mean_adaptive_ns=out["mean_by_arm"]["adaptive"], mean_fixed_ns=out["mean_by_arm"][a],
                                  globally_fastest_fixed=a in out["best_pooled_fixed"]))
    for key, arms in endpoints.items():
        for a in FIXED:
            deltas=[arms["adaptive"][q]["elapsed_ns"] - arms[a][q]["elapsed_ns"] for q in range(1,25)]
            crossing_rows.append(dict(key=key, comparator=a, **crossovers(deltas)))
    pooled_crossings = {}
    primary_decomposition = {}
    for a in FIXED:
        totals = [sum(arms["adaptive"][q]["elapsed_ns"]-arms[a][q]["elapsed_ns"] for arms in endpoints.values())
                  for q in range(1,25)]
        row = crossovers(totals)
        row["endpoint_mean_adaptive_minus_fixed_ns"] = row.pop("endpoint_adaptive_minus_fixed_ns") / len(endpoints)
        pooled_crossings[a] = row
        early = totals[4]
        later = totals[23] - early
        primary_decomposition[a] = dict(
            mean_first_five_delta_ns=early / len(endpoints),
            mean_incremental_delta_queries_6_to_24_ns=later / len(endpoints),
            weighted_incremental_delta_ns=later / (5*len(endpoints)),
            mean_primary_delta_ns=(5*early+later) / (5*len(endpoints)))
    boot = paired_bootstrap(law_costs(endpoints, LAWS["primary_80_20"], "elapsed_ns"), 5) if complete else None
    return dict(workloads=weighted, observed_primary_bootstrap_ns=boot,
                bootstrap_replicates=20000 if complete else None, pooled_mean_crossovers=pooled_crossings,
                primary_difference_decomposition=primary_decomposition,
                mixture=mixture(endpoints)), by_key, by_prefix, crossing_rows
