"""Independent, offline replay of the prespecified 12-key live-switch experiment."""
import argparse
from collections import Counter, defaultdict
import csv
from datetime import datetime
from itertools import combinations
import json
from math import isfinite
from pathlib import Path
import re

from oracle import EXPECTED, argmax, distance, hashfile, read_oracle, require
from statistics_trial import ARMS, FIXED, describe, summarize

HERE = Path(__file__).resolve().parent
GROUP = HERE.parent
WILLIAMS = (("adaptive","fixed17","fixed19","fixed18"), ("fixed17","fixed18","adaptive","fixed19"),
            ("fixed18","fixed19","fixed17","adaptive"), ("fixed19","adaptive","fixed18","fixed17"))
PRIOR = {
    "034b347e151b5295e4a83eec2ef5abf990e4127fc27ec13b4b6504362ae772f0",
    "6ac39034d4d643eddbcc78236431dfdfbebd403c6ce7d5dbf32a6c92d54eae19",
    "6d9de8c7bc82b63f70b78218bdf92fe6ddb11d3b54c500f6979d01415554ca2f",
    "0b088c8871e897e1190806c835bf7774a77c935b3a63751df70cc2cb1f21ba0e",
    "30abf5140ab407bfffff0940dcef845509e4c206ed83b79cf36d3f94c1b87b17",
    "753ab26d782d62ff5efc9c906545bdd5ac8d652d8854b335f981baeae6c91a82",
    "05f826770303f4e7f9b6462946b1141fe97647bd94806088e5bbce04190f2313",
    "93a8a34d468af627625e2925a2e9c0b5b5c3c5e7410f5721e4dd79f554cb5a7c",
    "c49fa752775eca4332023aa05edd6c89657c4cebd7028585979c240d84c01da5",
}
CATALOGS = {size: {2**e for e in range(12)} | {-2**e for e in range(7)}
            for size in (17,18,19)}
CATALOGS[17] -= {512,2048}
CATALOGS[18] -= {2048}


def load(path):
    return json.loads(path.read_text())


def lines(path):
    return [json.loads(line) for line in path.read_text().splitlines()]


def valid_digest(text):
    return isinstance(text, str) and bool(re.fullmatch("[0-9a-f]{64}", text))


def events(arm):
    n = 17 if arm == "adaptive" else int(arm[-2:])
    yield 1, n, 0
    for q in range(1, 25):
        if arm == "adaptive" and q == 6:
            yield 3, 18, 6
            yield 3, 19, 6
            n = 19
        yield 2, n, q


def validate_plan(run, freeze, harness):
    plan = load(run / "plan.json")
    host = load(run / "host.json")
    design = load(freeze)
    require(hashfile(freeze) == "d53bcde7913459b20713655cee76a39c037279ff3ba9d142b7de9069e2b1762d" and
            hashfile(HERE/"analysis-plan.md") == "1166d27ce328a1a93946b81ad73115bd006dcbc61dd6e942e1162fbc139a836b",
            "Design or independent analysis plan differs from its prospective version")
    require(design["protocol_version"] == 2 and design["policy"]["on_arrival_of_request"] == 6 and
            design["policy"]["install_in_order"] == [512,2048] and design["upload_mbps_decimal"] == 500 and
            design["cohort"]["fresh_independent_client_keys"] == 12 and
            design["cohort"]["maximum_requests_per_arm"] == 24 and
            [design["primary_workload"][f"probability_n_{q}"] for q in (5,24)] == ["4/5","1/5"],
            "Design freeze does not describe this audit")
    sess = plan["sessions"]
    require(plan["image_count"] == 8 and [s["key"] for s in sess] == list(range(12)), "Frozen key/image count")
    for i, s in enumerate(sess):
        require((s["length"],s["rate_mbps"],s["switch18"],s["switch19"]) == (24,500,6,6) and
                tuple(s["arm_order"]) == WILLIAMS[i%4] and
                s["image_offset"] == (sess[0]["image_offset"] + i) % 8, "Runtime plan differs from design")
    env = host["environment"]
    digests = env["sha256"]
    require(digests["plan"] == hashfile(run / "plan.json") and
            digests["harness"] == hashfile(harness) and digests["model"] == EXPECTED["weights.json"] and
            digests["fixtures"] == EXPECTED["samples.json"], "Native run source or fixture fingerprint mismatch")
    require(all(valid_digest(v) for v in digests.values()) and env["evaluator_threads"] == env["client_threads"] == 1,
            "Host environment evidence")
    return sess, host


def read_arm(attempt, arm, s, meta, ref, charges, evidence, rawlogits):
    path = lambda suffix: attempt / f"{arm}-{suffix}"
    client, server, summary = lines(path("client.jsonl")), lines(path("server.jsonl")), load(path("summary.json"))
    key, first, pid = s["key"], client[0]["start_ns"], summary["pid"]
    require(first > 0 and pid > 0 and summary["fingerprint"] == meta["fingerprint"] and
            (summary["key"],summary["arm"],summary["length"],summary["rate_mbps"]) == (key,arm,24,500),
            "Arm summary identity or first timestamp")
    totals = Counter()
    by_q = {}
    prev = first
    for seq, ((kind, count, q), c, r) in enumerate(zip(events(arm), client, server, strict=True)):
        descriptor = (key, arm, seq, q, kind, count, pid)
        for row in (c, r):
            require(tuple(row[k] for k in ("key","arm","seq","query","kind","keys","pid")) == descriptor,
                    f"Event identity/action does not match frozen rule: {descriptor}")
        start, reply, end = (c[k] for k in ("start_ns","reply_ns","end_ns"))
        require(prev <= start < reply <= end and (kind == 2 or end == reply) and
                r["process_ns"] > 0 and r["process_ns"] <= reply-start, "Nonmonotone clock or processing interval")
        prev = end
        require(c["upload"] == r["received"] > 10 and c["download"] == r["sent"] >= 19 and
                (reply - start) * 500 >= c["upload"] * 8000,
                "Application frame accounting or 500-Mbit/s pacing violation")
        if kind == 2:
            panel = meta["panel"][q-1]
            sha = panel["payload_sha256"]
            label, clear, _ = ref[panel["index"]]
            logits = c["logits"]
            require(c["download"] > 19 and c["index"] == panel["index"] and
                    len(logits) == 10 and all(map(isfinite, logits)), "Malformed prediction event")
            encrypted = argmax(logits)
            err = distance(logits,clear)
            require(c["label"] == label and encrypted == c["prediction"] and abs(err-c["error"]) < 1e-11,
                    "Recorded prediction, label or logit residual is inconsistent")
            evidence["errors"].append(err)
            evidence["margins"].append(sorted(logits)[-1] - sorted(logits)[-2])
            evidence["mismatches"] += int(encrypted != label or encrypted != argmax(clear))
            rawlogits[q].append((arm, logits, c["upload"]))
            totals["query_upload"] += c["upload"]
        else:
            family = "context" if kind == 1 else "delta"
            sha = meta[family+"s"][str(count)]
            require(c["download"] == 19 and c["upload"] == 10 + meta[family+"_payload_bytes"][str(count)] and
                    len(r["present_steps"]) == count and set(r["present_steps"]) == CATALOGS[count],
                    "Setup/update acknowledgment, exact frame bytes or physical Galois-key inventory")
            totals["catalog_upload"] += c["upload"]
            evidence["installs"].append(dict(key=key,arm=arm,kind=kind,keys=count,query=q,
                                             upload=c["upload"],download=c["download"],
                                             acknowledged_ns=reply-start,server_process_ns=r["process_ns"]))
        require(c["payload_sha256"] == r["payload_sha256"] == sha, "Mismatched paired upload payload hashes")
        totals["upload"] += c["upload"]
        totals["download"] += c["download"]
        evidence["frames"][kind] += 1
        elapsed = end - first
        require((elapsed,totals["upload"],totals["download"]) ==
                (c["cumulative_ns"],c["cumulative_upload"],c["cumulative_download"]),
                "Logged cumulative framed bytes or clock mismatch")
        if kind == 2:
            prior = by_q[q-1]["elapsed_ns"] if q > 1 else 0
            by_q[q] = dict(key=key,arm=arm,query=q,keys=count,elapsed_ns=elapsed,
                           increment_ns=elapsed-prior,query_request_to_reply_ns=reply-start,
                           decryption_ns=end-reply, **dict(totals), stage_adjusted_ns=elapsed+charges[arm][q])
    require((summary["start_ns"],summary["end_ns"],summary["elapsed_ns"],summary["upload"],summary["download"]) ==
            (first,prev,by_q[24]["elapsed_ns"],totals["upload"],totals["download"]), "Final summary reconciliation")
    return by_q, (first,prev), pid


def preparation(meta):
    p = meta["preparation_ns"]
    common = p["common_context"] + p["common_galois_holder"]
    base = p["base17_generate_install"] + p["snapshot"]["17"]
    additions = sum(p["delta"][n][field] for n in ("18","19") for field in ("generate","serialize"))
    add_charge = p["delta_key_generator_init"] + additions
    require(p["bulk_fixed"]["17"] == {"generate_install":p["base17_generate_install"],"serialize":p["snapshot"]["17"]},
            "17-key direct and staged preparations must be the same event")
    def positive(x):
        if isinstance(x, dict):
            return all(positive(v) for v in x.values())
        if isinstance(x, list):
            return all(positive(v) for v in x)
        return type(x) is int and x > 0
    require(positive(p) and len(p["encrypt_serialize"]) == 24, "Unexpected client preparation duration")
    charges = {"adaptive": {q: common + base + (add_charge if q >= 6 else 0) for q in range(1,25)}}
    for a in FIXED:
        bulk = p["bulk_fixed"][a[-2:]]
        charge = common + bulk["generate_install"] + bulk["serialize"]
        charges[a] = dict.fromkeys(range(1,25), charge)
    return charges


def audit(run, model, freeze, harness):
    sessions, host = validate_plan(run,freeze,harness)
    ref = read_oracle(model)
    seen_keys, query_digests, catalog_digests = set(), set(), set()
    endpoints, coverage, input_hashes = {}, [], {}
    evidence = dict(frames=Counter(), errors=[], margins=[], mismatches=0, installs=[])
    max_paired_gap, max_same_catalog_gap = 0., 0.
    for s in sessions:
        k = s["key"]
        folder = run / f"key-{k:03d}"
        marker = folder / "complete.json"
        if not marker.exists():
            coverage.append(dict(key=k, status="masked_no_completion_marker",attempt=None))
            continue
        record = load(marker)
        require(record["key"] == k and re.fullmatch(r"attempt-[0-9]{3,}",record["attempt"]),
                "Invalid canonical attempt reference")
        attempt = folder / record["attempt"]
        meta = load(attempt / "key.json")
        fingerprint = meta["fingerprint"]
        require(meta["key"] == k and fingerprint == record["fingerprint"] and valid_digest(fingerprint) and
                fingerprint not in seen_keys | PRIOR, "Fresh-key fingerprint mismatch or duplication")
        seen_keys.add(fingerprint)
        require(set(meta["contexts"]) == {"17","18","19"} and set(meta["deltas"]) == {"18","19"},
                "Catalog snapshots or updates missing")
        current_catalogs = set(meta["contexts"].values()) | set(meta["deltas"].values())
        require(len(current_catalogs) == 5 and current_catalogs.isdisjoint(catalog_digests) and
                all(map(valid_digest,current_catalogs)), "Distinct context and delta hashes")
        catalog_digests.update(current_catalogs)
        panel = meta["panel"]
        require(len(panel) == 24, "Missing ciphertext in panel")
        for q, row in enumerate(panel, 1):
            idx = (s["image_offset"] + q - 1) % 8
            digest = row["payload_sha256"]
            require(valid_digest(digest) and digest not in query_digests, "Input ciphertext reused across fresh ordinals")
            query_digests.add(digest)
            require((row["query"], row["index"], row["label"], row["reference_logits"]) == (q,idx,ref[idx][0],ref[idx][2]),
                    "Cyclic paired image selection or reference logits changed")
        charges = preparation(meta)
        rawlogits = defaultdict(list)
        last_end = 0
        pids = set()
        for arm in s["arm_order"]:
            endpoints.setdefault(k,{})[arm], span, pid = read_arm(attempt,arm,s,meta,ref,charges,evidence,rawlogits)
            require(last_end < span[0] and pid not in pids, "Realized arm order or process isolation")
            last_end = span[1]
            pids.add(pid)
        for q, items in rawlogits.items():
            require(len(items)==4 and len({item[2] for item in items})==1, "Same ciphertext frame size on all four arms")
            for (a,left,_), (b,right,_) in combinations(items,2):
                gap = distance(left,right)
                max_paired_gap=max(max_paired_gap,gap)
                if endpoints[k][a][q]["keys"] == endpoints[k][b][q]["keys"]:
                    max_same_catalog_gap=max(max_same_catalog_gap,gap)
        coverage.append(dict(key=k, status="verified",attempt=attempt.name,fingerprint=fingerprint))
        for file in sorted([marker, attempt/"key.json", *attempt.glob("*-client.jsonl"), *attempt.glob("*-server.jsonl"),
                            *attempt.glob("*-summary.json")]):
            input_hashes[str(file.relative_to(run))] = hashfile(file)
    global_marker = run/"complete.json"
    if global_marker.exists():
        marker = load(global_marker)
        require(len(endpoints)==12 and marker["keys"] == 12 and marker["encrypted_evaluations"] == 1152 and
                marker["plan_sha256"]==hashfile(run/"plan.json"), "Premature or invalid final completion marker")
    complete = len(endpoints) == 12 and global_marker.exists()
    if complete:
        require((run/"progress.jsonl").is_file(), "Missing global event log")
    if (run/"progress.jsonl").exists():
        # On partial inspections a collector may still be writing the progress stream.
        # Full runs must have all 12 commit records and the prescribed within-block order.
        if complete:
            progress = lines(run/"progress.jsonl")
            for s in sessions:
                item = coverage[s["key"]]
                scoped=[r for r in progress if r.get("key")==s["key"] and r.get("attempt")==item["attempt"]]
                require([r["arm"] for r in scoped if r["event"]=="arm_start"] == s["arm_order"] and
                        [r["arm"] for r in scoped if r["event"]=="arm_complete"] == s["arm_order"] and
                        sum(r["event"]=="key_complete" for r in scoped)==1, "Progress/commit log coherence")
            require(datetime.fromisoformat(host["frozen_utc"]) <= min(datetime.fromisoformat(r["utc"])
                    for r in progress if r["event"]=="key_start"), "Host arguments frozen after first key started")
            input_hashes["progress.jsonl"]=hashfile(run/"progress.jsonl")
    for p in ("plan.json","host.json","complete.json"):
        if (run/p).is_file():
            input_hashes[p] = hashfile(run/p)
    stats,per_key,per_prefix,crossings = summarize(endpoints,complete)
    verified = len(endpoints)
    if verified:
        q6 = {a: [arms[a][6]["increment_ns"] for arms in endpoints.values()] for a in ARMS}
        stats["sixth_request"] = dict(
            mean_increment_ns={a: sum(values)/verified for a,values in q6.items()},
            adaptive_minus_fixed_increment_ns={a: describe([x-y for x,y in zip(q6["adaptive"],q6[a],strict=True)])
                                               for a in FIXED})
    validations = dict(verified_key_blocks=verified, planned_key_blocks=12, verified_sessions=4*verified,
                       verification_scope="Canonical completed key blocks", model_sha256=EXPECTED,
                       native_host=host, freeze_sha256=hashfile(freeze), audit_plan_sha256=hashfile(HERE/"analysis-plan.md"),
                       input_sha256=input_hashes, public_key_fingerprints=sorted(seen_keys),
                       historical_fingerprints_checked=sorted(PRIOR), distinct_input_ciphertexts=len(query_digests),
                       distinct_images=(8 if endpoints else 0), exact_public_payload_hashes=len(catalog_digests),
                       setup_transactions=evidence["frames"][1], update_transactions=evidence["frames"][3],
                       query_transactions=evidence["frames"][2], directional_frames=2*sum(evidence["frames"].values()),
                       checked_logits=10*len(evidence["errors"]), class_disagreements=evidence["mismatches"],
                       predictions_matching_clear_and_label=len(evidence["errors"])-evidence["mismatches"],
                       max_abs_error_against_scalar=max(evidence["errors"],default=None),
                       smallest_decrypted_class_margin=min(evidence["margins"],default=None),
                       max_abs_difference_between_paired_arms=max_paired_gap if verified else None,
                       max_abs_difference_between_matched_catalogs=max_same_catalog_gap if verified else None)
    summary = dict(status="complete" if complete else "partial", planned_keys=12, committed_keys=verified,
                   pending_keys=[s["key"] for s in coverage if s["status"] != "verified"],
                   coverage=coverage, primary=stats["workloads"].get("primary_80_20") if complete else None,
                   observed=stats, validation=validations)
    prefix_rows = [v for key,arms in endpoints.items() for a in ARMS for v in arms[a].values()]
    prefix_pairs=[]
    for key,arms in endpoints.items():
        for q in range(1,25):
            adaptive=arms["adaptive"][q]
            best_time=min(arms[a][q]["elapsed_ns"] for a in FIXED)
            prefix_pairs.append(dict(key=key,query=q,
                                     **{"adaptive_minus_"+a+"_ns":adaptive["elapsed_ns"]-arms[a][q]["elapsed_ns"] for a in FIXED},
                                     **{"increment_adaptive_minus_"+a+"_ns":adaptive["increment_ns"]-arms[a][q]["increment_ns"] for a in FIXED},
                                     **{"upload_adaptive_minus_"+a:adaptive["upload"]-arms[a][q]["upload"] for a in FIXED},
                                     **{"download_adaptive_minus_"+a:adaptive["download"]-arms[a][q]["download"] for a in FIXED},
                                     hindsight_best_fixed="|".join(a for a in FIXED if arms[a][q]["elapsed_ns"] == best_time),
                                     hindsight_delta_ns=adaptive["elapsed_ns"]-best_time))
    return summary, {"coverage":coverage,"endpoints":prefix_rows,"paired-prefixes":prefix_pairs,"workload-by-key":per_key,
                     "prefix-summary":per_prefix,"crossovers":crossings,"installations":evidence["installs"]}


def write_csv(path, rows):
    columns = list(dict.fromkeys(c for row in rows for c in row))
    with path.open("w",newline="") as stream:
        writer=csv.DictWriter(stream,fieldnames=columns,lineterminator="\n")
        writer.writeheader()
        writer.writerows(rows)


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument("--run",type=Path,required=True)
    p.add_argument("--out",type=Path,required=True)
    p.add_argument("--model",type=Path,default=GROUP.parent/"second-trained/model")
    p.add_argument("--freeze",type=Path,default=GROUP/"design/freeze.json")
    p.add_argument("--harness",type=Path,default=GROUP/"harness/trial.py")
    p.add_argument("--require-complete",action="store_true")
    a=p.parse_args()
    summary, tables=audit(a.run,a.model,a.freeze,a.harness)
    if a.require_complete:
        require(summary["status"]=="complete","Frozen primary result is still masked")
    a.out.mkdir(parents=True,exist_ok=True)
    (a.out/"summary.json").write_text(json.dumps(summary,sort_keys=True,indent=2,allow_nan=False)+"\n")
    for name,table in tables.items():
        write_csv(a.out/(name+".csv"),table)
    print(f'{summary["status"]}: {summary["committed_keys"]}/12 key blocks; {summary["validation"]["query_transactions"]} predictions.')


if __name__=="__main__":
    main()
