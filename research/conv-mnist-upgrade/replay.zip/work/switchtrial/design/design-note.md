# A survival-triggered catalog upgrade at 500 Mbit/s

Enroll with 17 ordinary rotation keys. If a sixth request arrives, send +512 and +2048 consecutively. Wait for each acknowledgement, then serve request six and all subsequent requests with 19 keys. A five-request session sends neither additional key. This rule uses only the count that has arrived. Freeze v2 specifies the primary clock as first setup-frame write through prefix decryption with public keys prepared. Its predecessor assumed a different preparation boundary. Both are retained to document the clarification before inspection of fresh results.

## Design and scope

The synthetic primary population gives probability 0.8 to five requests and 0.2 to 24. These values deliberately create an informative arrival at request six. Conditional on that arrival, 19 requests remain including the sixth. Before starting, the expected session length is 8.8. The cutoff is therefore a test of whether a client can profit from a change in expected remaining work. Secondary scores include the uniform distribution on 5 through 10 and every individual prefix. The short-only workload includes clients who experience the interruption with little time left to recover it.

Measure all four policies on each of 12 new key blocks, through 24 requests per arm, using the same input identities for each arm within a block. Counterbalance the order of the four arms with a Williams design. Use 0.8 times the observed prefix-five time plus 0.2 times the observed prefix-24 time for each arm within each block. Taking the exact weighted sum avoids arbitrary Monte Carlo noise from redrawing a length for each arm. A mixture benefit requires beating all three fixed catalogs on their mean times. Report the per-key differences and the extra latency on the sixth request. The designed workload supplies no evidence of the mix at a deployed service.

## Pilot forecast

The existing fixed-catalog pilot fitted a mean cold time and a mean warm time to each catalog. At 500 Mbit/s, it predicts a 17-to-19 warm saving of 17.691 ms per request. For each of six archived upgrade frames sent at 100 Mbit/s, subtract its ideal wire time and add its ideal wire time at 500 Mbit/s. This predicts 75.37 ms for +512 and 73.09 ms for +2048 on average. These projections assume residual processing, framing, acknowledgment and pacing overhead stays constant. The original pilot's raw-image-to-class clock and a new experiment that uses pre-encoded images may have different absolute service totals. The forecast of policy differences additionally assumes such common costs cancel across arms.

For a session that survives to six, the staged policy saves `(n−5) × 17.691 ms − 148.46 ms` against fixed 17. Its first projected gain occurs at request 14. Its gain reaches 187.66 ms at request 24. In a session ending at five, the switch and fixed 17 are identical in the model. At length five, the switch saves 48.09 ms over fixed 19. Once the switch occurs, fixed 19 is 100.37 ms ahead at every evaluated post-switch length because both arms now use the same catalog. A win over every fixed choice is possible at the population level even though the model always has a better or tied fixed arm for any known individual length.

| Policy | Primary weighted mean, prepared keys | Uniform 5–10, prepared keys | Primary with legacy preparation proxy |
| --- | ---: | ---: | ---: |
| Fixed 17 | 12.579 s | 10.911 s | 13.549 s |
| Fixed 18 | 12.609 s | 10.947 s | 13.634 s |
| Fixed 19 | 12.560 s | 10.914 s | 13.640 s |
| Switch at six | 12.541 s | 10.990 s | 13.534 s |

The primary forecast favors switching over fixed 19 by 18.40 ms per session. It favors fixed 17 over switching by 79.49 ms on the short-only distribution. For the same two lengths and any long-session probability `p`, the prepared-key switch advantage over fixed 19 is `48.09 − 148.46p` ms. The model therefore favors the switch over all three fixed arms when `0 < p < 0.324`, with outcomes sensitive to the input estimates. Adjacent prefixes reuse the same session, and all policy comparisons reuse the same key blocks.

For a preparation sensitivity only, use each pilot's mean initial setup CPU time, including key generation, installation into the client context and serialization. Treat the 109.62 ms preparation difference between the original direct-19 and direct-17 catalogs as a proxy for preparing the two incremental updates. The legacy pilot used a different implementation path, so this number does not directly measure two singleton preparations. The proxy gives 258.08 ms in total upgrade charges and requires 15 post-switch requests, reaching break-even at request 20. The component-added forecast saves 15.61 ms against fixed 17 under the primary law. If actual extra client preparation exceeds 187.66 ms, this model predicts that even a 24-request session fails to repay the update against fixed 17. Interpret the new preparation sensitivity using its actual recorded cost components.

## Why the workload matters

A geometric session length with constant hazard offers no more expected remaining work when the sixth request arrives than on first arrival. For such an untruncated distribution with mean `L`, conditional expected warm savings from upgrading at six are `L × 17.691 ms`. If those savings are at most the 148.46 ms charge, staying at 17 weakly dominates upgrading. If they exceed the charge, compare switching with fixed 19. Write `a = (1−1/L)^5` for the probability of reaching request six. The model predicts switch minus fixed 19 equals `(1−a)(L × 17.691 − 148.46) + (148.46 − 17.691 − 118.857)` ms. In this second case both terms are nonnegative. The last constant uses the pilot direct-19 cold premium. Thus a fixed arm weakly dominates this threshold on each constant-hazard law under these assumptions. A change in the hazard, prior information, or materially different costs could produce another conclusion.

The measured effect may change direction with client hardware, implementation, competing load or network round-trip latency. The pilot advantage of 18.40 ms is small relative to the 12.54-second expected total and to unmeasured between-session timing variation. The 12 prospective blocks provide the independent replication units for this specific benchmark.

## Reproduce the forecasts

Run `python3 work/switchtrial/design/forecast.py` from the original workspace. The script records the three historical input digests and the frozen rule digest. The included `forecast.json` contains its full 1–24 prefix forecasts. All input observations precede the new trial.
