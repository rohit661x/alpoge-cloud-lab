"""Rebuild the pilot forecast for the fixed survival-to-six experiment."""

import argparse
import csv
import hashlib
import json
import math
from pathlib import Path
from statistics import mean


DESIGN_DIR = Path(__file__).resolve().parent
ROOT = DESIGN_DIR.parents[2]
PILOT_FIT = 'work/convnext/analysis/pilot-fit.csv'
PILOT_RAW = 'work/conv17/speed/raw.jsonl'
UPDATE_RAW = 'work/convnext/upgrade/run/client.jsonl'


def json_rows(path):
    return [json.loads(line) for line in path.read_text().splitlines()]


def forecast(root):
    with (root / PILOT_FIT).open() as stream:
        fits = {int(row['catalog']): (float(row['cold_mean_s']), float(row['warm_mean_s']))
                for row in csv.DictReader(stream) if int(row['rate_mbps']) == 500}
    catalog_names = {17: 'split17', 18: 'split', 19: 'pruned'}
    key_rows = [r for r in json_rows(root / PILOT_RAW) if r['type'] == 'key']
    preparation = {catalog: mean((r['context_ns'] + r['galois_generation_install_ns'] + r['serialization_ns']) / 1e9
                                 for r in key_rows if r['arm'] == name)
                   for catalog, name in catalog_names.items()}
    preparation_premium = {cat: sec - preparation[17] for cat, sec in preparation.items()}
    updates = [r for r in json_rows(root / UPDATE_RAW) if r.get('kind') == 3]
    assert len(updates) == 6 and len(key_rows) == 9
    update_projection = {cat: mean(r['send_to_reply_ns'] / 1e9 - r['upload'] * 8 / 100e6 + r['upload'] * 8 / 500e6
                                   for r in updates if r['keys'] == cat) for cat in [18, 19]}
    update_total = sum(update_projection.values())
    warm_saving = fits[17][1] - fits[19][1]
    result = {
        'units': 'seconds unless specified',
        'source_sha256': {p: hashlib.sha256((root / p).read_bytes()).hexdigest() for p in [PILOT_FIT, PILOT_RAW, UPDATE_RAW]},
        'freeze_sha256': hashlib.sha256((DESIGN_DIR / 'freeze.json').read_bytes()).hexdigest(),
        'warm_saving_17_to_19_per_request_s': warm_saving,
        'update_projected_ack_s': update_projection,
        'update_projected_combined_ack_s': update_total,
        'mean_initial_client_preparation_s': preparation,
        'mean_initial_client_preparation_relative_to_17_s': preparation_premium,
        'maximum_incremental_client_preparation_for_win_over_17_at_24_s': 19 * warm_saving - update_total,
        'conventions': {},
    }
    for convention, increment in [('prepared', 0), ('all_in_proxy', preparation_premium[19])]:
        initial = {cat: 0 if convention == 'prepared' else preparation[cat] for cat in fits}
        prefixes = {}
        for n in range(1, 25):
            costs = {str(cat): initial[cat] + cold + (n - 1) * warm for cat, (cold, warm) in fits.items()}
            costs['switch'] = costs['17']
            if n >= 6:
                costs['switch'] = initial[17] + fits[17][0] + 4 * fits[17][1] + increment + update_total + (n - 5) * fits[19][1]
            prefixes[n] = costs
        primary = {arm: .8 * prefixes[5][arm] + .2 * prefixes[24][arm] for arm in prefixes[5]}
        short_uniform = {arm: mean(prefixes[n][arm] for n in range(5, 11)) for arm in primary}
        fixed_best = min(catalog_names, key=lambda c: primary[str(c)])
        result['conventions'][convention] = {
            'missing_key_preparation_s': increment,
            'first_strictly_better_request_vs_17_after_switch': 5 + math.floor((increment + update_total) / warm_saving) + 1,
            'primary_mean_s': primary,
            'primary_best_fixed': fixed_best,
            'primary_switch_minus_best_fixed_s': primary['switch'] - primary[str(fixed_best)],
            'uniform_5_to_10_mean_s': short_uniform,
            'prefix_s': prefixes,
        }
    return result


if __name__ == '__main__':
    cli = argparse.ArgumentParser(description=__doc__)
    cli.add_argument('--root', type=Path, default=ROOT)
    args = cli.parse_args()
    print(json.dumps(forecast(args.root), indent=2))
