"""Read only the num_turns column of the pinned public VisionArena train split."""
import argparse
from collections import Counter
from concurrent.futures import ThreadPoolExecutor
import hashlib
import json
from pathlib import Path
import re
import tempfile
import time
from urllib.error import HTTPError, URLError
from urllib.request import Request, urlopen

import pyarrow.parquet as pq

ROOT = Path(__file__).resolve().parent
REV = '1394b4f59ab6f1f2e5aff6bc15b448e15960e170'
SOURCE = 'https://huggingface.co/datasets/lmarena-ai/VisionArena-Chat/resolve/' + REV
SHARDS = 43


def ranged(url, bounds):
    for attempt in range(5):
        try:
            req = Request(url + '?column_num_turns=' + bounds,
                          headers={'Range': 'bytes=' + bounds, 'User-Agent': 'Research column aggregate/1'})
            with urlopen(req, timeout=35) as reply:
                if reply.status != 206:
                    raise ValueError('server did not support column-only range access')
                match = re.fullmatch(r'bytes (\d+)-(\d+)/(\d+)', reply.headers['Content-Range'])
                start, stop, size = map(int, match.groups())
                if bounds.startswith('-'):
                    assert stop + 1 == size and stop - start + 1 == int(bounds[1:])
                else:
                    assert (start,stop) == tuple(map(int,bounds.split('-')))
                data = reply.read(stop - start + 2)
                if len(data) != stop-start+1:
                    raise ValueError('short range read')
                return start, size, data
        except (HTTPError, URLError, TimeoutError, ConnectionError) as error:
            if attempt == 4:
                raise
            time.sleep(min(12, 2 ** attempt))
    raise AssertionError('retry loop')


def collect(shard):
    dest = ROOT / 'shards' / f'{shard:02}.json'
    if dest.is_file():
        return json.loads(dest.read_text())
    url = f'{SOURCE}/data/train-{shard:05}-of-{SHARDS:05}.parquet'
    _, size, trailer = ranged(url, '-8')
    assert trailer[4:] == b'PAR1'
    flen = int.from_bytes(trailer[:4], 'little')
    pos, _, footer = ranged(url, f'{size-8-flen}-{size-9}')
    checksums = []
    with tempfile.TemporaryFile() as file:
        file.write(b'PAR1')
        file.seek(pos)
        file.write(footer+trailer)
        file.flush()
        pf = pq.ParquetFile(file, pre_buffer=False)
        ids = [i for i in range(pf.metadata.num_columns) if pf.schema.column(i).path == 'num_turns']
        if len(ids)!=1:
            raise ValueError('expected one num_turns scalar column')
        for group in range(pf.num_row_groups):
            col = pf.metadata.row_group(group).column(ids[0])
            offset = min(x for x in [col.data_page_offset, col.dictionary_page_offset] if x is not None and x >= 0)
            _, _, data = ranged(url, f'{offset}-{offset+col.total_compressed_size-1}')
            checksums.append(hashlib.sha256(data).hexdigest())
            file.seek(offset)
            file.write(data)
        file.flush()
        table = pf.read(columns=['num_turns'],use_threads=False)
        values = table.column(0).to_pylist()
        if len(values) != pf.metadata.num_rows or any(type(v) is not int or v < 1 for v in values):
            raise ValueError('invalid session length or row count')
    result = {'shard':shard, 'rows':len(values),'counts':dict(sorted(Counter(values).items())),
              'column_sha256':checksums,'footer_sha256':hashlib.sha256(footer).hexdigest()}
    temp = dest.with_suffix('.tmp')
    temp.write_text(json.dumps(result,sort_keys=True)+'\n')
    temp.replace(dest)
    print(f'counted shard {shard+1}/{SHARDS} ({len(values)} records)', flush=True)
    return result


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--workers',type=int,default=5)
    a=p.parse_args()
    (ROOT/'shards').mkdir(exist_ok=True)
    with ThreadPoolExecutor(max_workers=a.workers) as pool:
        rows=list(pool.map(collect,range(SHARDS)))
    hist=Counter()
    for r in rows:
        hist.update({int(k):v for k,v in r['counts'].items()})
    result={'revision':REV,'split':'train','column':'num_turns','shards':len(rows),
            'counts':dict(sorted(hist.items())),'n':hist.total(),
            'clipped_above_24':sum(v for k,v in hist.items() if k>24),
            'survive_to_six':sum(v for k,v in hist.items() if k>=6)}
    (ROOT/'histogram.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result),flush=True)


if __name__ == '__main__':
    main()
