"""Replay the separate external-length sensitivity from committed, paired prefixes."""
import argparse
from collections import Counter
import json
from pathlib import Path
from statistics import mean

ARMS=('adaptive','fixed17','fixed18','fixed19')


def raw(root):
    config=json.loads((root/'plan.json').read_text())
    output={}
    for s in config['sessions']:
        base=root/f"key-{s['key']:03d}"
        record=json.loads((base/'complete.json').read_text())
        attempt=base/record['attempt']
        arms={}
        for arm in ARMS:
            records=[json.loads(l) for l in (attempt/f'{arm}-client.jsonl').read_text().splitlines()]
            queries=[r for r in records if r['kind']==2]
            assert list(range(1,25))==[r['query'] for r in queries]
            observed=[r['cumulative_ns'] for r in queries]
            assert observed==sorted(observed)
            arms[arm] = observed
        output[s['key']] = arms
    assert output and (root/'complete.json').exists()
    return output


def score(rows,hist):
    counts=Counter()
    for length,n in hist.items():
        counts[min(length,24)]+=n
    total=sum(counts.values())
    scores=[{a:sum(counts[q]*endpoints[a][q-1] for q in counts)/total for a in ARMS} for endpoints in rows.values()]
    averages={a:mean(s[a] for s in scores)/1e6 for a in ARMS}
    fixed=min(ARMS[1:],key=averages.get)
    return {'means_ms':averages,'best_fixed':fixed,'adaptive_minus_best_ms':averages['adaptive']-averages[fixed],
            'adaptive_minus_fixed_ms_by_key':{a:[(s['adaptive']-s[a])/1e6 for s in scores] for a in ARMS[1:]}}


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--run',type=Path,required=True)
    p.add_argument('--hist',type=Path,default=Path(__file__).with_name('histogram.json'))
    p.add_argument('--out',type=Path,required=True)
    a=p.parse_args()
    hist=json.loads(a.hist.read_text())
    records={int(k):n for k,n in hist['counts'].items()}
    assert sum(records.values())==hist['n']
    rows=raw(a.run)
    r=score(rows,records)
    r.update({'keys':len(rows), 'source_conversations':hist['n'],'mapped_longer_than_24':hist['clipped_above_24'],
              'trigger_fraction':hist['survive_to_six']/hist['n'], 'scope':'Recorded vision-language conversation lengths reweight encrypted ConvMNIST measurements on one host; the tasks and users differ.'})
    a.out.write_text(json.dumps(r,indent=2)+'\n')


if __name__=='__main__':
    main()
