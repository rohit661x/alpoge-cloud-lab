"""On-demand catalog creation experiment. Reuse the frozen trial's native workers and socket stopwatch."""
import argparse
import fcntl
import gc
import json
from pathlib import Path
from types import SimpleNamespace

import trial as core
from public_catalog import attach_galois


HERE = Path(__file__).resolve().parent
PROTOCOL = HERE / "lazy-protocol.json"


def shared_inputs(s, fixtures, attempt):
    start = core.clock()
    original = core.ref.getctx()
    # This in-memory clone source contains only the private/public keypair, parameters and flags.
    # TenSEAL restores a private context's evaluation keys via generated flags, which are disabled.
    private = original.serialize(save_public_key=True, save_secret_key=True,
                                 save_galois_keys=False, save_relin_keys=False)
    public = original.serialize(save_public_key=True, save_secret_key=False,
                                save_galois_keys=False, save_relin_keys=False)
    pair_ready = core.clock()
    requests, panel, encryption_ns = [], [], []
    for q in range(1, s["length"] + 1):
        fixture = fixtures[(s["image_offset"] + q - 1) % len(fixtures)]
        start_q = core.clock()
        image = core.np.asarray(fixture["input"]).reshape(28, 28).tolist()
        enc, windows = core.ts.im2col_encoding(original, image, 7, 7, 3)
        if windows != 64:
            raise RuntimeError("unexpected CKKS packing")
        payload = enc.serialize()
        encryption_ns.append(core.clock()-start_q)
        requests.append(payload)
        panel.append(dict(query=q, index=fixture["index"], label=fixture["label"],
                          reference_logits=fixture["logits"], payload_sha256=core.sha(payload)))
    info = dict(key=s["key"], fingerprint=core.sha(public), panel=panel,
                common_private_clone_source_ns=pair_ready-start, encrypt_serialize_ns=encryption_ns)
    core.commit(attempt / "key.json", info)
    return private, requests, info


class GenerateOnce:
    """Provide a public blob only when the existing socket generator first requests that count."""
    def __init__(self, make):
        self.make = make
        self.used = set()

    def __getitem__(self, count):
        if count in self.used:
            raise RuntimeError("unexpected repeat catalog material request")
        self.used.add(count)
        return self.make(count)


def lazy_arm(s, arm, attempt, private, requests, shared):
    # A private clone is local to this client and contains no evaluation keys before the clock.
    ctx = core.ts.context_from(private, n_threads=1)
    if not ctx.is_private() or ctx.has_galois_keys() or ctx.has_relin_keys():
        raise RuntimeError("client clone must start with only the private/public key pair")
    public = ctx.serialize(save_public_key=True, save_secret_key=False,
                           save_galois_keys=False, save_relin_keys=False)
    if core.sha(public) != shared["fingerprint"]:
        raise RuntimeError("client clone has a different public key")
    info = dict(shared, contexts={}, deltas={})
    gen = None
    first = None
    with (attempt / f"{arm}-preparation.jsonl").open("x") as prep_log:
        def initial(count):
            nonlocal first
            first = core.clock()
            ctx.generate_relin_keys()
            relin_ready = core.clock()
            steps = [step for step in core.ref.SINGLE
                     if not (step == 512 and count < 18 or step == 2048 and count < 19)]
            builder = core.sa.KeyGenerator(ctx.seal_context().data, ctx.secret_key().data)
            selected = core.sa.GaloisKeys()
            generator_ready = core.clock()
            builder.create_galois_keys([core.element(step) for step in steps], selected)
            catalog_ready = core.clock()
            present = [step for step in core.ref.SINGLE if selected.has_key(core.element(step))]
            if present != steps or selected.size() != count or ctx.has_galois_keys():
                raise RuntimeError("initial key generation produced an unexpected physical inventory")
            before_serial = core.clock()
            galois_bytes = core.update.serialize_public_keys(selected)
            keys_serialized = core.clock()
            base_public = ctx.serialize(save_secret_key=False, save_galois_keys=False)
            base_serialized = core.clock()
            payload = attach_galois(base_public, galois_bytes)
            serialized = core.clock()
            info["contexts"][str(count)] = core.sha(payload)
            core.emit(prep_log, dict(kind=1, keys=count, query=0, start_ns=first, relin_ready_ns=relin_ready,
                          generator_ready_ns=generator_ready, catalog_ready_ns=catalog_ready,
                          requested_initial_steps=steps, initial_present_steps=present,
                          initial_galois_key_count=selected.size(), client_has_galois_holder=ctx.has_galois_keys(),
                          serialize_start_ns=before_serial, keys_serialized_ns=keys_serialized,
                          base_context_serialized_ns=base_serialized, serialized_ns=serialized,
                          base_context_bytes=len(base_public), serialized_galois_bytes=len(galois_bytes),
                          payload_sha256=info["contexts"][str(count)], bytes=len(payload)))
            return payload

        def singleton(count):
            nonlocal gen
            start = core.clock()
            if gen is None:
                gen = core.sa.KeyGenerator(ctx.seal_context().data, ctx.secret_key().data)
            gen_ready = core.clock()
            one = core.sa.GaloisKeys()
            gen.create_galois_keys([core.element(core.STEPS[count])], one)
            built = core.clock()
            payload = core.update.serialize_public_keys(one)
            serialized = core.clock()
            info["deltas"][str(count)] = core.sha(payload)
            core.emit(prep_log, dict(kind=3, keys=count, query=s[f"switch{count}"], start_ns=start,
                          generator_ready_ns=gen_ready, key_ready_ns=built, serialized_ns=serialized,
                          payload_sha256=info["deltas"][str(count)], bytes=len(payload)))
            return payload

        # Core transactions pull the initial blob after connection and the singleton blob only
        # on its trigger query, after all previous responses. Query tracing and decryption are identical.
        core.run_arm(s, arm, attempt, ctx, GenerateOnce(initial), GenerateOnce(singleton), requests, info)

    # Preserve the incremental socket journal verbatim and publish aligned inclusive columns.
    client_path = attempt / f"{arm}-client.jsonl"
    client = read_rows(client_path)
    aligned = attempt / f"{arm}-inclusive.tmp"
    with aligned.open("x") as file:
        for row in client:
            core.emit(file, dict(row, setup_write_cumulative_ns=row["cumulative_ns"],
                                 provisioning_start_ns=first, cumulative_ns=row["end_ns"]-first))
    client_path.rename(attempt / f"{arm}-socket-client.jsonl")
    aligned.replace(client_path)
    summary_path = attempt / f"{arm}-summary.json"
    summary = core.read(summary_path)
    summary_path.rename(attempt / f"{arm}-socket-summary.json")
    core.commit(summary_path, dict(summary, start_ns=first, elapsed_ns=summary["end_ns"]-first,
                first_setup_write_ns=summary["start_ns"], setup_write_elapsed_ns=summary["elapsed_ns"]))
    prefixes = [dict(query=r["query"], end_ns=r["end_ns"], provisioning_inclusive_ns=r["end_ns"]-first)
                for r in client if r["kind"] == 2]
    core.commit(attempt / f"{arm}-provisioning.json", dict(key=s["key"], arm=arm,
                provisioning_start_ns=first, first_setup_write_ns=client[0]["start_ns"],
                last_decrypt_ns=client[-1]["end_ns"], elapsed_ns=client[-1]["end_ns"]-first,
                contexts=info["contexts"], deltas=info["deltas"], prefixes=prefixes))


def read_rows(path):
    return [json.loads(line) for line in path.read_text().splitlines()]


def manifest(out, plan, resume):
    path = out / "plan.json"
    if path.exists():
        if not resume or core.read(path) != plan:
            raise ValueError("existing design: --resume with the same protocol and host is required")
    else:
        core.commit(path, plan)
    host = core.environment(path)
    host["sha256"].update(lazy_harness=core.sha(Path(__file__).read_bytes()),
                          lazy_protocol=core.sha(PROTOCOL.read_bytes()),
                          public_catalog_builder=core.sha((HERE / "public_catalog.py").read_bytes()),
                          tenseal_public_schema=core.sha((HERE / "tensealcontext.proto").read_bytes()))
    host_path = out / "host.json"
    if host_path.exists():
        if core.read(host_path)["environment"] != host:
            raise ValueError("frozen lazy experiment inputs or environment changed")
    else:
        core.commit(host_path, dict(frozen_utc=core.now(), environment=host))


def plan_for(protocol, fixture_count):
    c, p = protocol["cohort"], protocol["policy"]
    args = SimpleNamespace(lengths=str(c["requests"]), rates=str(p["upload_mbps"]), plan=None,
                           keys=c["key_blocks"], switch18=p["switch18"], switch19=p["switch19"],
                           seed=c["panel_seed"])
    plan = core.make_plan(args, fixture_count)
    plan["endpoint"] = protocol["endpoint"]
    plan["experiment"] = "fresh on-demand generation; independently randomized evaluation keys"
    plan["protocol_sha256"] = core.sha(PROTOCOL.read_bytes())
    return plan


def execute(out, resume, freeze_only):
    fixtures = core.read(core.BASE / "model/samples.json")
    plan = plan_for(core.read(PROTOCOL), len(fixtures))
    out.mkdir(parents=True, exist_ok=True)
    with (out / ".lock").open("a") as lock:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        manifest(out, plan, resume)
        if freeze_only:
            return
        if (out / "complete.json").exists():
            print("All on-demand blocks already complete.", flush=True)
            return
        with (out / "progress.jsonl").open("a") as progress:
            def checkpoint(event, **fields):
                row = dict(event=event, utc=core.now(), **fields)
                core.emit(progress, row)
                print(json.dumps(row, separators=(",", ":")), flush=True)

            for s in plan["sessions"]:
                key = s["key"]
                folder = out / f"key-{key:03d}"
                folder.mkdir(exist_ok=True)
                if (folder / "complete.json").exists():
                    checkpoint("reuse", key=key)
                    continue
                serial = 1 + max((int(p.name.split("-")[1]) for p in folder.glob("attempt-*")), default=0)
                attempt = folder / f"attempt-{serial:03d}"
                attempt.mkdir()
                checkpoint("key_start", key=key, attempt=attempt.name)
                private, requests, info = shared_inputs(s, fixtures, attempt)
                for arm in s["arm_order"]:
                    checkpoint("arm_start", key=key, arm=arm, attempt=attempt.name)
                    lazy_arm(s, arm, attempt, private, requests, info)
                    checkpoint("arm_complete", key=key, arm=arm, attempt=attempt.name)
                core.commit(folder / "complete.json", dict(key=key, attempt=attempt.name,
                            fingerprint=info["fingerprint"], completed_utc=core.now()))
                checkpoint("key_complete", key=key, attempt=attempt.name)
                del private, requests, info
                gc.collect()
            core.commit(out / "complete.json", dict(keys=len(plan["sessions"]),
                        encrypted_evaluations=4*sum(s["length"] for s in plan["sessions"]),
                        plan_sha256=core.sha((out / "plan.json").read_bytes()), completed_utc=core.now()))
            checkpoint("complete", keys=len(plan["sessions"]))


if __name__ == "__main__":
    cli = argparse.ArgumentParser(description=__doc__)
    cli.add_argument("--out", required=True, type=Path)
    cli.add_argument("--resume", action="store_true")
    cli.add_argument("--freeze-only", action="store_true")
    args = cli.parse_args()
    execute(args.out.resolve(), args.resume, args.freeze_only)
