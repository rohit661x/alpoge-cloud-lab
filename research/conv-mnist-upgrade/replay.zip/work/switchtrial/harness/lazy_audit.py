"""Reconstruct the on-demand trial's stopwatches and contrasts from its independent raw receipts."""
import argparse
import hashlib
import json
import math
from pathlib import Path
from statistics import mean

HERE = Path(__file__).resolve().parent
ARMS = ("adaptive", "fixed17", "fixed18", "fixed19")
WILLIAMS = ((0, 1, 3, 2), (1, 2, 0, 3), (2, 3, 1, 0), (3, 0, 2, 1))
STEPS = list(2**i for i in range(12)) + list(-(2**i) for i in range(7))


def read(path):
    return json.loads(path.read_text())


def rows(path):
    return [json.loads(line) for line in path.read_text().splitlines()]


def require(ok, description):
    if not ok:
        raise ValueError(description)


def hash_file(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def expected_ops(arm):
    n = 17 if arm == "adaptive" else int(arm[-2:])
    expected = [(1, n, 0)]
    for q in range(1, 25):
        if arm == "adaptive" and q == 6:
            expected.extend([(3, 18, 6), (3, 19, 6)])
            n = 19
        expected.append((2, n, q))
    return expected


def check_arm(path, key, arm, info, previous_end):
    log = rows(path / f"{arm}-client.jsonl")
    socket_log = rows(path / f"{arm}-socket-client.jsonl")
    server = rows(path / f"{arm}-server.jsonl")
    generated = rows(path / f"{arm}-preparation.jsonl")
    setup = read(path / f"{arm}-provisioning.json")
    summary = read(path / f"{arm}-summary.json")
    pid = summary["pid"]
    ops = [(r["kind"], r["keys"], r["query"]) for r in log]
    require(ops == expected_ops(arm), f"{key}/{arm} invalid wire schedule")
    require([(r["kind"], r["keys"], r["query"]) for r in generated] ==
            [op for op in ops if op[0] != 2], "generation schedule")
    first = generated[0]["start_ns"]
    require(previous_end <= first and summary["connect_end_ns"] <= first <= log[0]["start_ns"],
            "on-demand generation must begin after connection and the previous arm")
    require(summary["fingerprint"] == info["fingerprint"], "summary public lineage")
    require(first == setup["provisioning_start_ns"] and setup["first_setup_write_ns"] == log[0]["start_ns"],
            "setup start mismatch")
    previous_end, upload, download = first, 0, 0
    prefix, maximum_error, wrong = {}, 0.0, 0
    events = iter(generated)
    for seq, ((kind, n, q), a, b, raw) in enumerate(zip(ops, log, server, socket_log, strict=True)):
        require((a["seq"], a["pid"], a["key"], a["arm"]) == (seq, pid, key, arm), "client identity")
        require((b["seq"], b["pid"], b["key"], b["arm"], b["kind"], b["keys"], b["query"]) ==
                (seq, pid, key, arm, kind, n, q), "worker identity")
        require((a["upload"], a["download"], a["payload_sha256"]) ==
                (b["received"], b["sent"], b["payload_sha256"]), "independent receipt")
        require(previous_end <= a["start_ns"] <= a["reply_ns"] <= a["end_ns"], "clock ordering")
        upload += a["upload"]
        download += a["download"]
        require((a["cumulative_upload"], a["cumulative_download"]) == (upload, download), "byte accounting")
        require(a["setup_write_cumulative_ns"] == a["end_ns"]-log[0]["start_ns"] == raw["cumulative_ns"],
                "unmodified inner socket clock")
        require(a["provisioning_start_ns"] == first and a["cumulative_ns"] == a["end_ns"]-first and
                all(raw[k] == a[k] for k in raw if k != "cumulative_ns"), "inclusive client clock and raw journal")
        if kind != 2:
            g = next(events)
            times = ([g["start_ns"], g["relin_ready_ns"], g["generator_ready_ns"], g["catalog_ready_ns"],
                      g["serialize_start_ns"], g["keys_serialized_ns"], g["base_context_serialized_ns"], g["serialized_ns"]] if kind == 1 else
                     [g["start_ns"], g["generator_ready_ns"], g["key_ready_ns"], g["serialized_ns"]])
            require(previous_end <= times[0] < times[-1] <= a["start_ns"] and times == sorted(times),
                    "catalog preparation must precede its write and follow the previous response")
            field = "contexts" if kind == 1 else "deltas"
            require(a["payload_sha256"] == g["payload_sha256"] == setup[field][str(n)] and
                    g["bytes"] + 10 == a["upload"] and a["download"] == 19, "prepared payload receipt")
            present = [step for step in STEPS if not (step == 512 and n < 18 or step == 2048 and n < 19)]
            require(b["present_steps"] == present, "resident physical inventory")
            if kind == 1:
                require(g["requested_initial_steps"] == g["initial_present_steps"] == present and
                        g["initial_galois_key_count"] == n and g["client_has_galois_holder"] is False,
                        "client request, actual client directions, and evaluator inventory")
                # The only additional protobuf bytes are field 5 / its length, and any public
                # message length-varint growth when replacing the outer field 2 header.
                slack = g["bytes"] - g["base_context_bytes"] - g["serialized_galois_bytes"]
                require(2 <= slack <= 20, "official public/SEAL wire composition")
        else:
            sample = info["panel"][q-1]
            require((a["index"], a["label"], a["payload_sha256"]) ==
                    (sample["index"], sample["label"], sample["payload_sha256"]), "paired query identity")
            logits = a["logits"]
            require(len(logits) == 10 and all(map(math.isfinite, logits)), "nonfinite logits")
            pred = max(range(10), key=logits.__getitem__)
            err = max(abs(x-y) for x, y in zip(logits, sample["reference_logits"], strict=True))
            require(pred == a["prediction"] and err == a["error"], "prediction or error")
            maximum_error = max(maximum_error, err)
            wrong += int(pred != sample["label"])
            t = a["end_ns"]-first
            saved = setup["prefixes"][q-1]
            require((saved["query"], saved["end_ns"], saved["provisioning_inclusive_ns"]) ==
                    (q, a["end_ns"], t), "inclusive prefix")
            prefix[q] = dict(ns=t, upload=upload, download=download, prediction=pred)
        previous_end = a["end_ns"]
    require(setup["elapsed_ns"] == previous_end-first and summary["end_ns"] == previous_end and
            summary["start_ns"] == first and summary["elapsed_ns"] == previous_end-first and
            summary["setup_write_elapsed_ns"] == previous_end-log[0]["start_ns"] and
            (summary["upload"], summary["download"]) == (upload, download), "terminal summaries")
    return dict(arm=arm, pid=pid, prefix=prefix, max_error=maximum_error, wrong=wrong,
                initial_sha=generated[0]["payload_sha256"], end=previous_end)


def run(out, fixture_path):
    plan = read(out / "plan.json")
    host = read(out / "host.json")["environment"]
    complete = read(out / "complete.json")
    require((complete["keys"], complete["encrypted_evaluations"]) == (4, 384), "planned four full blocks")
    require(hash_file(out / "plan.json") == complete["plan_sha256"] == host["sha256"]["plan"], "frozen plan")
    require(plan["protocol_sha256"] == hash_file(HERE / "lazy-protocol.json") == host["sha256"]["lazy_protocol"],
            "frozen lazy protocol")
    require(hash_file(HERE / "lazy.py") == host["sha256"]["lazy_harness"] and
            hash_file(HERE / "trial.py") == host["sha256"]["harness"], "frozen drivers")
    require(hash_file(HERE / "public_catalog.py") == host["sha256"]["public_catalog_builder"] and
            hash_file(HERE / "tensealcontext.proto") == host["sha256"]["tenseal_public_schema"],
            "pinned public context construction")
    require(hash_file(fixture_path) == host["sha256"]["fixtures"], "frozen model inputs")
    fixtures = read(fixture_path)
    require(len(plan["sessions"]) == 4, "number of key blocks")
    fingerprints, input_digests, worker_pids, initial_digests = set(), set(), set(), set()
    blocks = []
    previous_end = 0
    for key, session in enumerate(plan["sessions"]):
        order = [ARMS[x] for x in WILLIAMS[key]]
        require(session == dict(key=key, length=24, rate_mbps=500, switch18=6, switch19=6,
                                image_offset=(2718+key)%8, arm_order=order), "frozen session design")
        folder = out / f"key-{key:03d}"
        marker = read(folder / "complete.json")
        path = folder / marker["attempt"]
        info = read(path / "key.json")
        require(marker["key"] == info["key"] == key and marker["fingerprint"] == info["fingerprint"] and
                marker["fingerprint"] not in fingerprints, "fresh key fingerprint")
        fingerprints.add(marker["fingerprint"])
        require(len(info["panel"]) == 24, "panel length")
        for q, sample in enumerate(info["panel"], 1):
            expected = fixtures[(2718 + key + q - 1) % 8]
            require((sample["query"], sample["index"], sample["label"], sample["reference_logits"]) ==
                    (q, expected["index"], expected["label"], expected["logits"]), "clear reference panel")
            require(sample["payload_sha256"] not in input_digests, "fresh ciphertext per ordinal")
            input_digests.add(sample["payload_sha256"])
        arms = {}
        for arm in order:
            result = check_arm(path, key, arm, info, previous_end)
            require(result["pid"] not in worker_pids and result["initial_sha"] not in initial_digests,
                    "each arm requires a fresh worker and independently built initial context")
            worker_pids.add(result["pid"])
            initial_digests.add(result["initial_sha"])
            previous_end = result["end"]
            arms[arm] = result
        times = {}
        for arm, a in arms.items():
            p = a["prefix"]
            # Numerators retain integer nanoseconds across both prefix weights.
            times[arm] = dict(mixture_s=(4*p[5]["ns"]+p[24]["ns"])/5e9,
                              uniform_5_10_s=mean(p[q]["ns"] for q in range(5,11))/1e9,
                              prefix5_s=p[5]["ns"]/1e9, prefix24_s=p[24]["ns"]/1e9,
                              query6_s=(p[6]["ns"]-p[5]["ns"])/1e9, wrong=a["wrong"],
                              max_absolute_logit_error=a["max_error"])
        disagreements = sum(len({a["prefix"][q]["prediction"] for a in arms.values()}) > 1 for q in range(1,25))
        blocks.append(dict(key=key, fingerprint=marker["fingerprint"], by_arm=times,
                           cross_arm_class_disagreement_ordinals=disagreements))
    runs = {arm: {f:mean(k["by_arm"][arm][f] for k in blocks) for f in
                  ("mixture_s", "uniform_5_10_s", "prefix5_s", "prefix24_s", "query6_s")} for arm in ARMS}
    contrasts = {arm:[k["by_arm"]["adaptive"]["mixture_s"]-k["by_arm"][arm]["mixture_s"] for k in blocks]
                 for arm in ARMS[1:]}
    best = min(ARMS[1:], key=lambda arm: runs[arm]["mixture_s"])
    return dict(independent_keys=len(fingerprints), encrypted_evaluations=384, distinct_ciphertexts=len(input_digests),
                distinct_workers=len(worker_pids), mean_by_arm=runs, paired_mixture_differences_s=contrasts,
                mean_paired_mixture_differences_s={a:mean(d) for a,d in contrasts.items()},
                best_fixed_mixture=best, active_minus_best_fixed_mixture_s=mean(contrasts[best]),
                class_errors=sum(k["by_arm"][arm]["wrong"] for k in blocks for arm in ARMS),
                maximum_absolute_logit_error=max(k["by_arm"][arm]["max_absolute_logit_error"] for k in blocks for arm in ARMS),
                blocks=blocks)


if __name__ == "__main__":
    cli = argparse.ArgumentParser(description=__doc__)
    cli.add_argument("--run", required=True, type=Path)
    cli.add_argument("--fixtures", type=Path, default=HERE.parents[1] / "second-trained/model/samples.json")
    cli.add_argument("--out", type=Path)
    args = cli.parse_args()
    result = json.dumps(run(args.run, args.fixtures), indent=2, allow_nan=False) + "\n"
    if args.out:
        args.out.write_text(result)
    else:
        print(result, end="")
