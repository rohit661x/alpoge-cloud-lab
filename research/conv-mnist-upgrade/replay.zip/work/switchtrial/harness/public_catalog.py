"""Attach one SEAL GaloisKeys serialization to the pinned public TenSEALContextProto."""
from collections import namedtuple

Field = namedtuple("Field", "number wire start body end")


def varint(value):
    output = bytearray()
    while value >= 128:
        output.append(128 | (value & 127))
        value >>= 7
    output.append(value)
    return bytes(output)


def read_varint(data, pos):
    value = 0
    for shift in range(0, 70, 7):
        if pos >= len(data):
            break
        byte = data[pos]
        pos += 1
        value |= (byte & 127) << shift
        if byte < 128:
            return value, pos
    raise ValueError("malformed protobuf varint")


def fields(data):
    pos = 0
    while pos < len(data):
        start = pos
        tag, body = read_varint(data, pos)
        number, wire = divmod(tag, 8)
        if number == 0:
            raise ValueError("invalid protobuf field number")
        if wire == 0:
            _, end = read_varint(data, body)
        elif wire == 1:
            end = body + 8
        elif wire == 2:
            size, body = read_varint(data, body)
            end = body + size
        elif wire == 5:
            end = body + 4
        else:
            raise ValueError("unsupported protobuf wire type")
        if end > len(data):
            raise ValueError("truncated protobuf field")
        yield Field(number, wire, start, body, end)
        pos = end


def attach_galois(base, galois):
    if not galois:
        raise ValueError("empty SEAL GaloisKeys object")
    raw = memoryview(base)
    top = list(fields(raw))
    public = [f for f in top if f.number == 2]
    if (len(public) != 1 or public[0].wire != 2 or any(f.number == 3 for f in top) or
            sum(f.number == 1 and f.wire == 2 for f in top) != 1):
        raise ValueError("expected a single public context and parameters, with no private context")
    p = public[0]
    original = raw[p.body:p.end]
    nested = list(fields(original))
    if (any(f.number == 5 for f in nested) or
            any(sum(f.number == n and f.wire == 2 for f in nested) != 1 for n in (1, 4))):
        raise ValueError("base must contain public and relinearization keys, with no Galois field")
    # Field 5 of TenSEALPublicProto is bytes. Field 2 of TenSEALContextProto is that message.
    # Preserve all other fields byte-for-byte, including encryption_type if present.
    addition_header = b"\x2a" + varint(len(galois))
    public_size = len(original) + len(addition_header) + len(galois)
    return b"".join((raw[:p.start], b"\x12", varint(public_size), original,
                     addition_header, galois, raw[p.end:]))
