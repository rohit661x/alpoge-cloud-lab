"""Measure paired public CKKS catalog sessions on a paced local TCP socket."""
import argparse
from datetime import datetime, timezone
import fcntl
import gc
import hashlib
import json
import math
import multiprocessing as mp
import os
from pathlib import Path
import platform
import socket
import sys
import time

HERE = Path(__file__).resolve().parent
WORK = HERE.parents[1]
BASE = Path(os.environ.get("CONVMNIST_BASE", WORK / "second-trained")).resolve()
ADAPTER = Path(os.environ.get("CONVMNIST_ADAPTER", WORK / "convnext/upgrade")).resolve()
THREAD_CAPS = ("OPENBLAS_NUM_THREADS", "VECLIB_MAXIMUM_THREADS", "OMP_NUM_THREADS",
               "MKL_NUM_THREADS", "BLIS_NUM_THREADS", "NUMEXPR_NUM_THREADS")
for name in THREAD_CAPS:
    os.environ[name] = "1"
sys.path[:0] = [str(BASE / "patched/lib"), str(ADAPTER), str(BASE / "transport")]

import numpy as np
import tenseal as ts
import tenseal.sealapi as sa
import _tenseal_cpp
import _sealapi_cpp
import _conv_key_update as update
import reference as ref

clock = time.perf_counter_ns
ARMS = ("adaptive", "fixed17", "fixed18", "fixed19")
WILLIAMS = ((0, 1, 3, 2), (1, 2, 0, 3), (2, 3, 1, 0), (3, 0, 2, 1))
STEPS = {18: 512, 19: 2048}


def now():
    return datetime.now(timezone.utc).isoformat()


def sha(data):
    return hashlib.sha256(data).hexdigest()


def emit(file, row):
    file.write(json.dumps(row, separators=(",", ":"), allow_nan=False) + "\n")
    file.flush()


def commit(path, row):
    temporary = path.with_suffix(".tmp")
    temporary.write_text(json.dumps(row, indent=2, allow_nan=False) + "\n")
    temporary.replace(path)


def read(path):
    return json.loads(path.read_text())


def threshold(value):
    if value is None or str(value).lower() == "never":
        return None
    if isinstance(value, bool) or not str(value).isdigit() or int(value) < 1:
        raise ValueError("switch points must be positive query indices or never")
    return int(value)


def make_plan(args, n_images):
    lengths = [int(x) for x in args.lengths.split(",")]
    rates = [float(x) for x in args.rates.split(",")]
    custom = read(args.plan)["sessions"] if args.plan else [{} for _ in range(args.keys)]
    if not custom:
        raise ValueError("the design needs at least one key block")
    sessions = []
    for i, overrides in enumerate(custom):
        s = dict(key=i, length=lengths[i % len(lengths)], rate_mbps=rates[i % len(rates)],
                 switch18=args.switch18, switch19=args.switch19,
                 image_offset=(args.seed + i) % n_images,
                 arm_order=[ARMS[j] for j in WILLIAMS[i % 4]])
        if set(overrides) - set(s):
            raise ValueError(f"unknown session fields {set(overrides) - set(s)}")
        s.update(overrides)
        for field in ("switch18", "switch19"):
            s[field] = threshold(s[field])
        if s["key"] != i or type(s["length"]) != int or s["length"] < 1:
            raise ValueError("keys must be sequential and lengths positive")
        if not math.isfinite(s["rate_mbps"]) or s["rate_mbps"] <= 0:
            raise ValueError("upload rate must be positive and finite")
        if sorted(s["arm_order"]) != sorted(ARMS):
            raise ValueError("arm_order must contain each of the four arms once")
        if type(s["image_offset"]) != int or not 0 <= s["image_offset"] < n_images:
            raise ValueError("image offset outside panel")
        if s["switch19"] is not None and (s["switch18"] is None or s["switch19"] < s["switch18"]):
            raise ValueError("the +512 addition must precede or coincide with the +2048 addition")
        sessions.append(s)
    return dict(schema_version=1, sessions=sessions, image_count=n_images,
                panel_rule="(image_offset + one-based query - 1) modulo image_count, fresh encryption per query",
                endpoint="first setup frame write through decrypt of query k, continuous client monotonic wall time",
                upload="all setup, update and encrypted request frames, 64 KiB absolute-deadline pacing, decimal Mbit/s",
                reply="unpaced loopback replies with receipt of full request-frame byte count and catalog count")


def element(step):
    return pow(3, step % 4096, 16384)


def inventory(ctx, count):
    keys = ctx.galois_keys().data
    present = [s for s in ref.SINGLE if keys.has_key(element(s))]
    expected = [s for s in ref.SINGLE if s not in [step for n, step in STEPS.items() if n > count]]
    if keys.size() != count or present != expected:
        raise RuntimeError(f"unexpected physical rotation-key inventory for {count}")
    return present


def prepare(s, fixtures, attempt):
    started = clock()
    ctx = ref.getctx()
    context_ready = clock()
    ctx.generate_galois_keys()  # TenSEAL's catalog holder initially contains its default keys.
    holder_ready = clock()
    ref.install_keys(ctx, "split17")
    base_ready = clock()
    inventory(ctx, 17)
    snapshot_start = clock()
    contexts = {17: ctx.serialize(save_secret_key=False)}
    snapshot_ns = {"17": clock() - snapshot_start}
    prep = dict(common_context=context_ready-started, common_galois_holder=holder_ready-context_ready,
                base17_generate_install=base_ready-holder_ready, snapshot=snapshot_ns,
                delta={}, bulk_fixed={}, encrypt_serialize=[])
    prep["bulk_fixed"]["17"] = dict(generate_install=prep["base17_generate_install"], serialize=snapshot_ns["17"])
    deltas = {}
    gen_start = clock()
    gen = sa.KeyGenerator(ctx.seal_context().data, ctx.secret_key().data)
    prep["delta_key_generator_init"] = clock() - gen_start
    for count, step in STEPS.items():
        generation_start = clock()
        singleton = sa.GaloisKeys()
        gen.create_galois_keys([element(step)], singleton)
        generated = clock()
        deltas[count] = update.serialize_public_keys(singleton)
        serialized = clock()
        update.install_one(ctx.galois_keys().data, ctx.seal_context().data, deltas[count], element(step))
        installed = clock()
        inventory(ctx, count)
        snapshot_start = clock()
        contexts[count] = ctx.serialize(save_secret_key=False)
        snapshot_ns[str(count)] = clock()-snapshot_start
        prep["delta"][str(count)] = dict(generate=generated-generation_start, serialize=serialized-generated,
                                         install_into_client_snapshot=installed-serialized)
    fingerprint = sha(ctx.serialize(save_public_key=True, save_secret_key=False,
                                    save_galois_keys=False, save_relin_keys=False))
    public_ready = clock()

    # Fresh evaluation randomness under the same secret times each fixed catalog's direct
    # bulk constructor. These probes never replace the exact nested wire bytes above.
    probe_order = (18, 19) if s["key"] % 2 == 0 else (19, 18)
    for count in probe_order:
        t0 = clock()
        ref.install_keys(ctx, {18:"split", 19:"pruned"}[count])
        t1 = clock()
        probe = ctx.serialize(save_secret_key=False)
        t2 = clock()
        inventory(ctx, count)
        prep["bulk_fixed"][str(count)] = dict(generate_install=t1-t0, serialize=t2-t1)
        del probe
    panel, requests = [], []
    panel_start = clock()
    for q in range(1, s["length"] + 1):
        sample = fixtures[(s["image_offset"] + q - 1) % len(fixtures)]
        enc_start = clock()
        image = np.array(sample["input"]).reshape(28, 28).tolist()
        enc, windows = ts.im2col_encoding(ctx, image, 7, 7, 3)
        if windows != 64:
            raise RuntimeError("unexpected packing")
        payload = enc.serialize()
        prep["encrypt_serialize"].append(clock()-enc_start)
        requests.append(payload)
        panel.append(dict(query=q, index=sample["index"], label=sample["label"],
                          payload_sha256=sha(payload), reference_logits=sample["logits"]))
    info = dict(key=s["key"], fingerprint=fingerprint, panel=panel,
                contexts={str(k): sha(v) for k, v in contexts.items()},
                deltas={str(k): sha(v) for k, v in deltas.items()},
                context_payload_bytes={str(k): len(v) for k, v in contexts.items()},
                delta_payload_bytes={str(k): len(v) for k, v in deltas.items()},
                public_preparation_ns=public_ready-started, panel_preparation_ns=clock()-panel_start,
                preparation_ns=prep)
    commit(attempt / "key.json", info)
    return ctx, contexts, deltas, requests, info


def serve(ready, arm, key, path):
    model = ref.Classifier(periodic=True)
    pid = os.getpid()
    with path.open("x") as log, socket.socket() as listener:
        listener.bind(("127.0.0.1", 0))
        listener.listen(1)
        ready.send(listener.getsockname()[1])
        ready.close()
        sock, _ = listener.accept()
        with sock:
            sock.setsockopt(socket.IPPROTO_TCP, socket.TCP_NODELAY, 1)
            ctx, count, seq = None, 0, 0
            completed_queries = 0
            while True:
                kind, tag, wire, rx = ref.receive(sock)
                if kind == 0:
                    if tag or wire:
                        raise ValueError("malformed close")
                    break
                start = clock()
                held = None
                if kind == 1 and ctx is None and tag == (17 if arm == "adaptive" else int(arm[-2:])):
                    ctx = ts.context_from(wire, n_threads=1)
                    if ctx.is_private() or not ctx.has_relin_keys() or not ctx.has_galois_keys():
                        raise RuntimeError("evaluator requires a public evaluation context")
                    held = inventory(ctx, tag)
                    count, body, q = tag, b"", 0
                elif kind == 3 and arm == "adaptive" and ctx is not None and tag == count+1 and tag in STEPS:
                    update.install_one(ctx.galois_keys().data, ctx.seal_context().data,
                                       wire, element(STEPS[tag]))
                    held = inventory(ctx, tag)
                    count, body, q = tag, b"", completed_queries+1
                elif kind == 2 and ctx is not None and tag == count:
                    body = model.forward(ts.ckks_vector_from(ctx, wire)).serialize()
                    completed_queries += 1
                    q = completed_queries
                else:
                    raise ValueError(f"invalid transition: op={kind}, tag={tag}, resident={count}")
                processed = clock()
                payload_sha = sha(wire)
                tx = ref.send(sock, kind, tag, rx.to_bytes(8, "big") + bytes([count]) + body)
                row = dict(seq=seq, kind=kind, keys=count, pid=pid, key=key, arm=arm, query=q,
                           received=rx, sent=tx, payload_sha256=payload_sha, process_ns=processed-start)
                if held is not None:
                    row["present_steps"] = held
                emit(log, row)
                seq += 1


def transactions(s, arm, contexts, deltas, requests, info):
    count = 17 if arm == "adaptive" else int(arm[-2:])
    yield 1, count, 0, contexts[count], info["contexts"][str(count)]
    for sample, request in zip(info["panel"], requests, strict=True):
        q = sample["query"]
        if arm == "adaptive":
            for next_count in STEPS:
                if s[f"switch{next_count}"] == q:
                    count = next_count
                    yield 3, count, q, deltas[count], info["deltas"][str(count)]
        yield 2, count, q, request, sample["payload_sha256"]


def run_arm(s, arm, attempt, ctx, contexts, deltas, requests, info):
    mp_ctx = mp.get_context("spawn")
    reader, writer = mp_ctx.Pipe(duplex=False)
    worker = mp_ctx.Process(target=serve, args=(writer, arm, s["key"], attempt / f"{arm}-server.jsonl"))
    worker.start()
    writer.close()
    try:
        if not reader.poll(90):
            raise TimeoutError("evaluator startup")
        port = reader.recv()
        connect_start = clock()
        connected = socket.create_connection(("127.0.0.1", port), timeout=120)
        connect_end = clock()
        with connected as sock, (attempt / f"{arm}-client.jsonl").open("x") as log:
            sock.setsockopt(socket.IPPROTO_TCP, socket.TCP_NODELAY, 1)
            first, upload, download = None, 0, 0
            for seq, (kind, count, q, payload, payload_sha) in enumerate(
                    transactions(s, arm, contexts, deltas, requests, info)):
                start = clock()
                sent = ref.send(sock, kind, count, payload, s["rate_mbps"])
                reply_kind, reply_count, answer, received = ref.receive(sock)
                replied = clock()
                if ((reply_kind, reply_count) != (kind, count) or len(answer) < 9 or
                        int.from_bytes(answer[:8], "big") != sent or answer[8] != count):
                    raise RuntimeError("receipt disagrees with request")
                prediction = None
                if kind == 2:
                    logits = ts.ckks_vector_from(ctx, answer[9:]).decrypt()
                    end = clock()
                    sample = info["panel"][q-1]
                    if len(logits) != 10 or not np.isfinite(logits).all():
                        raise ValueError("non-finite or malformed prediction")
                    prediction = int(np.argmax(logits))
                else:
                    end = replied
                    if len(answer) != 9:
                        raise RuntimeError("unexpected setup/update reply")
                if first is None:
                    first = start
                upload += sent
                download += received
                row = dict(seq=seq, kind=kind, keys=count, key=s["key"], arm=arm, query=q, pid=worker.pid,
                           upload=sent, download=received, payload_sha256=payload_sha,
                           start_ns=start, reply_ns=replied, end_ns=end, cumulative_ns=end-first,
                           cumulative_upload=upload, cumulative_download=download)
                if kind == 2:
                    row.update(index=sample["index"], logits=logits, label=sample["label"],
                               prediction=prediction, error=max(abs(a-b) for a,b in
                               zip(logits, sample["reference_logits"], strict=True)))
                emit(log, row)
            ref.send(sock, 0, 0, b"")
        worker.join(30)
        if worker.exitcode != 0:
            raise RuntimeError(f"evaluator {arm} failed with exit code {worker.exitcode}")
        summary = dict(arm=arm, key=s["key"], pid=worker.pid, fingerprint=info["fingerprint"],
                       length=s["length"], rate_mbps=s["rate_mbps"], start_ns=first, end_ns=end,
                       elapsed_ns=end-first, upload=upload, download=download, connect_start_ns=connect_start,
                       connect_end_ns=connect_end, tcp_connect_ns=connect_end-connect_start,
                       connect_to_final_decrypt_ns=end-connect_start)
        commit(attempt / f"{arm}-summary.json", summary)
    finally:
        reader.close()
        if worker.is_alive():
            worker.kill()
            worker.join()


def environment(plan_path):
    paths = dict(harness=Path(__file__), reference=Path(ref.__file__), adapter=Path(update.__file__),
                 native=Path(_tenseal_cpp.__file__), sealapi=Path(_sealapi_cpp.__file__),
                 model=BASE / "model/weights.json", fixtures=BASE / "model/samples.json", plan=plan_path)
    if Path(_tenseal_cpp.__file__).resolve().parent != BASE / "patched/lib" or not hasattr(
            _tenseal_cpp.CKKSVector, "add_plain_periodic_"):
        raise RuntimeError("the pinned patched TenSEAL extension is required")
    return dict(platform=platform.platform(), machine=platform.machine(), python=sys.version,
                numpy=np.__version__, tenseal=ts.__version__, thread_environment={k: os.environ[k] for k in THREAD_CAPS},
                evaluator_threads=1, client_threads=1, clock=time.get_clock_info("perf_counter").implementation,
                sha256={k: sha(path.read_bytes()) for k, path in paths.items()})


def execute(args):
    out = args.out.resolve()
    out.mkdir(parents=True, exist_ok=True)
    fixtures = read(BASE / "model/samples.json")
    plan = make_plan(args, len(fixtures))
    with (out / ".lock").open("a") as lock:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        plan_path = out / "plan.json"
        if plan_path.exists():
            if not args.resume:
                raise ValueError("existing plan: use --resume to continue the identical design")
            if read(plan_path) != plan:
                raise ValueError("resume arguments differ from frozen plan")
        else:
            commit(plan_path, plan)
        host = environment(plan_path)
        host_path = out / "host.json"
        if host_path.exists():
            prev = read(host_path)
            if prev["environment"] != host:
                raise ValueError("host, pinned source, native inputs, or design changed")
        else:
            commit(host_path, dict(frozen_utc=now(), environment=host))
        if args.freeze_only:
            return
        if (out / "complete.json").exists():
            print("All frozen blocks already complete.", flush=True)
            return
        with (out / "progress.jsonl").open("a") as progress:
            def checkpoint(event, **fields):
                row = dict(event=event, utc=now(), **fields)
                emit(progress, row)
                print(json.dumps(row, separators=(",", ":")), flush=True)

            for s in plan["sessions"]:
                key = s["key"]
                folder = out / f"key-{key:03d}"
                folder.mkdir(exist_ok=True)
                marker = folder / "complete.json"
                if marker.exists():
                    checkpoint("reuse", key=key, attempt=read(marker)["attempt"])
                    continue
                serial = max((int(p.name.split("-")[1]) for p in folder.glob("attempt-*")), default=0)+1
                attempt = folder / f"attempt-{serial:03d}"
                attempt.mkdir()
                checkpoint("key_start", key=key, attempt=attempt.name)
                ctx, contexts, deltas, requests, info = prepare(s, fixtures, attempt)
                for arm in s["arm_order"]:
                    checkpoint("arm_start", key=key, arm=arm, attempt=attempt.name)
                    run_arm(s, arm, attempt, ctx, contexts, deltas, requests, info)
                    checkpoint("arm_complete", key=key, arm=arm, attempt=attempt.name)
                commit(marker, dict(key=key, fingerprint=info["fingerprint"], attempt=attempt.name,
                                    completed_utc=now()))
                checkpoint("key_complete", key=key, attempt=attempt.name)
                del ctx, contexts, deltas, requests, info
                gc.collect()
            commit(out / "complete.json", dict(completed_utc=now(), keys=len(plan["sessions"]),
                   encrypted_evaluations=4*sum(s["length"] for s in plan["sessions"]),
                   plan_sha256=sha(plan_path.read_bytes())))
            checkpoint("complete", keys=len(plan["sessions"]))


if __name__ == "__main__":
    cli = argparse.ArgumentParser(description=__doc__)
    cli.add_argument("--out", type=Path, required=True)
    cli.add_argument("--keys", type=int, default=12)
    cli.add_argument("--rate", "--rates", dest="rates", default="500", help="one or more comma-separated Mbit/s rates")
    cli.add_argument("--lengths", default="24", help="comma-separated lengths, cycled across fresh keys")
    cli.add_argument("--switch18", type=threshold, default=6, help="one-based query index, or never")
    cli.add_argument("--switch19", type=threshold, default=6, help="one-based query index, or never")
    cli.add_argument("--seed", type=int, default=2718, help="deterministic cyclic panel offset seed")
    cli.add_argument("--plan", type=Path, help="JSON with per-block overrides in a sessions array")
    cli.add_argument("--freeze-only", action="store_true")
    cli.add_argument("--resume", action="store_true")
    execute(cli.parse_args())
