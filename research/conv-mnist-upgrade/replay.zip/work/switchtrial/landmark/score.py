"""Conditional decision for an enrolled client who has served exactly five queries."""
import argparse
import csv
import json
from pathlib import Path
from statistics import mean, median


def box(values):
    return {'mean_ms':mean(values),'median_ms':median(values),'min_ms':min(values),'max_ms':max(values),
            'advantage_keys':sum(x<0 for x in values),'n':len(values)}


def leads(deltas):
    fast=[q for q,d in deltas.items() if d<0]
    last=max(deltas)
    stable=None if deltas[last]>=0 else 1+max([q for q,d in deltas.items() if d>=0],default=5)
    return {'first_lead':min(fast,default=None),'sustained_lead_through_24':stable}


def run(root,output):
    commits=sorted(root.glob('key-*/complete.json'))
    end=json.loads((root/'complete.json').read_text())
    assert len(commits)==end['keys'] and end['encrypted_evaluations']==96*len(commits)
    rows=[]
    key_cross=[]
    negative=[]
    for marker in commits:
        key=json.loads(marker.read_text())
        folder=marker.parent/key['attempt']
        qs={}
        for arm in ['adaptive','fixed17']:
            raw=[json.loads(line) for line in (folder/f'{arm}-client.jsonl').read_text().splitlines()]
            qs[arm]={r['query']:r['cumulative_ns'] for r in raw if r['kind']==2}
            assert set(qs[arm])==set(range(1,25))
        av,fv=qs['adaptive'],qs['fixed17']
        negative.append((av[5]-fv[5])/1e6)
        line={q:((av[q]-av[5])-(fv[q]-fv[5]))/1e6 for q in range(6,25)}
        key_cross.append({'key':key['key'],**leads(line)})
        rows.append(line)
    curve={q:box([r[q] for r in rows]) for q in range(6,25)}
    avg={q:r['mean_ms'] for q,r in curve.items()}
    result={'definition':'Adaptive minus remain at 17, ms counted from decryption at request five',
            'identical_path_control_at_5':box(negative),'curve':curve, 'pooled_crossing':leads(avg),
            'per_key_crossing':key_cross, 'leave_one_key_out_24_ms':
            [mean(r[24] for i,r in enumerate(rows) if i!=k) for k in range(len(rows))]}
    output.mkdir(parents=True,exist_ok=True)
    with (output/'landmark.csv').open('w',newline='') as f:
        w=csv.writer(f);w.writerow(['key','prediction','ms_from_5_adaptive_minus_fixed17'])
        for k,r in enumerate(rows):
            w.writerows((k,q,d) for q,d in r.items())
    (output/'landmark.json').write_text(json.dumps(result,indent=2)+'\n')


if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--run',type=Path,required=True)
    p.add_argument('--out',type=Path,required=True)
    a=p.parse_args()
    run(a.run,a.out)
