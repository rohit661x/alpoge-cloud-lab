# Replicate the catalog-switch trial on two machines

Run the existing client on one computer and its evaluator on a second computer using an authenticated OpenSSH connection. The operator supplies the two hosts and SSH access. Each evaluator accepts a TCP connection on its own loopback interface. The client opens a loopback-only SSH forward to that listener. The native inference function, public-only context check, upgrade schedule, client timer and frame receipts come directly from `work/switchtrial/harness/trial.py`.

## Install the same research bundle on each computer

Use Linux or macOS with Python 3.12, NumPy, the TenSEAL 0.3.18 Python package, the two companion source patches, and the native one-key adapter. Follow `work/second-trained/patched/README.md` for the native build on each machine. Keep the package directories in the same relative arrangement on each host. The two absolute extraction paths and virtual environments can differ. From the bundle root on each host, build the adapter using that host's interpreter.

```sh
/path/to/venv/bin/python work/convnext/upgrade/build.py --companion work/second-trained
```

Identify the evaluator's SSH host or OpenSSH configuration alias. The ordinary account must have working noninteractive authentication and its real host key must already be in the client's known hosts. The SSH server must permit local TCP forwarding to evaluator loopback ports. The runner creates temporary local control sockets. It sets batch mode and strict host-key checking on each connection. Each host retains its own compiled binaries. The client checks the source, fixture, model, patch and runner hashes across hosts. It records each host's native binary hashes, versions, thread settings, Python path, architecture and hostname.

## Start from the client

Replace `eval-lab`, the two interpreter paths, the remote bundle root and the topology description with the values for your two machines. The top-level extraction directory should contain `work/`. The remote interpreter is invoked directly, so shell activation is unnecessary.

```sh
/client/venv/bin/python work/switchtrial/remote/run.py \
  --destination eval-lab \
  --remote-root /srv/ckks-bundle \
  --remote-python /srv/venv/bin/python \
  --topology 'separate client and evaluator on the lab wired LAN' \
  --out fresh-ssh-trial
```

The defaults run 12 independent client-key blocks, all four Williams-ordered arms, 24 encrypted requests per arm, a 500 decimal Mbit/s application upload cap, and both acknowledged upgrades immediately before request six. Client keys, ciphertexts, public catalog bytes and image identities are paired by the original preparation routine. Only public contexts, public updates and encrypted requests go to the evaluator. Results and the byte-identical evaluator receipt files are collected on the client. The independent audit can consume this receipt layout for the full 12-block frozen design.

For alternate dependency directories, set `CONVMNIST_BASE` and `CONVMNIST_ADAPTER` on the client. Supply `--remote-base` and `--remote-adapter` for the evaluator. Each names an absolute path in that host's filesystem. The default layout locates the model and patches in `work/second-trained` and the adapter in `work/convnext/upgrade`.

`--freeze-only` records the local plan and client environment without contacting the evaluator. Use the same arguments and add `--resume` to execute a frozen plan or resume an interrupted experiment. A resume retains completed full blocks and repeats an incomplete block in a new attempt with fresh key material. A changed SSH destination, topology description, client environment or source digest causes the local resume check to fail. The first evaluator connection fixes the remote host manifest for all later arms. Use a fresh output directory to study another host pair or configuration.

For a shorter native connectivity check, add `--keys 1 --length 6` and choose its own output directory. That check runs 24 encrypted predictions and exercises both incremental keys. A full-size statistical replay requires the default design.

## Read the network and timing data

`host.json` contains the client environment, SSH version, destination and supplied topology description. `remote-host.json` contains the evaluator manifest. The `*-tunnel.json` record next to each arm contains eight one-byte echo times and the acknowledgement time for a random 1 MiB upload. The probe uses an additional forwarded TCP channel over the same SSH connection before native setup. Its warm RTT summary is the median of echoes two through eight. The first echo can include opening the forwarded SSH channel. The one-shot upload estimate includes the remote checksum, return acknowledgement and SSH processing. The configured application upload cap and the unpaced probe estimate describe different measurements.

The main endpoint starts immediately before the client's first setup-frame write. It ends when the client decrypts the selected response. SSH encryption, routing delay, buffering and tunnel throughput affect this clock. Local/remote helper startup, the link probe, key generation, encrypted image preparation, and copying the completed receipt file occur outside it. Client and server byte columns count the protocol frames. They omit TCP/IP, SSH framing and the auxiliary probe. The client alone timestamps all endpoint boundaries, so synchronized wall clocks across hosts are unnecessary. SSH and local loopback results are different transport conditions.

Hostnames, command-line topology labels and probes support experiment provenance. Confirmation that the computers are physically distinct comes from the operator's deployment record. Archive `plan.json`, the two host manifests, all committed client/server receipts and `*-tunnel.json` with any reported comparison.

## Lightweight local transport check

```sh
python3 work/switchtrial/remote/smoke/control_test.py
```

This standard-library test launches a tiny worker with a local-only SSH test double. It exercises two loopback forwards, the eight echoes, the checksummed upload, remote PID propagation, matching receipt transfer, and rejection of a deliberately mismatched client digest. It requires neither a native build nor an SSH account. Its successful result describes one-machine transport orchestration. A real SSH server, WAN latency, two physical machines and encrypted inference are outside this test.

## Four encrypted predictions through the local SSH test double

Use `--one-request-smoke` to evaluate each fixed inventory once and to exercise both updates immediately before the adaptive arm's only prediction. This uses one fresh client key, the same encrypted input in all four arms and actual native CKKS inference. From the package root, set `trial_python` to the absolute path of the local environment's Python. Make the test double executable if your archive extractor dropped executable permissions.

```sh
trial_python=/absolute/path/to/venv/bin/python
chmod u+x work/switchtrial/remote/smoke/mock_ssh.py
"$trial_python" work/switchtrial/remote/run.py \
  --destination local-smoke-only \
  --ssh "$PWD/work/switchtrial/remote/smoke/mock_ssh.py" \
  --remote-root "$PWD" --remote-python "$trial_python" \
  --one-request-smoke \
  --topology 'one physical machine with local-only mock SSH forwarding and native CKKS' \
  --out native-forward-smoke
python3 work/switchtrial/remote/smoke/check_native.py native-forward-smoke
```

The checker reconciles all ten transactions, the physical catalogs, byte counts, payload digests and native evaluator PIDs. It checks that every decrypted class matches the clear model and label on the same image. The run records the mock transport in its plan and environment. It provides one-host integration evidence. A genuine two-host SSH trial uses the earlier command and the standard OpenSSH executable.
