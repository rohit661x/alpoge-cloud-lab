"""SSH command endpoint. All listening sockets bind to the evaluator loopback."""
import argparse
import base64
import hashlib
import json
import os
from pathlib import Path
import platform
import signal
import socket
import sys
import tempfile
import threading

HERE = Path(__file__).resolve().parent
PINGS = 8
BULK_BYTES = 1024 * 1024


def load_trial():
    sys.path.insert(0, str(HERE.parent / 'harness'))
    import trial
    return trial


def digest(data):
    return hashlib.sha256(data).hexdigest()


def inventory(trial):
    if not hasattr(trial._tenseal_cpp.CKKSVector, 'add_plain_periodic_') or Path(trial._tenseal_cpp.__file__).resolve().parent != trial.BASE / 'patched/lib':
        raise RuntimeError('The periodic-bias patched TenSEAL extension is required')
    source = {
        'harness': Path(trial.__file__), 'reference': Path(trial.ref.__file__),
        'weights': trial.BASE / 'model/weights.json', 'samples': trial.BASE / 'model/samples.json',
        'install_one': trial.ADAPTER / 'install_one.cpp',
        'periodic_patch': trial.BASE / 'patched/periodic-plaintext.patch',
        'rotation_patch': trial.BASE / 'patched/rotation-repair.patch',
    }
    for name in ('evaluator.py', 'run.py', 'link.py'):
        source[name] = HERE / name
    binaries = {name: Path(module.__file__) for name, module in
                [('tenseal_native', trial._tenseal_cpp), ('sealapi_native', trial._sealapi_cpp), ('adapter', trial.update)]}
    return dict(hostname=socket.gethostname(), platform=platform.platform(), machine=platform.machine(),
                processor=platform.processor(), logical_cpu_count=os.cpu_count(), python=sys.version,
                executable=sys.executable, numpy=trial.np.__version__, tenseal=trial.ts.__version__,
                thread_environment={k: os.environ[k] for k in trial.THREAD_CAPS},
                source_sha256={k: digest(v.read_bytes()) for k, v in source.items()},
                native_sha256={k: digest(v.read_bytes()) for k, v in binaries.items()})


def emit(data):
    print(json.dumps(data, separators=(',', ':')), flush=True)


def read_exact(sock, size):
    data = bytearray(size)
    view = memoryview(data)
    while view:
        length = sock.recv_into(view)
        if not length:
            raise EOFError('Probe connection closed early')
        view = view[length:]
    return data


def serve_probe(host):
    with socket.socket() as listener:
        listener.bind(('127.0.0.1', 0))
        listener.listen(1)
        listener.settimeout(90)
        emit(dict(event='probe_ready', port=listener.getsockname()[1], environment=host))
        sock, _ = listener.accept()
        with sock:
            sock.settimeout(90)
            sock.setsockopt(socket.IPPROTO_TCP, socket.TCP_NODELAY, 1)
            for _ in range(PINGS):
                sock.sendall(read_exact(sock, 1))
            sock.sendall(hashlib.sha256(read_exact(sock, BULK_BYTES)).digest())


class Ready:
    def send(self, port):
        emit(dict(event='evaluator_ready', port=port, pid=os.getpid()))

    def close(self):
        pass


def stop_on_disconnect():
    # The SSH client leaves stdin open until work ends. Losing the channel also
    # interrupts a worker blocked in accept, allowing temporary receipts to be removed.
    os.read(sys.stdin.fileno(), 1)
    os.kill(os.getpid(), signal.SIGINT)


def main():
    cli = argparse.ArgumentParser(description=__doc__)
    cli.add_argument('arm', choices=['fixed17', 'fixed18', 'fixed19', 'adaptive'])
    cli.add_argument('key', type=int)
    args = cli.parse_args()
    threading.Thread(target=stop_on_disconnect, daemon=True).start()
    trial = load_trial()
    serve_probe(inventory(trial))
    with tempfile.TemporaryDirectory() as directory:
        path = Path(directory) / 'receipts.jsonl'
        trial.serve(Ready(), args.arm, args.key, path)
        receipts = path.read_bytes()
        emit(dict(event='complete', sha256=digest(receipts), data=base64.b64encode(receipts).decode('ascii')))


if __name__ == '__main__':
    main()
