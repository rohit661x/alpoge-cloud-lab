"""Launch one remote evaluator behind an authenticated OpenSSH local forward."""
import base64
import hashlib
import json
import os
from pathlib import Path
import queue
import shlex
import socket
import statistics
import subprocess
import tempfile
import threading
import time

from evaluator import BULK_BYTES, PINGS, digest, read_exact


class Tunnel:
    def __init__(self, options, stderr_path):
        self.options = options
        self.directory = tempfile.TemporaryDirectory(prefix='ckks-', dir='/tmp')
        self.control = str(Path(self.directory.name) / 'ssh')
        self.stderr = stderr_path.open('x')
        self.process = None
        self.lines = queue.Queue()

    def start(self, command):
        args = [self.options.ssh, '-T', '-M', '-S', self.control,
                '-o', 'BatchMode=yes', '-o', 'StrictHostKeyChecking=yes',
                '-o', 'ConnectTimeout=20', '-o', 'ServerAliveInterval=15',
                '-o', 'ServerAliveCountMax=3', '-o', 'ControlPersist=no',
                '-o', 'ForwardAgent=no', '-o', 'GatewayPorts=no', '-o', 'Compression=no', '-o', 'ClearAllForwardings=yes',
                self.options.destination, shlex.join(command)]
        self.process = subprocess.Popen(args, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=self.stderr)
        threading.Thread(target=self._read_lines, daemon=True).start()

    def _read_lines(self):
        try:
            for line in self.process.stdout:
                self.lines.put(line)
        finally:
            self.lines.put(None)

    def event(self, name, timeout=90):
        try:
            line = self.lines.get(timeout=timeout)
        except queue.Empty as exc:
            raise TimeoutError(f'Waited {timeout}s for {name}; see {self.stderr.name}') from exc
        if line is None:
            raise RuntimeError(f'SSH evaluator closed before {name}; see {self.stderr.name}')
        value = json.loads(line)
        if value.get('event') != name:
            raise ValueError(f'Unexpected control event while waiting for {name}: {value.get("event")}')
        return value

    def multiplex(self, action, spec):
        return subprocess.run([self.options.ssh, '-S', self.control, '-O', action, '-L', spec,
                               self.options.destination], capture_output=True, text=True, timeout=15)

    def forward(self, remote_port):
        if type(remote_port) is not int or not 1 <= remote_port <= 65535:
            raise ValueError('Unexpected remote loopback port')
        for _ in range(4):
            # OpenSSH performs the actual bind. Retry if the temporary selection
            # collides with another local listener between selection and forwarding.
            with socket.socket() as reservation:
                reservation.bind(('127.0.0.1', 0))
                port = reservation.getsockname()[1]
            spec = f'127.0.0.1:{port}:127.0.0.1:{remote_port}'
            result = self.multiplex('forward', spec)
            if result.returncode == 0:
                return port, spec
        raise RuntimeError(f'Could not open SSH local forward: {result.stderr.strip()}')

    def release_forward(self, spec):
        result = self.multiplex('cancel', spec)
        if result.returncode:
            raise RuntimeError(f'Could not cancel SSH probe forward: {result.stderr.strip()}')

    def close(self):
        if self.process is not None:
            self.process.stdin.close()
            try:
                self.process.wait(timeout=3)
            except subprocess.TimeoutExpired:
                self.process.terminate()
                try:
                    self.process.wait(timeout=3)
                except subprocess.TimeoutExpired:
                    self.process.kill()
                    self.process.wait(timeout=3)
            self.process.stdout.close()
        self.stderr.close()
        self.directory.cleanup()


def probe(port):
    payload = os.urandom(BULK_BYTES)
    expected = hashlib.sha256(payload).digest()
    samples = []
    with socket.create_connection(('127.0.0.1', port), timeout=90) as sock:
        sock.setsockopt(socket.IPPROTO_TCP, socket.TCP_NODELAY, 1)
        for i in range(PINGS):
            marker = bytes([i])
            start = time.perf_counter_ns()
            sock.sendall(marker)
            if read_exact(sock, 1) != marker:
                raise ValueError('Bad tunneled echo')
            samples.append(time.perf_counter_ns() - start)
        start = time.perf_counter_ns()
        sock.sendall(payload)
        if read_exact(sock, len(expected)) != expected:
            raise ValueError('Tunneled upload checksum mismatch')
        elapsed = time.perf_counter_ns() - start
    return dict(echo_roundtrip_ns=samples, median_warm_echo_roundtrip_ns=statistics.median(samples[1:]),
                bulk_ack_ns=elapsed, bulk_payload_bytes=len(payload),
                acknowledged_application_goodput_mbps=8000 * len(payload) / elapsed)


class RemoteWorker:
    """Process interface used by the frozen harness; pid is the remote evaluator's native PID."""
    def __init__(self, options, local_host, writer, arm, key, path):
        self.options, self.local_host, self.writer = options, local_host, writer
        self.arm, self.key, self.path = arm, key, path
        self.tunnel = None
        self.pid = self.exitcode = None

    def start(self):
        self.tunnel = Tunnel(self.options, self.path.with_name(f'{self.arm}-ssh.log'))
        try:
            self.tunnel.start([*self.options.remote_command, self.arm, str(self.key)])
            ready = self.tunnel.event('probe_ready')
            remote_host = ready['environment']
            if remote_host['source_sha256'] != self.local_host['source_sha256']:
                raise RuntimeError('Client and evaluator harness, source, patch or model digests differ')
            if remote_host['tenseal'] != self.local_host['tenseal']:
                raise RuntimeError('Client and evaluator TenSEAL versions differ')
            host_path = self.options.out / 'remote-host.json'
            if host_path.exists():
                if json.loads(host_path.read_text()) != remote_host:
                    raise RuntimeError('Evaluator environment changed across arms or on resume')
            else:
                # The enclosing harness holds the run directory's exclusive lock.
                # An interruption leaves only the temporary copy uncommitted.
                temporary = host_path.with_suffix('.tmp')
                temporary.write_text(json.dumps(remote_host, indent=2) + '\n')
                temporary.replace(host_path)
            probe_port, probe_forward = self.tunnel.forward(ready['port'])
            network = probe(probe_port)
            self.tunnel.release_forward(probe_forward)
            ready = self.tunnel.event('evaluator_ready')
            self.pid = ready['pid']
            if type(self.pid) is not int or self.pid <= 0:
                raise ValueError('Invalid remote evaluator PID')
            port, _ = self.tunnel.forward(ready['port'])
            evidence = dict(key=self.key, arm=self.arm, evaluator_pid=self.pid, probe=network)
            with self.path.with_name(f'{self.arm}-tunnel.json').open('x') as file:
                json.dump(evidence, file, indent=2)
                file.write('\n')
            self.writer.send(port)
        except BaseException:
            self.tunnel.close()
            raise

    def join(self, timeout=30):
        if self.exitcode is not None:
            return
        try:
            outcome = self.tunnel.event('complete', timeout)
            receipts = base64.b64decode(outcome['data'], validate=True)
            if digest(receipts) != outcome['sha256']:
                raise ValueError('Receipt transfer digest mismatch')
            client_path = self.path.with_name(f'{self.arm}-client.jsonl')
            client_rows = [json.loads(row) for row in client_path.read_text().splitlines()]
            server_rows = [json.loads(row) for row in receipts.splitlines()]
            if not client_rows or not server_rows:
                raise ValueError('Missing transaction receipts')
            for c, r in zip(client_rows, server_rows, strict=True):
                if (any(c[k] != r[k] for k in ('key', 'arm', 'pid', 'seq', 'kind', 'keys', 'query', 'payload_sha256'))
                        or c['upload'] != r['received'] or c['download'] != r['sent']):
                    raise ValueError('Client/server transaction receipts disagree')
            self.exitcode = self.tunnel.process.wait(timeout=timeout)
            if self.exitcode == 0:
                with self.path.open('xb') as file:
                    file.write(receipts)
        finally:
            self.tunnel.close()
            if self.exitcode is None:
                self.exitcode = -1

    def is_alive(self):
        return self.exitcode is None

    def kill(self):
        self.tunnel.close()
        self.exitcode = -1
