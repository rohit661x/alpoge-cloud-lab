"""Run the frozen client against the same evaluator on an SSH-accessible POSIX host."""
import argparse
import multiprocessing
from pathlib import Path, PurePosixPath
import shlex
import shutil
import subprocess
from types import SimpleNamespace

from evaluator import inventory, load_trial
from link import RemoteWorker


class RemoteContext:
    def __init__(self, options, local_host, serve):
        self.options, self.local_host, self.serve = options, local_host, serve

    def Pipe(self, duplex):
        return multiprocessing.get_context('spawn').Pipe(duplex=duplex)

    def Process(self, target, args):
        if target is not self.serve or len(args) != 4:
            raise ValueError('The harness evaluator launcher interface has changed')
        return RemoteWorker(self.options, self.local_host, *args)


def main():
    cli = argparse.ArgumentParser(description=__doc__)
    cli.add_argument('--destination', required=True, help='Known OpenSSH destination or SSH config alias')
    cli.add_argument('--remote-root', required=True, type=PurePosixPath, help='Absolute path to extracted bundle root')
    cli.add_argument('--remote-python', required=True, help='Evaluator Python executable or absolute virtualenv interpreter path')
    cli.add_argument('--remote-base', help='Optional absolute path to evaluator second-trained companion')
    cli.add_argument('--remote-adapter', help='Optional absolute path to evaluator adapter directory')
    cli.add_argument('--ssh', default='ssh', help='Local OpenSSH executable')
    cli.add_argument('--topology', default='', help='Operator description of machines and network')
    cli.add_argument('--out', type=Path, required=True)
    cli.add_argument('--resume', action='store_true')
    cli.add_argument('--freeze-only', action='store_true', help='Write the local plan and environment without connecting')
    cli.add_argument('--one-request-smoke', action='store_true',
                     help='Use one key, one query per arm and both live updates before the first adaptive query')
    cli.add_argument('--keys', type=int, default=12)
    cli.add_argument('--length', type=int, default=24, help='Requests per arm; the full study uses 24')
    cli.add_argument('--seed', type=int, default=2718)
    args = cli.parse_args()
    if args.one_request_smoke:
        args.keys, args.length = 1, 1
    if not args.destination or args.destination.startswith('-') or any(c.isspace() for c in args.destination):
        cli.error('Use a single OpenSSH destination or config alias')
    if not args.remote_root.is_absolute() or args.keys < 1 or args.length < 1:
        cli.error('Use an absolute remote bundle root and positive lengths and key counts')
    args.ssh = shutil.which(args.ssh)
    if not args.ssh:
        cli.error('OpenSSH executable unavailable')
    env = []
    for name, path in [('CONVMNIST_BASE', args.remote_base), ('CONVMNIST_ADAPTER', args.remote_adapter)]:
        if path:
            if not PurePosixPath(path).is_absolute():
                cli.error(f'Use an absolute path for {name}')
            env.append(name + '=' + path)
    helper = str(args.remote_root / 'work/switchtrial/remote/evaluator.py')
    args.remote_command = ['env', *env, args.remote_python, helper]
    args.out = args.out.resolve()
    ssh_version = subprocess.run([args.ssh, '-V'], text=True, capture_output=True, check=True, timeout=15)
    trial = load_trial()
    local_host = inventory(trial)
    context = RemoteContext(args, local_host, trial.serve)

    def get_context(name):
        if name != 'spawn':
            raise ValueError('Unexpected process context')
        return context

    # Replace the imported module's launcher only. The native client and remote
    # evaluator execute unchanged, including their frame loops and timing calls.
    trial.mp = SimpleNamespace(get_context=get_context)
    original_plan = trial.make_plan
    original_environment = trial.environment

    using_mock = 'local-only mock ssh' in (ssh_version.stdout + ssh_version.stderr)

    def plan(options, image_count):
        value = original_plan(options, image_count)
        transport = ('local-only loopback forwarding via a mock SSH executable' if using_mock
                     else 'authenticated OpenSSH local forwarding')
        value['reply'] = f'unpaced replies via {transport}, byte-count and catalog receipt at the client'
        value['transport'] = f'{transport}; client and evaluator listeners bound to loopback'
        if args.one_request_smoke:
            value['purpose'] = 'native integration smoke: both updates before first prediction, four arms'
        return value

    def environment(plan_path):
        value = original_environment(plan_path)
        value['ssh'] = dict(destination=args.destination, executable=args.ssh,
                            version=(ssh_version.stdout + ssh_version.stderr).strip(),
                            remote_command=shlex.join(args.remote_command), topology=args.topology)
        value['client_host'] = local_host
        return value

    trial.make_plan, trial.environment = plan, environment
    switch_query = 1 if args.one_request_smoke else 6
    args.lengths, args.rates = str(args.length), '500'
    args.switch18, args.switch19, args.plan = switch_query, switch_query, None
    trial.execute(args)


if __name__ == '__main__':
    main()
