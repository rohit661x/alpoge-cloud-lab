"""Verify the four real encrypted predictions from --one-request-smoke with the local SSH test double."""
import argparse
import hashlib
import json
import math
from pathlib import Path


def read(path):
    return json.loads(path.read_text())


def rows(path):
    return [json.loads(line) for line in path.read_text().splitlines()]


def require(condition, detail):
    if not condition:
        raise ValueError(detail)


def check(out):
    complete = read(out/'complete.json')
    plan = read(out/'plan.json')
    host = read(out/'host.json')['environment']
    remote = read(out/'remote-host.json')
    require((complete['keys'], complete['encrypted_evaluations']) == (1, 4), 'Expected one key and four evaluations')
    require(complete['plan_sha256'] == hashlib.sha256((out/'plan.json').read_bytes()).hexdigest(), 'Plan digest differs')
    require('mock SSH' in plan['transport'] and 'local-only mock ssh' in host['ssh']['version'], 'Expected local mock SSH')
    require(host['client_host']['hostname'] == remote['hostname'] and host['client_host']['source_sha256'] == remote['source_sha256'], 'Expected same host and sources')
    session, = plan['sessions']
    require((session['length'], session['switch18'], session['switch19'], session['rate_mbps']) == (1, 1, 1, 500), 'Unexpected native-smoke design')
    marker = read(out/'key-000/complete.json')
    attempt = out/'key-000'/marker['attempt']
    info = read(attempt/'key.json')
    require(info['fingerprint'] == marker['fingerprint'], 'Uncommitted key')
    sample, = info['panel']
    clear = max(range(10), key=sample['reference_logits'].__getitem__)
    arms = ['adaptive', 'fixed17', 'fixed18', 'fixed19']
    pids, recorded, receipts = set(), {}, 0
    for arm in arms:
        initial = 17 if arm == 'adaptive' else int(arm[-2:])
        transitions = [(1, initial, 0)]
        if arm == 'adaptive':
            transitions.extend([(3, 18, 1), (3, 19, 1)])
        transitions.append((2, 19 if arm == 'adaptive' else initial, 1))
        client = rows(attempt/f'{arm}-client.jsonl')
        server = rows(attempt/f'{arm}-server.jsonl')
        summary = read(attempt/f'{arm}-summary.json')
        tunnel = read(attempt/f'{arm}-tunnel.json')
        require(summary['pid'] == tunnel['evaluator_pid'] and summary['pid'] not in pids, 'Evaluator PID mismatch')
        pids.add(summary['pid'])
        require(len(tunnel['probe']['echo_roundtrip_ns']) == 8 and tunnel['probe']['bulk_payload_bytes'] == 1048576, 'Probe incomplete')
        for seq, ((kind, count, q), c, r) in enumerate(zip(transitions, client, server, strict=True)):
            descriptor = (kind, count, q, seq, arm, summary['pid'])
            require(all(tuple(d[k] for k in ('kind', 'keys', 'query', 'seq', 'arm', 'pid')) == descriptor for d in (c, r)), 'Wrong event')
            if kind == 2:
                expected = sample['payload_sha256']
                logits = c['logits']
                require(len(logits) == 10 and all(map(math.isfinite, logits)), 'Malformed decrypted logits')
                require(max(range(10), key=logits.__getitem__) == c['prediction'] == c['label'] == clear == sample['label'], 'Incorrect decrypted class')
                recorded[arm] = c['prediction']
            else:
                expected = info['contexts' if kind == 1 else 'deltas'][str(count)]
                require(len(r['present_steps']) == count and len(set(r['present_steps'])) == count, 'Wrong physical key inventory')
                require(c['download'] == 19 and (kind != 3 or (512 if count == 18 else 2048) in r['present_steps']), 'Wrong update receipt')
            require(c['payload_sha256'] == r['payload_sha256'] == expected and c['upload'] == r['received'] and c['download'] == r['sent'], 'Mismatched application bytes or digests')
            receipts += 1
        require(summary['fingerprint'] == info['fingerprint'] and summary['elapsed_ns'] == client[-1]['end_ns'] - client[0]['start_ns'], 'Wrong key or timer boundary')
    return dict(status='passed', topology='one physical machine; local-only mock SSH executable; real encrypted CKKS inference', keys=1, encrypted_evaluations=len(recorded),
                updates_before_first_prediction=[512, 2048], reconciled_transactions=receipts, same_input_ciphertext_all_arms=True,
                clear_and_decrypted_class=clear, predictions=recorded)


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('out', type=Path)
    print(json.dumps(check(parser.parse_args().out), indent=2))
