"""Check the remote process adapter with tiny local frames and mock SSH. No CKKS work."""
import base64
import hashlib
import json
from pathlib import Path
import os
import shutil
import socket
import sys
import tempfile
from types import SimpleNamespace

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parent))
from evaluator import Ready, emit, read_exact, serve_probe
from link import RemoteWorker

HOST = {'source_sha256': {'mock': 'control-test-source'}, 'tenseal': 'mock'}
PAYLOAD = b'local forwarding smoke payload'


def tiny_server(arm, key):
    serve_probe(HOST)
    with socket.socket() as listener:
        listener.bind(('127.0.0.1', 0))
        listener.listen(1)
        Ready().send(listener.getsockname()[1])
        conn, _ = listener.accept()
        with conn:
            data = read_exact(conn, len(PAYLOAD))
            conn.sendall(b'OK')
            if data != PAYLOAD:
                raise ValueError('mock payload mismatch')
    row = dict(seq=0, kind=1, keys=17, key=key, arm=arm, query=0, pid=os.getpid(),
               received=len(data), sent=2, payload_sha256=hashlib.sha256(data).hexdigest())
    receipts = (json.dumps(row)+'\n').encode()
    emit(dict(event='complete', sha256=hashlib.sha256(receipts).hexdigest(), data=base64.b64encode(receipts).decode()))


def test(directory, corrupt=False):
    directory.mkdir()
    mock = directory / 'mock-ssh'
    shutil.copyfile(HERE / 'mock_ssh.py', mock)
    mock.chmod(0o700)
    options = SimpleNamespace(ssh=str(mock), destination='local-smoke-only', out=directory,
                              remote_command=[sys.executable, str(Path(__file__).resolve()), 'worker'])
    out = []
    path = directory/'adaptive-server.jsonl'
    worker = RemoteWorker(options, HOST, SimpleNamespace(send=out.append), 'adaptive', 0, path)
    worker.start()
    try:
        with socket.create_connection(('127.0.0.1', out[0]), timeout=15) as conn:
            conn.sendall(PAYLOAD)
            assert read_exact(conn, 2) == b'OK'
        fingerprint = 'bad' if corrupt else hashlib.sha256(PAYLOAD).hexdigest()
        row = dict(seq=0, kind=1, keys=17, key=0, arm='adaptive', query=0, pid=worker.pid,
                   upload=len(PAYLOAD), download=2, payload_sha256=fingerprint)
        (directory/'adaptive-client.jsonl').write_text(json.dumps(row)+'\n')
        if corrupt:
            try:
                worker.join()
            except ValueError as exc:
                assert 'disagree' in str(exc) and not path.exists()
            else:
                raise AssertionError('Accepted tampered client digest')
        else:
            worker.join()
            assert json.loads(path.read_text())['pid'] == worker.pid and worker.exitcode == 0
            net = json.loads((directory/'adaptive-tunnel.json').read_text())['probe']
            assert len(net['echo_roundtrip_ns']) == 8 and net['bulk_payload_bytes'] == 1024**2
    finally:
        if worker.is_alive():
            worker.kill()


if __name__ == '__main__':
    if sys.argv[1:2] == ['worker']:
        tiny_server(sys.argv[2], int(sys.argv[3]))
    else:
        with tempfile.TemporaryDirectory() as temp:
            test(Path(temp)/'ok')
            test(Path(temp)/'bad', corrupt=True)
        print('PASS: loopback control, both forwards, eight echoes, hashed upload, native-PID routing, exact receipts, tamper rejection. Local mock SSH; no encrypted inference or physical remote host.')
