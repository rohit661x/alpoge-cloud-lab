#!/usr/bin/env python3
"""Local-only OpenSSH test double: performs loopback forwarding and local execution."""
import json
import os
from pathlib import Path
import selectors
import shlex
import socket
import subprocess
import sys
import threading


def relay(conn, destination):
    with conn, socket.create_connection(('127.0.0.1', destination), timeout=30) as other:
        conn.settimeout(None)
        other.settimeout(None)
        with selectors.DefaultSelector() as selector:
            selector.register(conn, selectors.EVENT_READ, other)
            selector.register(other, selectors.EVENT_READ, conn)
            while selector.get_map():
                for key, _ in selector.select():
                    chunk = key.fileobj.recv(65536)
                    if chunk:
                        key.data.sendall(chunk)
                    else:
                        selector.unregister(key.fileobj)
                        key.data.shutdown(socket.SHUT_WR)


def settings(args, flag):
    return args[args.index(flag) + 1]


def master(args, control):
    if args[-2] != 'local-smoke-only':
        raise ValueError('The mock supports only local-smoke-only')
    command = shlex.split(args[-1])
    with socket.socket(socket.AF_UNIX) as listener:
        listener.bind(control)
        listener.listen(4)
        listener.settimeout(.1)
        child = subprocess.Popen(command)
        forwards = {}
        try:
            while child.poll() is None:
                try:
                    peer, _ = listener.accept()
                except TimeoutError:
                    continue
                with peer:
                    action, spec = json.loads(peer.recv(4096))
                    src, local, dest, remote = spec.split(':')
                    if src != '127.0.0.1' or dest != '127.0.0.1':
                        raise ValueError('The mock forwards only loopback addresses')
                    if action == 'forward':
                        sock = socket.socket()
                        try:
                            sock.bind((src, int(local)))
                            sock.listen(1)
                        except OSError as exc:
                            sock.close()
                            peer.sendall(str(exc).encode())
                            continue
                        forwards[spec] = sock
                        def receive_once(listener=sock, destination=int(remote)):
                            conn, _ = listener.accept()
                            relay(conn, destination)
                        threading.Thread(target=receive_once, daemon=True).start()
                    elif action == 'cancel':
                        forwards.pop(spec).close()
                    else:
                        raise ValueError(action)
                    peer.sendall(b'ok')
        finally:
            for sock in forwards.values():
                sock.close()
            if child.poll() is None:
                child.terminate()
            child.wait()
        return child.returncode


def main():
    args = sys.argv[1:]
    if args == ['-V']:
        print('local-only mock ssh, no SSH protocol or cryptography')
        return 0
    control = settings(args, '-S')
    if '-M' in args:
        return master(args, control)
    if '-O' not in args or args[-1] != 'local-smoke-only':
        raise ValueError('Unexpected mock invocation')
    with socket.socket(socket.AF_UNIX) as peer:
        peer.connect(control)
        peer.sendall(json.dumps([settings(args, '-O'), settings(args, '-L')]).encode())
        answer = peer.recv(4096)
        if answer != b'ok':
            print(answer.decode(), file=sys.stderr)
            return 1
    return 0


if __name__ == '__main__':
    sys.exit(main())
