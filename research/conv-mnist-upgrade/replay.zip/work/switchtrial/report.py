"""Render the offline research brief from validated aggregate data."""
from html import escape
from pathlib import Path
from statistics import median
import json

HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[1]
RES=HERE/'results'
ARMS=('fixed17','fixed18','fixed19','adaptive')
LABEL={'primary':'Designed mix · 80% stop at five, 20% at 24',
       'short':'Five predictions','long':'24 predictions','uniform':'Uniform lengths from five to ten',
       'external':'VisionArena conversation lengths, capped at 24'}
ARM={'fixed17':'Fixed 17','fixed18':'Fixed 18','fixed19':'Fixed 19','adaptive':'Upgrade at six'}


def read(path):
    return json.loads(path.read_text())


def table(head,rows,caption=''):
    cap='<caption>'+escape(caption)+'</caption>' if caption else ''
    return '<div class="scroll"><table>'+cap+'<thead><tr>'+''.join('<th scope="col">'+escape(s)+'</th>' for s in head)+'</tr></thead><tbody>'+''.join('<tr>'+''.join(('<th scope="row">'+escape(str(s))+'</th>') if i==0 else '<td>'+escape(str(s))+'</td>' for i,s in enumerate(row))+'</tr>' for row in rows)+'</tbody></table></div>'


def verdict(x):
    return f'{abs(x):.1f} ms '+('slower' if x>0 else 'faster' if x<0 else 'tied')


def render():
    p=read(RES/'main-extra.json')
    lazy=read(RES/'lazy-extra.json')
    brief=read(RES/'audit/summary.json')
    landmark=read(RES/'landmark.json')
    lazy_land=read(RES/'lazy-landmark/landmark.json')
    h=read(HERE/'external/histogram.json')
    obs=brief['observed']
    prim=p['laws']['primary']; latter=lazy['laws']['primary']
    vc=brief['validation']
    best_interval=[n/1e6 for n in obs['observed_primary_bootstrap_ns']['best_pooled_fixed_reselected']]
    cold_keys=read(RES/'lazy-audit.json')['paired_mixture_differences_s'][latter['best_fixed']]
    cold_rounded=', '.join(f'{1000*x:+.1f}' for x in cold_keys)
    cross=landmark['pooled_crossing']['sustained_lead_through_24']
    lazy_cross=lazy_land['pooled_crossing']['sustained_lead_through_24']
    def when(x):
        return str(x) if x is not None else 'No sustained lead'
    def lawtable(run):
        rows=[]
        for k,r in run['laws'].items():
            rows.append([LABEL[k],*[f"{r['latency_ms'][a]/1000:.3f}" for a in ARMS],
                         f"{verdict(r['delta_ms'])} vs {ARM[r['best_fixed']]}"])
        return table(['Workload','Fixed 17 (s)','Fixed 18 (s)','Fixed 19 (s)','Upgrade at six (s)','Change vs fastest fixed'],rows)
    details=[]
    for a in ('fixed17','fixed18','fixed19'):
        d=brief['primary']['elapsed_ns']['adaptive_minus_fixed'][a]
        boot=obs['observed_primary_bootstrap_ns'][a]
        details.append([ARM[a],f"{d['mean']/1e6:+.1f} ms",f"{boot[0]/1e6:+.1f} to {boot[1]/1e6:+.1f} ms",str(d['faster'])+' of 12'])
    ref='https://openaccess.thecvf.com/content/CVPR2025/html/Chou_VisionArena_230k_Real_World_User-VLM_Conversations_with_Preference_Labels_CVPR_2025_paper.html'
    dataset='https://huggingface.co/datasets/lmarena-ai/VisionArena-Chat/tree/'+h['revision']
    upload=table(['Policy','Median initial catalog','Median subsequent keys','Median joint wait for both acknowledgements'],
                 [[ARM[x['arm']],f"{x['median_initial_upload_mb']:.2f} MB",f"{x['median_added_upload_mb']:.2f} MB",
                   f"{x['median_joint_update_socket_ms']:.1f} ms" if x['arm']=='adaptive' else '—'] for x in p['catalog']])
    def ltable():
        return table(['Deployment clock','Extra time at prediction six','Change from the end of five through 24','First sustained lead through 24'],
                     [[name,f"{v['curve']['6']['mean_ms']:+.1f} ms",f"{v['curve']['24']['mean_ms']:+.1f} ms",when(cr)]
                      for name,v,cr in [('Prepared public keys',landmark,cross),('Generate public keys on demand',lazy_land,lazy_cross)]])
    payload=json.dumps({k:p['laws'][k]['latency_ms'] for k in ('short','long')},separators=(',',':'))
    text=f"""<!doctype html>
<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>When should an encrypted classifier add rotation keys?</title>
<style>
:root{{color-scheme:light;--ink:#142b35;--quiet:#46606d;--rule:#bfd0d2;--teal:#146457}}
*{{box-sizing:border-box}}body{{margin:0;color:var(--ink);background:#f7f7f1;font:16px/1.5 system-ui,sans-serif}}main{{max-width:1050px;margin:0 auto;padding:clamp(20px,5vw,60px)}}header{{border-top:6px solid var(--teal);padding:26px 0 12px}}h1,h2{{font-family:Georgia,serif;font-weight:500;line-height:1.12}}h1{{font-size:clamp(34px,5vw,60px);max-width:850px;margin:0 0 20px}}h2{{font-size:clamp(24px,3vw,34px);margin:36px 0 10px}}p{{max-width:85ch}}header p{{font-size:19px}}.scroll{{overflow:auto;margin:16px 0}}table{{border-collapse:collapse;width:100%;font-size:14px;background:#fff}}th,td{{padding:9px 12px;border-bottom:1px solid var(--rule);text-align:right;font-variant-numeric:tabular-nums;white-space:nowrap}}th:first-child{{text-align:left;white-space:normal;min-width:120px}}thead th{{background:#e5eeea;font-weight:650;white-space:normal}}tbody th{{font-weight:500}}a{{color:var(--teal)}}.control{{padding:16px 20px;background:#e5eeea;border-left:4px solid var(--teal);margin:18px 0}}input{{width:min(410px,100%);accent-color:var(--teal);display:block;margin:12px 0}}output{{display:block;font-weight:620}}.note,footer{{color:var(--quiet)}}@media print{{main{{padding:0}}.control{{display:none}}h2{{break-after:avoid}}section{{break-inside:avoid}}}}
</style></head><body><main><header><h1>When should an encrypted classifier add rotation keys?</h1>
<p>We tested a client that starts ConvMNIST with 17 rotation keys. When a sixth request arrives, it uploads rotation keys for +512 and +2048, waits for both acknowledgements and answers with 19 keys.</p>
<p>On the prespecified session mix, this rule was <b>{verdict(prim['delta_ms'])} than {ARM[prim['best_fixed']]}</b> when public keys were prepared. With keys generated on demand, it was <b>{verdict(latter['delta_ms'])} than {ARM[latter['best_fixed']]}</b> in a smaller follow-up.</p>
<p>The primary difference has an exploratory 95% paired bootstrap interval of {best_interval[0]:+.1f} to {best_interval[1]:+.1f} ms for switching minus the fastest fixed choice, reselected in each resample. The data support a conditional recovery point for a client already using 17 keys. A general enrollment-time advantage needs a separate deployment replication.</p></header>
<section><h2>Time a client actually waited</h2><p>Each entry averages cumulative measured seconds across paired fresh client keys. Each client sent the same input ciphertext at each position to all four policies. Values for a workload are weighted averages of measured prefixes. The designed mix gives a five-prediction session four times the weight of a 24-prediction session.</p>
<h3>Public keys ready to send · 12 fresh client keys</h3>{lawtable(p)}
<p>The client clock begins at its first setup write and ends at decryption. It includes uploads, acknowledgements, server inference and client decryption. Client key generation, input encryption, process startup and connection establishment occurred beforehand.</p>
<h3>Generate public keys as needed · four additional fresh client keys</h3>{lawtable(lazy)}
<p>In this separate cohort the clock begins before preparing each arm’s initial catalog. The adaptive arm generates and serializes its missing public keys only after request six arrives. All arms share a prepared client secret, ciphertexts and an established connection. Catalogs in this cohort use independent public key-switching randomness under the same client secret. The four individual switch-minus-{ARM[latter['best_fixed']]} differences on the designed mix were {cold_rounded} ms.</p></section>
<section><h2>The decision after prediction five</h2><p>For an already-enrolled client the relevant comparison is continuing with 17 keys. These values subtract the time both policies had spent by prediction five. Negative changes favor upgrading. A sustained lead lasts through the last measured prediction.</p>{ltable()}
<p>As a timing control, the two prepared policies performed identical work through prediction five. Their observed mean difference was {landmark['identical_path_control_at_5']['mean_ms']:+.1f} ms.</p></section>
<section><h2>How the workload changes the result</h2>
<div class="control"><label for="mix">Share of sessions reaching 24 predictions, with all others stopping at five</label><input type="range" min="0" max="100" value="20" step="1" id="mix"><output id="mixresult" aria-live="polite"></output></div>
<p>The independent sensitivity uses the published lengths of {h['n']:,} human conversations with vision-language models. Only {h['survive_to_six']:,} ({100*h['survive_to_six']/h['n']:.2f}%) reached a sixth turn. We counted each conversation once and capped {h['clipped_above_24']:,} conversations at 24. Applying their length distribution to the encrypted measurements tests how the result changes for a different workload. There are no encrypted deployment logs in this dataset. <a href="{ref}">VisionArena paper</a> · <a href="{dataset}">Pinned data release</a></p></section>
<section><h2>Uncertainty and upload cost</h2><p>Paired changes on the primary mix use one observation per fresh client key. The intervals resample entire key blocks 20,000 times. These exploratory intervals describe variation within one machine and software build.</p>
{table(['Comparator','Mean change','95% paired bootstrap interval','Keys favoring switch'],details)}
{upload}
<p>Including ciphertext requests, mean total client upload on the primary mix was {prim['upload_mb']['adaptive']:.2f} MB with the adaptive rule, {prim['upload_mb']['fixed17']:.2f} MB with fixed 17, {prim['upload_mb']['fixed18']:.2f} MB with fixed 18, and {prim['upload_mb']['fixed19']:.2f} MB with fixed 19. MB is decimal. All byte counts cover actual framed payloads, with weighting by the designed session lengths.</p>
<p>The two sequential key installations each require one extra round trip in sessions that reach prediction six. A simple sensitivity adds 0.4 times any extra round-trip latency to the mean adaptive penalty on the designed mix. An additional 50 ms per round trip therefore shifts that comparison by 20 ms. This calculation assumes all other transport and compute costs stay fixed.</p></section>
<section><h2>What was verified</h2><p>The primary cohort ran {vc['query_transactions']:,} encrypted predictions, {vc['setup_transactions']} setups and {vc['update_transactions']} live key updates, with {vc['class_disagreements']} class disagreements against scalar inference and the test labels. The separate on-demand cohort ran 384 encrypted predictions. Each session cycled through the same eight MNIST test images, with fresh ciphertexts at each request position. All four arms appeared equally often in each run position.</p>
<p>Both processes ran on one Apple M5 Pro. The sender paced upload frames to 500 decimal Mbit/s on local TCP, with unpaced replies. Each evaluator used one thread. The evidence kit includes a two-host runner, raw receipts, frozen protocol and replay checks. A separate local integration check sent four real encrypted predictions, including both additions, through the runner using loopback forwards and a mock SSH executable. It verifies the code path on this host.</p></section>
<footer><p>These results describe the completed single-machine experiment. The repository records the subsequent two-Mac replication in a separate partial checkpoint.</p></footer>
<script>const raw={payload};
const labels={{fixed17:'fixed 17',fixed18:'fixed 18',fixed19:'fixed 19'}};
function update(){{let p=Number(document.getElementById('mix').value)/100;
let costs=Object.fromEntries(Object.keys(raw.short).map(k=>[k,(1-p)*raw.short[k]+p*raw.long[k]]));
let best=Object.keys(labels).sort((a,b)=>costs[a]-costs[b])[0];let d=costs.adaptive-costs[best];
document.getElementById('mixresult').textContent=(100*p).toFixed(0)+'% long sessions · the upgrade rule is '+Math.abs(d).toFixed(1)+' ms '+(d>0?'slower than ':d<0?'faster than ':'tied with ')+labels[best]+' on average with prepared keys.';}}
document.getElementById('mix').addEventListener('input',update);update();</script></main></body></html>"""
    return text


if __name__=='__main__':
    (ROOT/'outputs/conv-mnist-when-to-upgrade.html').write_text(render())
