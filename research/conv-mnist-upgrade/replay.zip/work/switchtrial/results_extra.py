"""Compute corroborating primary, transfer-delay, and trace summaries from committed receipts."""
from collections import Counter
from pathlib import Path
from statistics import mean,median
import argparse
import json

BASE=Path(__file__).resolve().parent
ARMS=('adaptive','fixed17','fixed18','fixed19')


def load(p):
    return json.loads(p.read_text())


def readlines(p):
    return [json.loads(l) for l in p.read_text().splitlines()]


def scores(root):
    out={}
    for m in sorted(root.glob('key-*/complete.json')):
        k=load(m)
        a=m.parent/k['attempt']
        row={}
        for arm in ARMS:
            events=readlines(a/(arm+'-client.jsonl'))
            qs=[e for e in events if e['kind']==2]
            assert [x['query'] for x in qs]==list(range(1,25))
            row[arm]={'ns':[x['cumulative_ns'] for x in qs], 'upload':[x['cumulative_upload'] for x in qs],
                      'events':events}
        out[k['key']]=row
    assert len(out)==load(root/'complete.json')['keys']
    return out


def law(cohort,weights,field='ns'):
    normalized=sum(weights.values())
    by_key={k:{a:sum(w*arms[a][field][q-1] for q,w in weights.items())/normalized for a in ARMS}
            for k,arms in cohort.items()}
    means={a:mean(r[a] for r in by_key.values()) for a in ARMS}
    fixed=min(ARMS[1:],key=means.get)
    return {'mean':means,'best_fixed':fixed,'adaptive_minus_best':means['adaptive']-means[fixed],
            'paired_vs_best':[r['adaptive']-r[fixed] for r in by_key.values()]}


def analyze(root,external):
    c=scores(root)
    hist={int(k):v for k,v in load(external)['counts'].items()}
    capped=Counter()
    for q,n in hist.items():capped[min(24,q)]+=n
    laws={'primary':{5:4,24:1},'short':{5:1},'long':{24:1},'uniform':dict.fromkeys(range(5,11),1),
          'external':dict(capped)}
    rows={}
    for name,w in laws.items():
        times=law(c,w)
        uploads=law(c,w,'upload')
        fixed=times['best_fixed']
        survive=sum(v for q,v in w.items() if q>=6)/sum(w.values())
        delay={r:times['adaptive_minus_best']/1e6+2*survive*r for r in (0,10,25,50,100)}
        rows[name]=dict(latency_ms={k:v/1e6 for k,v in times['mean'].items()},upload_mb={k:v/1e6 for k,v in uploads['mean'].items()},
                       best_fixed=fixed,delta_ms=times['adaptive_minus_best']/1e6,
                       fraction_faster_vs_best=sum(x<0 for x in times['paired_vs_best'])/len(c),
                       survive_to_six=survive,delta_ms_with_added_per_call_rtt_ms=delay)
    catalog=[]
    for arm in ARMS:
        envelopes=[]
        for data in c.values():
            logs=data[arm]['events']
            setups=[e for e in logs if e['kind']==1]
            adds=[e for e in logs if e['kind']==3]
            assert len(setups)==1
            envelopes.append([setups[0]['upload'],sum(e['upload'] for e in adds),
                             sum(e['reply_ns']-e['start_ns'] for e in adds)])
        catalog.append({'arm':arm,'median_initial_upload_mb':median(r[0] for r in envelopes)/1e6,
                        'median_added_upload_mb':median(r[1] for r in envelopes)/1e6,
                        'median_joint_update_socket_ms':median(r[2] for r in envelopes)/1e6})
    return {'keys':len(c),'laws':rows,'catalog':catalog}


if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--run',type=Path,required=True);p.add_argument('--out',type=Path,required=True)
    p.add_argument('--hist',type=Path,default=BASE/'external/histogram.json')
    a=p.parse_args();a.out.write_text(json.dumps(analyze(a.run,a.hist),indent=2)+'\n')
